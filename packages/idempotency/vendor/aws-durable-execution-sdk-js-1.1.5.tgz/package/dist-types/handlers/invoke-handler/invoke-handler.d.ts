import { ExecutionContext, InvokeConfig, DurablePromise } from "../../types";
import { Checkpoint } from "../../utils/checkpoint/checkpoint-helper";
export declare const createInvokeHandler: (context: ExecutionContext, checkpoint: Checkpoint, createStepId: () => string, parentId?: string, checkAndUpdateReplayMode?: () => void) => {
    <I, O>(funcId: string, input?: I, config?: InvokeConfig<I, O>): DurablePromise<O>;
    <I, O>(name: string, funcId: string, input?: I, config?: InvokeConfig<I, O>): DurablePromise<O>;
};
//# sourceMappingURL=invoke-handler.d.ts.map