export {};
//# sourceMappingURL=wait-for-condition-handler.test.d.ts.map