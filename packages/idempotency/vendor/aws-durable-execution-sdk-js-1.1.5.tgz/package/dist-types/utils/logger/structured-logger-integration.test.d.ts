export {};
//# sourceMappingURL=structured-logger-integration.test.d.ts.map