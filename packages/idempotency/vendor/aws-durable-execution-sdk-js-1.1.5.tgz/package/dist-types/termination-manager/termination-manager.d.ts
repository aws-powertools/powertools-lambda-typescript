import { EventEmitter } from "events";
import { TerminationOptions, TerminationResponse } from "./types";
export declare class TerminationManager extends EventEmitter {
    private isTerminated;
    private terminationDetails?;
    private resolveTermination?;
    private terminationPromise;
    private setCheckpointTerminating?;
    constructor(setCheckpointTerminating?: () => void);
    setCheckpointTerminatingCallback(callback: () => void): void;
    terminate(options?: TerminationOptions): void;
    getTerminationPromise(): Promise<TerminationResponse>;
    private handleTermination;
}
//# sourceMappingURL=termination-manager.d.ts.map