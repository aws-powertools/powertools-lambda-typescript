import { Duration } from "../../types";
/**
 * Converts a Duration object to total seconds
 * @param duration - Duration object with at least one time unit specified
 * @returns Total duration in seconds
 */
export declare function durationToSeconds(duration: Duration): number;
//# sourceMappingURL=duration.d.ts.map