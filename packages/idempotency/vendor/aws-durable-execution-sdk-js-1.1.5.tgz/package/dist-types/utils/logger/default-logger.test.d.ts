export {};
//# sourceMappingURL=default-logger.test.d.ts.map