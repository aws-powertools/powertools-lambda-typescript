export {};
//# sourceMappingURL=error-object-coverage.test.d.ts.map