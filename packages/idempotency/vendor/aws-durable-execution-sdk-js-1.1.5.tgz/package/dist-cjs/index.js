'use strict';

var clientLambda = require('@aws-sdk/client-lambda');
var events = require('events');
var async_hooks = require('async_hooks');
var crypto = require('crypto');
var node_console = require('node:console');
var util = require('node:util');
var node_url = require('node:url');
var node_path = require('node:path');

var _documentCurrentScript = typeof document !== 'undefined' ? document.currentScript : null;
/**
 * @internal
 */
var DurableExecutionMode;
(function (DurableExecutionMode) {
    DurableExecutionMode["ExecutionMode"] = "ExecutionMode";
    DurableExecutionMode["ReplayMode"] = "ReplayMode";
    DurableExecutionMode["ReplaySucceededContext"] = "ReplaySucceededContext";
})(DurableExecutionMode || (DurableExecutionMode = {}));
/**
 * Status enumeration for durable execution invocation results.
 *
 * This enum defines the possible outcomes of a durable execution invocation,
 * indicating whether the execution completed successfully, failed, or is
 * continuing asynchronously.
 *
 * The status determines how the AWS durable execution service will handle
 * the execution:
 * - SUCCEEDED: Execution completed successfully with a final result
 * - FAILED: Execution failed with an error that cannot be retried
 * - PENDING: Execution is continuing and will be resumed later (checkpointed)
 *
 * @public
 */
exports.InvocationStatus = void 0;
(function (InvocationStatus) {
    /**
     * The durable execution completed successfully.
     *
     * This status indicates:
     * - A final result is available (if any)
     * - No further invocations are needed
     * - The execution has reached its natural completion
     */
    InvocationStatus["SUCCEEDED"] = "SUCCEEDED";
    /**
     * The durable execution failed with an unrecoverable error.
     *
     * This status indicates:
     * - An error occurred that cannot be automatically retried
     * - Error details are provided in the response
     * - No further invocations will occur
     */
    InvocationStatus["FAILED"] = "FAILED";
    /**
     * The durable execution is continuing asynchronously.
     *
     * This status indicates:
     * - Execution was checkpointed and will resume later
     * - Common scenarios: waiting for callbacks, retries, wait operations
     * - The function may terminate while execution continues
     * - Future invocations will resume from the checkpoint
     */
    InvocationStatus["PENDING"] = "PENDING";
})(exports.InvocationStatus || (exports.InvocationStatus = {}));
/**
 * Operation subtype enumeration for categorizing different types of durable operations.
 *
 * This enum provides fine-grained classification of durable operations beyond the
 * basic operation types. Subtypes enable improved observability for specific
 * operation patterns.
 *
 * Each subtype corresponds to a specific durable context method or execution pattern.
 *
 * @public
 */
exports.OperationSubType = void 0;
(function (OperationSubType) {
    /**
     * A durable step operation (`context.step`).
     *
     * Represents atomic operations with automatic retry and checkpointing.
     * Steps are the fundamental building blocks of durable executions.
     */
    OperationSubType["STEP"] = "Step";
    /**
     * A wait operation (`context.wait`).
     *
     * Represents time-based delays that pause execution for a specified duration.
     * Waits allow long-running workflows without keeping invocations active.
     */
    OperationSubType["WAIT"] = "Wait";
    /**
     * A callback creation operation (`context.createCallback`).
     *
     * Represents the creation of a callback that external systems can complete.
     * Used for human-in-the-loop workflows and external system integration.
     */
    OperationSubType["CALLBACK"] = "Callback";
    /**
     * A child context operation (`context.runInChildContext`).
     *
     * Represents execution within an isolated child context with its own
     * step counter and state tracking. Used for grouping related operations.
     */
    OperationSubType["RUN_IN_CHILD_CONTEXT"] = "RunInChildContext";
    /**
     * A map operation (`context.map`).
     *
     * Represents parallel processing of an array of items with concurrency control
     * and completion policies. Each map operation coordinates multiple iterations.
     */
    OperationSubType["MAP"] = "Map";
    /**
     * An individual iteration within a map operation.
     *
     * Represents the processing of a single item within a `context.map` call.
     * Each iteration runs in its own child context with isolated state.
     */
    OperationSubType["MAP_ITERATION"] = "MapIteration";
    /**
     * A parallel execution operation (`context.parallel`).
     *
     * Represents concurrent execution of multiple branches with optional
     * concurrency control and completion policies.
     */
    OperationSubType["PARALLEL"] = "Parallel";
    /**
     * An individual branch within a parallel operation.
     *
     * Represents a single branch of execution within a `context.parallel` call.
     * Each branch runs in its own child context with isolated state.
     */
    OperationSubType["PARALLEL_BRANCH"] = "ParallelBranch";
    /**
     * A wait for callback operation (`context.waitForCallback`).
     *
     * Represents waiting for an external system to complete a callback,
     * combining callback creation with submission logic.
     */
    OperationSubType["WAIT_FOR_CALLBACK"] = "WaitForCallback";
    /**
     * A wait for condition operation (`context.waitForCondition`).
     *
     * Represents periodic checking of a condition until it's met,
     * with configurable polling intervals and wait strategies.
     */
    OperationSubType["WAIT_FOR_CONDITION"] = "WaitForCondition";
    /**
     * A chained invocation operation (`context.invoke`).
     *
     * Represents calling another durable function with input parameters
     * and waiting for its completion. Used for function composition and workflows.
     */
    OperationSubType["CHAINED_INVOKE"] = "ChainedInvoke";
})(exports.OperationSubType || (exports.OperationSubType = {}));

/**
 * Log level supported by the durable logger
 * @public
 */
var DurableLogLevel;
(function (DurableLogLevel) {
    DurableLogLevel["INFO"] = "INFO";
    DurableLogLevel["WARN"] = "WARN";
    DurableLogLevel["ERROR"] = "ERROR";
    DurableLogLevel["DEBUG"] = "DEBUG";
})(DurableLogLevel || (DurableLogLevel = {}));

/**
 * Execution semantics for step operations.
 *
 * @remarks
 * These semantics control how step execution is checkpointed and replayed. **Important**: The guarantees apply *per
 * retry attempt*, not per overall workflow execution.
 *
 * With retries enabled (the default), a step could execute multiple times across different retry attempts even when
 * using `AtMostOncePerRetry`. To achieve step-level at-most-once execution, combine `AtMostOncePerRetry` with a retry
 * strategy that disables retries (`shouldRetry: false`).
 *
 * @example
 * ```typescript
 * // At-least-once per retry (default) - safe for idempotent operations
 * await context.step("send-notification", async () => sendEmail(), {
 *   semantics: StepSemantics.AtLeastOncePerRetry,
 * });
 *
 * // At-most-once per retry - for non-idempotent operations
 * await context.step("charge-payment", async () => processPayment(), {
 *   semantics: StepSemantics.AtMostOncePerRetry,
 *   retryStrategy: () => ({ shouldRetry: false }),
 * });
 * ```
 *
 * @public
 */
exports.StepSemantics = void 0;
(function (StepSemantics) {
    /**
     * At-most-once execution per retry attempt.
     *
     * @remarks
     * A checkpoint is created before step execution. If a failure occurs after the checkpoint
     * but before step completion, the previous step retry attempt is skipped on replay.
     *
     * **Note**: This is "at-most-once *per retry*". With multiple retry attempts, the step
     * could still execute multiple times across different retries. To guarantee the step
     * executes at most once, disable retries by returning
     * `{ shouldRetry: false }` from your retry strategy.
     */
    StepSemantics["AtMostOncePerRetry"] = "AT_MOST_ONCE_PER_RETRY";
    /**
     * At-least-once execution per retry attempt (default).
     *
     * @remarks
     * The step will execute at least once on each retry attempt. If the step succeeds
     * but the checkpoint fails (e.g., due to a sandbox crash), the step will re-execute
     * on replay. This is the safer default for operations that are idempotent or can
     * tolerate duplicate execution.
     */
    StepSemantics["AtLeastOncePerRetry"] = "AT_LEAST_ONCE_PER_RETRY";
})(exports.StepSemantics || (exports.StepSemantics = {}));
/**
 * Jitter strategy for retry delays to prevent thundering herd. Jitter reduces simultaneous retry attempts
 * by spreading retries out over a randomized delay interval.
 *
 * @public
 */
exports.JitterStrategy = void 0;
(function (JitterStrategy) {
    /** No jitter - use exact calculated delay */
    JitterStrategy["NONE"] = "NONE";
    /** Full jitter - random delay between 0 and calculated delay */
    JitterStrategy["FULL"] = "FULL";
    /** Half jitter - random delay between 50% and 100% of calculated delay */
    JitterStrategy["HALF"] = "HALF";
})(exports.JitterStrategy || (exports.JitterStrategy = {}));

/**
 * The status of a batch item
 * @public
 */
exports.BatchItemStatus = void 0;
(function (BatchItemStatus) {
    BatchItemStatus["SUCCEEDED"] = "SUCCEEDED";
    BatchItemStatus["FAILED"] = "FAILED";
    BatchItemStatus["STARTED"] = "STARTED";
})(exports.BatchItemStatus || (exports.BatchItemStatus = {}));

/**
 * A promise that defers execution until it's awaited or .then/.catch/.finally is called
 *
 * @public
 */
class DurablePromise {
    /**
     * The actual promise instance, created only when execution begins.
     * Starts as null and remains null until the DurablePromise is first awaited
     * or chained (.then/.catch/.finally). Once created, it holds the running
     * promise returned by the _executor function.
     *
     * Example lifecycle:
     * ```typescript
     * const dp = new DurablePromise(() => fetch('/api')); // _promise = null
     * console.log(dp.isExecuted); // false
     *
     * const result = await dp; // NOW _promise = fetch('/api') promise
     * console.log(dp.isExecuted); // true
     * ```
     *
     * This lazy initialization prevents the executor from running until needed.
     */
    _promise = null;
    /**
     * Function that contains the deferred execution logic.
     * This function is NOT called when the DurablePromise is created - it's only
     * executed when the promise is first awaited or chained (.then/.catch/.finally).
     *
     * Example:
     * ```typescript
     * const durablePromise = new DurablePromise(async () => {
     *   console.log("This runs ONLY when awaited, not when created");
     *   return await someAsyncOperation();
     * });
     *
     * // At this point, nothing has executed yet
     * console.log("Promise created but not executed");
     *
     * // NOW the executor function runs
     * const result = await durablePromise;
     * ```
     */
    _executor;
    /** Flag indicating whether the promise has been executed (awaited or chained) */
    _isExecuted = false;
    /**
     * Creates a new DurablePromise
     * @param executor - Function containing the deferred execution logic
     */
    constructor(executor) {
        this._executor = executor;
    }
    /**
     * Ensures the promise is executed, creating the actual promise if needed
     * @returns The underlying promise instance
     */
    ensureExecution() {
        if (!this._promise) {
            this._isExecuted = true;
            // Execute the promise
            this._promise = this._executor();
        }
        return this._promise;
    }
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise
     * Triggers execution if not already started
     */
    then(onfulfilled, onrejected) {
        return this.ensureExecution().then(onfulfilled, onrejected);
    }
    /**
     * Attaches a callback for only the rejection of the Promise
     * Triggers execution if not already started
     */
    catch(onrejected) {
        return this.ensureExecution().catch(onrejected);
    }
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected)
     * Triggers execution if not already started
     */
    finally(onfinally) {
        return this.ensureExecution().finally(onfinally);
    }
    /** Returns the string tag for the promise type */
    get [Symbol.toStringTag]() {
        return "DurablePromise";
    }
    /**
     * Check if the promise has been executed (awaited or had .then/.catch/.finally called)
     * @returns true if execution has started, false otherwise
     */
    get isExecuted() {
        return this._isExecuted;
    }
}

/**
 * Represents the lifecycle state of an operation in the durable execution system.
 * This is distinct from AWS SDK's OperationStatus (PENDING, SUCCEEDED, FAILED).
 */
var OperationLifecycleState;
(function (OperationLifecycleState) {
    /**
     * Operation is currently executing user code (step function, waitForCondition check)
     */
    OperationLifecycleState["EXECUTING"] = "EXECUTING";
    /**
     * Operation is waiting for retry timer to expire before re-executing user code
     */
    OperationLifecycleState["RETRY_WAITING"] = "RETRY_WAITING";
    /**
     * Operation is waiting for external event (timer, callback, invoke) but not awaited yet (phase 1)
     */
    OperationLifecycleState["IDLE_NOT_AWAITED"] = "IDLE_NOT_AWAITED";
    /**
     * Operation is waiting for external event and has been awaited (phase 2)
     */
    OperationLifecycleState["IDLE_AWAITED"] = "IDLE_AWAITED";
    /**
     * Operation has completed (success or permanent failure)
     */
    OperationLifecycleState["COMPLETED"] = "COMPLETED";
})(OperationLifecycleState || (OperationLifecycleState = {}));

/**
 * Converts a Duration object to total seconds
 * @param duration - Duration object with at least one time unit specified
 * @returns Total duration in seconds
 */
function durationToSeconds(duration) {
    const days = "days" in duration ? (duration.days ?? 0) : 0;
    const hours = "hours" in duration ? (duration.hours ?? 0) : 0;
    const minutes = "minutes" in duration ? (duration.minutes ?? 0) : 0;
    const seconds = "seconds" in duration ? (duration.seconds ?? 0) : 0;
    return days * 24 * 60 * 60 + hours * 60 * 60 + minutes * 60 + seconds;
}

/**
 * Terminates execution for unrecoverable errors and returns a never-resolving promise
 * @param context - The execution context containing the termination manager
 * @param error - The unrecoverable error that caused termination
 * @param stepIdentifier - The step name or ID for error messaging
 * @returns A never-resolving promise
 */
function terminateForUnrecoverableError(context, error, stepIdentifier) {
    context.terminationManager.terminate({
        reason: error.terminationReason,
        message: `Unrecoverable error in step ${stepIdentifier}: ${error.message}`,
    });
    return new Promise(() => { }); // Never-resolving promise
}

const safeStringify = (data) => {
    try {
        const seen = new WeakSet();
        return JSON.stringify(data, (key, value) => {
            if (typeof value === "object" && value !== null) {
                if (seen.has(value))
                    return "[Circular]";
                seen.add(value);
                // Handle Error objects by extracting their properties
                if (value instanceof Error) {
                    return {
                        ...value,
                        name: value.name,
                        message: value.message,
                        stack: value.stack,
                    };
                }
            }
            return value;
        }, 2);
    }
    catch {
        return "[Unable to stringify]";
    }
};

/* eslint-disable no-console */
const log = (emoji, message, data) => {
    if (process.env.DURABLE_VERBOSE_MODE === "true") {
        console.debug(`${emoji} ${message}`, data ? safeStringify(data) : "");
    }
};

const DEFAULT_CONFIG$1 = {
    maxAttempts: 3,
    initialDelay: { seconds: 5 },
    maxDelay: { minutes: 5 },
    backoffRate: 2,
    jitter: exports.JitterStrategy.FULL,
    retryableErrors: [/.*/], // By default, retry all errors
    retryableErrorTypes: [],
};
const applyJitter$1 = (delay, strategy) => {
    switch (strategy) {
        case exports.JitterStrategy.NONE:
            return delay;
        case exports.JitterStrategy.FULL:
            // Random between 0 and delay
            return Math.random() * delay;
        case exports.JitterStrategy.HALF:
            // Random between delay/2 and delay
            return delay / 2 + Math.random() * (delay / 2);
        default:
            return delay;
    }
};
/**
 * Creates a retry strategy function with exponential backoff and configurable jitter
 *
 * @param config - Configuration options for the retry strategy
 * @returns A function that determines whether to retry and calculates delay based on error and attempt count
 *
 * @remarks
 * The returned function takes an error and attempt count, and returns a {@link RetryDecision} indicating
 * whether to retry and the delay before the next attempt.
 *
 * **Delay Calculation:**
 * - Base delay = `initialDelay × backoffRate^(attemptsMade - 1)`
 * - Capped at `maxDelay`
 * - Jitter applied based on `jitter` strategy
 * - Final delay rounded to nearest second, minimum 1 second
 *
 * **Error Filtering:**
 * - If neither `retryableErrors` nor `retryableErrorTypes` is specified: all errors are retried
 * - If either is specified: only matching errors are retried
 * - If both are specified: errors matching either criteria are retried (OR logic)
 *
 * @example
 * ```typescript
 * // Basic usage with defaults (retry all errors, 3 attempts, exponential backoff)
 * const defaultRetry = createRetryStrategy();
 *
 * // Custom retry with more attempts and specific delays
 * const customRetry = createRetryStrategy({
 *   maxAttempts: 5,
 *   initialDelay: { seconds: 10 },
 *   maxDelay: { seconds: 60 },
 *   backoffRate: 2,
 *   jitter: JitterStrategy.HALF
 * });
 *
 * // Retry only specific error types
 * class TimeoutError extends Error {}
 * const typeBasedRetry = createRetryStrategy({
 *   retryableErrorTypes: [TimeoutError]
 * });
 *
 * // Retry only errors matching message patterns
 * const patternBasedRetry = createRetryStrategy({
 *   retryableErrors: [/timeout/i, /connection/i, "rate limit"]
 * });
 *
 * // Combine error types and patterns
 * const combinedRetry = createRetryStrategy({
 *   retryableErrorTypes: [TimeoutError],
 *   retryableErrors: [/network/i]
 * });
 *
 * // Use in step configuration
 * await context.step('api-call', async () => {
 *   return await callExternalAPI();
 * }, { retryStrategy: customRetry });
 * ```
 *
 * @see {@link RetryStrategyConfig} for configuration options
 * @see {@link JitterStrategy} for jitter strategies
 * @see {@link RetryDecision} for return type
 *
 * @public
 */
const createRetryStrategy = (config = {}) => {
    // Only apply default retryableErrors if user didn't specify either filter
    const shouldUseDefaultErrors = config.retryableErrors === undefined &&
        config.retryableErrorTypes === undefined;
    const finalConfig = {
        ...DEFAULT_CONFIG$1,
        ...config,
        retryableErrors: config.retryableErrors ?? (shouldUseDefaultErrors ? [/.*/] : []),
    };
    return (error, attemptsMade) => {
        // Check if we've exceeded max attempts
        if (attemptsMade >= finalConfig.maxAttempts) {
            return { shouldRetry: false };
        }
        // Check if error is retryable based on error message
        const isRetryableErrorMessage = finalConfig.retryableErrors.some((pattern) => {
            if (pattern instanceof RegExp) {
                return pattern.test(error.message);
            }
            return error.message.includes(pattern);
        });
        // Check if error is retryable based on error type
        const isRetryableErrorType = finalConfig.retryableErrorTypes.some((ErrorType) => error instanceof ErrorType);
        if (!isRetryableErrorMessage && !isRetryableErrorType) {
            return { shouldRetry: false };
        }
        // Calculate delay with exponential backoff
        const initialDelaySeconds = durationToSeconds(finalConfig.initialDelay);
        const maxDelaySeconds = durationToSeconds(finalConfig.maxDelay);
        const baseDelay = Math.min(initialDelaySeconds * Math.pow(finalConfig.backoffRate, attemptsMade - 1), maxDelaySeconds);
        // Apply jitter
        const delayWithJitter = applyJitter$1(baseDelay, finalConfig.jitter);
        // Ensure delay is an integer >= 1
        const finalDelay = Math.max(1, Math.round(delayWithJitter));
        return { shouldRetry: true, delay: { seconds: finalDelay } };
    };
};

/**
 * Pre-configured retry strategies for common use cases
 * @example
 * ```typescript
 * // Use default retry preset (3 attempts with exponential backoff)
 * await context.step('my-step', async () => {
 *   return await someOperation();
 * }, { retryStrategy: retryPresets.default });
 *
 * // Use no-retry preset (fail immediately on error)
 * await context.step('critical-step', async () => {
 *   return await criticalOperation();
 * }, { retryStrategy: retryPresets.noRetry });
 * ```
 *
 * @public
 */
const retryPresets = {
    /**
     * Default retry strategy with exponential backoff
     * - 6 total attempts (1 initial + 5 retries)
     * - Initial delay: 5 seconds
     * - Max delay: 60 seconds
     * - Backoff rate: 2x
     * - Jitter: FULL (randomizes delay between 0 and calculated delay)
     * - Total max wait time less than 150 seconds (2:30)
     */
    default: createRetryStrategy({
        maxAttempts: 6,
        initialDelay: { seconds: 5 },
        maxDelay: { seconds: 60 },
        backoffRate: 2,
        jitter: exports.JitterStrategy.FULL,
    }),
    /**
     * No retry strategy - fails immediately on first error
     * - 1 total attempt (no retries)
     */
    noRetry: createRetryStrategy({
        maxAttempts: 1,
    }),
};

/**
 * Error thrown when a step with AT_MOST_ONCE_PER_RETRY semantics was started but interrupted
 * before completion.
 * @public
 */
class StepInterruptedError extends Error {
    constructor(_stepId, _stepName) {
        super(`The step execution process was initiated but failed to reach completion due to an interruption.`);
        this.name = "StepInterruptedError";
    }
}

/**
 * Shared constants to avoid circular dependencies
 */
/**
 * Controls whether stack traces are stored in error objects
 * TODO: Accept this as configuration parameter in the future
 */
/**
 * Checkpoint manager termination cooldown in milliseconds
 * After the last operation completes, the checkpoint manager waits this duration
 * before terminating to allow for any final checkpoint operations
 */
const CHECKPOINT_TERMINATION_COOLDOWN_MS = 20;
/**
 * Maximum polling duration in milliseconds (15 minutes)
 * Used to cap setTimeout delays to prevent 32-bit signed integer overflow
 * and limit polling duration for long-running operations
 */
const MAX_POLL_DURATION_MS = 15 * 60 * 1000;

/**
 * Base class for all durable operation errors
 * @public
 */
class DurableOperationError extends Error {
    cause;
    errorData;
    stackTrace;
    constructor(message, cause, errorData) {
        super(message);
        this.name = this.constructor.name;
        this.cause = cause;
        this.errorData = errorData;
    }
    /**
     * Create DurableOperationError from ErrorObject (for reconstruction during replay)
     */
    static fromErrorObject(errorObject) {
        const cause = new Error(errorObject.ErrorMessage);
        cause.name = errorObject.ErrorType || "Error";
        cause.stack = errorObject.StackTrace?.join("\n");
        // Determine error type and create appropriate instance
        switch (errorObject.ErrorType) {
            case "StepError":
                return new StepError(errorObject.ErrorMessage || "Step failed", cause, errorObject.ErrorData);
            case "CallbackError":
                return new CallbackError(errorObject.ErrorMessage || "Callback failed", cause, errorObject.ErrorData);
            case "InvokeError":
                return new InvokeError(errorObject.ErrorMessage || "Invoke failed", cause, errorObject.ErrorData);
            case "ChildContextError":
                return new ChildContextError(errorObject.ErrorMessage || "Child context failed", cause, errorObject.ErrorData);
            case "WaitForConditionError":
                return new WaitForConditionError(errorObject.ErrorMessage || "Wait for condition failed", cause, errorObject.ErrorData);
            default:
                return new StepError(errorObject.ErrorMessage || "Unknown error", cause, errorObject.ErrorData);
        }
    }
    /**
     * Convert to ErrorObject for serialization
     */
    toErrorObject() {
        return {
            ErrorType: this.errorType,
            ErrorMessage: this.message,
            ErrorData: this.errorData,
            StackTrace: undefined,
        };
    }
}
/**
 * Error thrown when a step operation fails
 * @public
 */
class StepError extends DurableOperationError {
    errorType = "StepError";
    constructor(message, cause, errorData) {
        super(message || "Step failed", cause, errorData);
    }
}
/**
 * Error thrown when a callback operation fails
 * @public
 */
class CallbackError extends DurableOperationError {
    errorType = "CallbackError";
    constructor(message, cause, errorData) {
        super(message || "Callback failed", cause, errorData);
    }
}
/**
 * Error thrown when an invoke operation fails
 * @public
 */
class InvokeError extends DurableOperationError {
    errorType = "InvokeError";
    constructor(message, cause, errorData) {
        super(message || "Invoke failed", cause, errorData);
    }
}
/**
 * Error thrown when a child context operation fails
 * @public
 */
class ChildContextError extends DurableOperationError {
    errorType = "ChildContextError";
    constructor(message, cause, errorData) {
        super(message || "Child context failed", cause, errorData);
    }
}
/**
 * Error thrown when a wait for condition operation fails
 * @public
 */
class WaitForConditionError extends DurableOperationError {
    errorType = "WaitForConditionError";
    constructor(message, cause, errorData) {
        super(message || "Wait for condition failed", cause, errorData);
    }
}

/**
 * Default Serdes implementation using JSON.stringify and JSON.parse
 * Wrapped in Promise.resolve() to maintain async interface compatibility
 * Ignores context parameter since it uses inline JSON serialization
 *
 * Note: Uses 'any' type intentionally as this is a generic serializer that must
 * handle arbitrary JavaScript values. JSON.stringify/parse work with any type,
 * and using more restrictive types would break compatibility with the generic
 * Serdes<T> interface when T can be any type.
 *
 * @public
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const defaultSerdes = {
    serialize: async (
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    value, _context) => value !== undefined ? JSON.stringify(value) : undefined,
    deserialize: async (data, _context) => (data !== undefined ? JSON.parse(data) : undefined),
};
/**
 * Creates a Serdes for a specific class that preserves the class type. This implementation
 * is a basic class wrapper and does not support any complex class structures. If you need
 * custom serialization, it is recommended to create your own custom serdes.
 *
 * @param cls - The class constructor (must have no required parameters)
 * @returns A Serdes that maintains the class type during serialization/deserialization
 *
 * @example
 * ```typescript
 * class User {
 *   name: string = "";
 *   age: number = 0;
 *
 *   greet() {
 *     return `Hello, ${this.name}`;
 *   }
 * }
 *
 * const userSerdes = createClassSerdes(User);
 *
 * // In a durable function:
 * const user = await context.step("create-user", async () => {
 *   const u = new User();
 *   u.name = "Alice";
 *   u.age = 30;
 *   return u;
 * }, { serdes: userSerdes });
 *
 * console.log(user.greet()); // "Hello, Alice" - methods are preserved
 * ```
 *
 * Limitations:
 * - Class instances becomes plain objects and loses all class information
 * - Constructor must have no parameters
 * - Constructor side-effects will re-run during deserialization
 * - Private fields (#field) cannot be serialized
 * - Getters/setters are not preserved
 * - Nested class instances lose their prototype
 *
 * For classes with Date properties, use createClassSerdesWithDates instead.
 *
 * @beta
 */
function createClassSerdes(cls) {
    return {
        serialize: async (value, _context) => value !== undefined ? JSON.stringify(value) : undefined,
        deserialize: async (data, _context) => data !== undefined
            ? Object.assign(new cls(), JSON.parse(data))
            : undefined,
    };
}
/**
 * Creates a custom Serdes for a class with special handling for Date properties. This implementation
 * is a basic class wrapper and does not support any complex class structures. If you need
 * custom serialization, it is recommended to create your own custom serdes.
 *
 * @param cls - The class constructor (must have no required parameters)
 * @param dateProps - Array of property paths that should be converted to Date objects (supports nested paths like "metadata.createdAt")
 * @returns A Serdes that maintains the class type and converts specified properties to Date objects
 *
 * @example
 * ```typescript
 * class Article {
 *   title: string = "";
 *   createdAt: Date = new Date();
 *   metadata: {
 *     publishedAt: Date;
 *     updatedAt: Date;
 *   } = {
 *     publishedAt: new Date(),
 *     updatedAt: new Date()
 *   };
 *
 *   getAge() {
 *     return Date.now() - this.createdAt.getTime();
 *   }
 * }
 *
 * const articleSerdes = createClassSerdesWithDates(Article, [
 *   "createdAt",
 *   "metadata.publishedAt",
 *   "metadata.updatedAt"
 * ]);
 *
 * // In a durable function:
 * const article = await context.step("create-article", async () => {
 *   const a = new Article();
 *   a.title = "My Article";
 *   return a;
 * }, { serdes: articleSerdes });
 *
 * console.log(article.getAge()); // Works! Dates are properly restored
 * ```
 *
 * Limitations:
 * - Class instances becomes plain objects and loses all class information
 * - Constructor must have no parameters
 * - Constructor side-effects will re-run during deserialization
 * - Private fields (#field) cannot be serialized
 * - Getters/setters are not preserved
 * - Nested class instances lose their prototype
 *
 * For classes with Date properties, use createClassSerdesWithDates instead.
 *
 * @beta
 */
function createClassSerdesWithDates(cls, dateProps) {
    return {
        serialize: async (value, _context) => value !== undefined ? JSON.stringify(value) : undefined,
        deserialize: async (data, _context) => {
            if (data === undefined) {
                return undefined;
            }
            const parsed = JSON.parse(data);
            const instance = new cls();
            // Copy all properties from parsed object to the new instance
            Object.assign(instance, parsed);
            // Convert date strings back to Date objects (supports nested paths)
            for (const prop of dateProps) {
                const parts = prop.split(".");
                let obj = instance;
                // Navigate to parent of target property
                for (let i = 0; i < parts.length - 1; i++) {
                    const next = obj[parts[i]];
                    if (!next || typeof next !== "object")
                        break;
                    obj = next;
                }
                // Convert to Date if path exists
                const lastKey = parts[parts.length - 1];
                if (obj[lastKey]) {
                    obj[lastKey] = new Date(obj[lastKey]);
                }
            }
            return instance;
        },
    };
}

var TerminationReason;
(function (TerminationReason) {
    // Default termination reason
    TerminationReason["OPERATION_TERMINATED"] = "OPERATION_TERMINATED";
    // Retry-related reasons
    TerminationReason["RETRY_SCHEDULED"] = "RETRY_SCHEDULED";
    TerminationReason["RETRY_INTERRUPTED_STEP"] = "RETRY_INTERRUPTED_STEP";
    // Wait-related reasons
    TerminationReason["WAIT_SCHEDULED"] = "WAIT_SCHEDULED";
    // Callback-related reasons
    TerminationReason["CALLBACK_PENDING"] = "CALLBACK_PENDING";
    // Error-related reasons
    TerminationReason["CHECKPOINT_FAILED"] = "CHECKPOINT_FAILED";
    TerminationReason["SERDES_FAILED"] = "SERDES_FAILED";
    TerminationReason["CONTEXT_VALIDATION_ERROR"] = "CONTEXT_VALIDATION_ERROR";
    // Custom reason
    TerminationReason["CUSTOM"] = "CUSTOM";
})(TerminationReason || (TerminationReason = {}));

/**
 * Base class for all unrecoverable errors
 * Any error that inherits from this class indicates a fatal condition
 */
class UnrecoverableError extends Error {
    originalError;
    isUnrecoverable = true;
    constructor(message, originalError) {
        super(message);
        this.originalError = originalError;
        this.name = this.constructor.name;
        // Preserve the original stack trace if available
        if (originalError?.stack) {
            this.stack = `${this.stack}\nCaused by: ${originalError.stack}`;
        }
    }
}
/**
 * Base class for errors that make the entire execution unrecoverable
 * These errors indicate that the execution cannot continue and should be terminated completely
 */
class UnrecoverableExecutionError extends UnrecoverableError {
    isUnrecoverableExecution = true;
    constructor(message, originalError) {
        super(`[Unrecoverable Execution] ${message}`, originalError);
    }
}
/**
 * Base class for errors that make the current invocation unrecoverable
 * These errors indicate that the current Lambda invocation should be terminated,
 * but the execution might be able to continue with a new invocation
 */
class UnrecoverableInvocationError extends UnrecoverableError {
    isUnrecoverableInvocation = true;
    constructor(message, originalError) {
        super(`[Unrecoverable Invocation] ${message}`, originalError);
    }
}
/**
 * Type guard to check if an error is any kind of unrecoverable error
 */
function isUnrecoverableError(error) {
    return (error instanceof Error &&
        "isUnrecoverable" in error &&
        error.isUnrecoverable === true);
}
/**
 * Type guard to check if an error is an unrecoverable invocation error
 */
function isUnrecoverableInvocationError(error) {
    return (error instanceof Error &&
        "isUnrecoverableInvocation" in error &&
        error.isUnrecoverableInvocation === true);
}

/**
 * Error thrown when serdes operation fails and terminates Lambda invocation
 * This is used by withDurableExecution to terminate the Lambda when serdes fails
 */
class SerdesFailedError extends UnrecoverableInvocationError {
    terminationReason = TerminationReason.SERDES_FAILED;
    constructor(message, originalError) {
        super(message || "Serdes operation failed", originalError);
    }
}
/**
 * Utility function to safely execute serialization with proper error handling
 * Instead of throwing unrecoverable errors, this directly terminates execution
 */
async function safeSerialize(serdes, value, stepId, stepName, terminationManager, durableExecutionArn) {
    try {
        const context = {
            entityId: stepId,
            durableExecutionArn,
        };
        return await serdes.serialize(value, context);
    }
    catch (error) {
        const message = `Serialization failed for step ${stepName ? `"${stepName}" ` : ""}(${stepId}): ${error instanceof Error ? error.message : "Unknown serialization error"}`;
        log("💥", "Serialization failed - terminating execution:", {
            stepId,
            stepName,
            error: error instanceof Error ? error.message : String(error),
        });
        terminationManager.terminate({
            reason: TerminationReason.SERDES_FAILED,
            message: message,
        });
        // Return a never-resolving promise to ensure the execution doesn't continue
        return new Promise(() => { });
    }
}
/**
 * Utility function to safely execute deserialization with proper error handling
 * Instead of throwing unrecoverable errors, this directly terminates execution
 */
async function safeDeserialize(serdes, data, stepId, stepName, terminationManager, durableExecutionArn) {
    try {
        const context = {
            entityId: stepId,
            durableExecutionArn,
        };
        return await serdes.deserialize(data, context);
    }
    catch (error) {
        const message = `Deserialization failed for step ${stepName ? `"${stepName}" ` : ""}(${stepId}): ${error instanceof Error ? error.message : "Unknown deserialization error"}`;
        log("💥", "Deserialization failed - terminating execution:", {
            stepId,
            stepName,
            error: error instanceof Error ? error.message : String(error),
        });
        terminationManager.terminate({
            reason: TerminationReason.SERDES_FAILED,
            message: message,
        });
        // Return a never-resolving promise to ensure the execution doesn't continue
        return new Promise(() => { });
    }
}

const asyncLocalStorage = new async_hooks.AsyncLocalStorage();
const getActiveContext = () => {
    return asyncLocalStorage.getStore();
};
const runWithContext = (contextId, parentId, fn, attempt, durableExecutionMode) => {
    return asyncLocalStorage.run({ contextId, parentId, attempt, durableExecutionMode }, fn);
};
const validateContextUsage = (operationContextId, operationName, terminationManager) => {
    const contextId = operationContextId || "root";
    const activeContext = getActiveContext();
    if (!activeContext) {
        return;
    }
    if (activeContext.contextId !== contextId) {
        const errorMessage = `Context usage error in "${operationName}": You are using a parent or sibling context instead of the current child context. Expected context ID: "${activeContext.contextId}", but got: "${operationContextId}". When inside runInChildContext(), you must use the child context parameter, not the parent context.`;
        terminationManager.terminate({
            reason: TerminationReason.CONTEXT_VALIDATION_ERROR,
            message: errorMessage,
            error: new Error(errorMessage),
        });
        // Only call termination manager, don't throw or return promise
    }
};

function isErrorLike(obj) {
    return (obj instanceof Error ||
        (obj != null &&
            typeof obj === "object" &&
            "message" in obj &&
            "name" in obj));
}
function createErrorObjectFromError(error, data) {
    if (error instanceof DurableOperationError) {
        // Use DurableOperationError's built-in serialization
        const errorObject = error.toErrorObject();
        return errorObject;
    }
    if (isErrorLike(error)) {
        return {
            ErrorData: data,
            ErrorMessage: error.message,
            ErrorType: error.name,
            StackTrace: undefined,
        };
    }
    return {
        ErrorData: data,
        ErrorMessage: "Unknown error",
    };
}

/**
 * Error thrown when non-deterministic code is detected during replay
 */
class NonDeterministicExecutionError extends UnrecoverableExecutionError {
    terminationReason = TerminationReason.CUSTOM;
    constructor(message) {
        super(message);
        this.name = "NonDeterministicExecutionError";
    }
}

const validateReplayConsistency = (stepId, currentOperation, checkpointData, context) => {
    // Skip validation if no checkpoint data exists or if Type is undefined (first execution)
    if (!checkpointData || !checkpointData.Type) {
        return;
    }
    // Validate operation type
    if (checkpointData.Type !== currentOperation.type) {
        const error = new NonDeterministicExecutionError(`Non-deterministic execution detected: Operation type mismatch for step "${stepId}". ` +
            `Expected type "${checkpointData.Type}", but got "${currentOperation.type}". ` +
            `This indicates non-deterministic control flow in your workflow code.`);
        terminateForUnrecoverableError(context, error, stepId);
    }
    // Validate operation name (including undefined)
    if (checkpointData.Name !== currentOperation.name) {
        const error = new NonDeterministicExecutionError(`Non-deterministic execution detected: Operation name mismatch for step "${stepId}". ` +
            `Expected name "${checkpointData.Name ?? "undefined"}", but got "${currentOperation.name ?? "undefined"}". ` +
            `This indicates non-deterministic control flow in your workflow code.`);
        terminateForUnrecoverableError(context, error, stepId);
    }
    // Validate operation subtype
    if (checkpointData.SubType !== currentOperation.subType) {
        const error = new NonDeterministicExecutionError(`Non-deterministic execution detected: Operation subtype mismatch for step "${stepId}". ` +
            `Expected subtype "${checkpointData.SubType}", but got "${currentOperation.subType}". ` +
            `This indicates non-deterministic control flow in your workflow code.`);
        terminateForUnrecoverableError(context, error, stepId);
    }
};

const createStepHandler = (context, checkpoint, parentContext, createStepId, logger, parentId) => {
    return (nameOrFn, fnOrOptions, maybeOptions) => {
        let name;
        let fn;
        let options;
        if (typeof nameOrFn === "string" || nameOrFn === undefined) {
            name = nameOrFn;
            fn = fnOrOptions;
            options = maybeOptions;
        }
        else {
            fn = nameOrFn;
            options = fnOrOptions;
        }
        const stepId = createStepId();
        const semantics = options?.semantics || exports.StepSemantics.AtLeastOncePerRetry;
        const serdes = options?.serdes || defaultSerdes;
        // Phase 1: Execute step
        const phase1Promise = (async () => {
            let stepData = context.getStepData(stepId);
            validateReplayConsistency(stepId, { type: clientLambda.OperationType.STEP, name, subType: exports.OperationSubType.STEP }, stepData, context);
            // Check if already completed
            if (stepData?.Status === clientLambda.OperationStatus.SUCCEEDED) {
                log("⏭️", "Step already completed:", { stepId });
                checkpoint.markOperationState(stepId, OperationLifecycleState.COMPLETED, {
                    metadata: {
                        stepId,
                        name,
                        type: clientLambda.OperationType.STEP,
                        subType: exports.OperationSubType.STEP,
                        parentId,
                    },
                });
                return await safeDeserialize(serdes, stepData.StepDetails?.Result, stepId, name, context.terminationManager, context.durableExecutionArn);
            }
            // Check if already failed
            if (stepData?.Status === clientLambda.OperationStatus.FAILED) {
                checkpoint.markOperationState(stepId, OperationLifecycleState.COMPLETED, {
                    metadata: {
                        stepId,
                        name,
                        type: clientLambda.OperationType.STEP,
                        subType: exports.OperationSubType.STEP,
                        parentId,
                    },
                });
                if (stepData.StepDetails?.Error) {
                    throw DurableOperationError.fromErrorObject(stepData.StepDetails.Error);
                }
                throw new StepError("Unknown error");
            }
            // Check if pending retry
            if (stepData?.Status === clientLambda.OperationStatus.PENDING) {
                checkpoint.markOperationState(stepId, OperationLifecycleState.RETRY_WAITING, {
                    metadata: {
                        stepId,
                        name,
                        type: clientLambda.OperationType.STEP,
                        subType: exports.OperationSubType.STEP,
                        parentId,
                    },
                    endTimestamp: stepData.StepDetails?.NextAttemptTimestamp,
                });
                return (async () => {
                    await checkpoint.waitForRetryTimer(stepId);
                    stepData = context.getStepData(stepId);
                    return await executeStepLogic();
                })();
            }
            // Check for interrupted step with AT_MOST_ONCE_PER_RETRY
            if (stepData?.Status === clientLambda.OperationStatus.STARTED &&
                semantics === exports.StepSemantics.AtMostOncePerRetry) {
                const error = new StepInterruptedError(stepId, name);
                const currentAttempt = (stepData.StepDetails?.Attempt || 0) + 1;
                const retryDecision = options?.retryStrategy?.(error, currentAttempt) ??
                    retryPresets.default(error, currentAttempt);
                if (!retryDecision.shouldRetry) {
                    await checkpoint.checkpoint(stepId, {
                        Id: stepId,
                        ParentId: parentId,
                        Action: clientLambda.OperationAction.FAIL,
                        SubType: exports.OperationSubType.STEP,
                        Type: clientLambda.OperationType.STEP,
                        Error: createErrorObjectFromError(error),
                        Name: name,
                    });
                    checkpoint.markOperationState(stepId, OperationLifecycleState.COMPLETED);
                    throw DurableOperationError.fromErrorObject(createErrorObjectFromError(error));
                }
                await checkpoint.checkpoint(stepId, {
                    Id: stepId,
                    ParentId: parentId,
                    Action: clientLambda.OperationAction.RETRY,
                    SubType: exports.OperationSubType.STEP,
                    Type: clientLambda.OperationType.STEP,
                    Error: createErrorObjectFromError(error),
                    Name: name,
                    StepOptions: {
                        NextAttemptDelaySeconds: retryDecision.delay
                            ? durationToSeconds(retryDecision.delay)
                            : 1,
                    },
                });
                checkpoint.markOperationState(stepId, OperationLifecycleState.RETRY_WAITING, {
                    metadata: {
                        stepId,
                        name,
                        type: clientLambda.OperationType.STEP,
                        subType: exports.OperationSubType.STEP,
                        parentId,
                    },
                    endTimestamp: context.getStepData(stepId)?.StepDetails?.NextAttemptTimestamp,
                });
                return (async () => {
                    await checkpoint.waitForRetryTimer(stepId);
                    stepData = context.getStepData(stepId);
                    return await executeStepLogic();
                })();
            }
            return await executeStepLogic();
            async function executeStepLogic() {
                stepData = context.getStepData(stepId);
                if (stepData?.Status !== clientLambda.OperationStatus.STARTED) {
                    if (semantics === exports.StepSemantics.AtMostOncePerRetry) {
                        await checkpoint.checkpoint(stepId, {
                            Id: stepId,
                            ParentId: parentId,
                            Action: clientLambda.OperationAction.START,
                            SubType: exports.OperationSubType.STEP,
                            Type: clientLambda.OperationType.STEP,
                            Name: name,
                        });
                    }
                    else {
                        checkpoint.checkpoint(stepId, {
                            Id: stepId,
                            ParentId: parentId,
                            Action: clientLambda.OperationAction.START,
                            SubType: exports.OperationSubType.STEP,
                            Type: clientLambda.OperationType.STEP,
                            Name: name,
                        });
                    }
                }
                try {
                    stepData = context.getStepData(stepId);
                    const currentAttempt = stepData?.StepDetails?.Attempt || 0;
                    const stepContext = { logger };
                    // Mark operation as EXECUTING
                    checkpoint.markOperationState(stepId, OperationLifecycleState.EXECUTING, {
                        metadata: {
                            stepId,
                            name,
                            type: clientLambda.OperationType.STEP,
                            subType: exports.OperationSubType.STEP,
                            parentId,
                        },
                    });
                    let result;
                    result = await runWithContext(stepId, parentId, () => fn(stepContext), currentAttempt + 1, DurableExecutionMode.ExecutionMode);
                    const serializedResult = await safeSerialize(serdes, result, stepId, name, context.terminationManager, context.durableExecutionArn);
                    await checkpoint.checkpoint(stepId, {
                        Id: stepId,
                        ParentId: parentId,
                        Action: clientLambda.OperationAction.SUCCEED,
                        SubType: exports.OperationSubType.STEP,
                        Type: clientLambda.OperationType.STEP,
                        Payload: serializedResult,
                        Name: name,
                    });
                    checkpoint.markOperationState(stepId, OperationLifecycleState.COMPLETED);
                    return await safeDeserialize(serdes, serializedResult, stepId, name, context.terminationManager, context.durableExecutionArn);
                }
                catch (error) {
                    if (isUnrecoverableError(error)) {
                        return terminateForUnrecoverableError(context, error, name || stepId);
                    }
                    stepData = context.getStepData(stepId);
                    const currentAttempt = (stepData?.StepDetails?.Attempt || 0) + 1;
                    const retryDecision = options?.retryStrategy?.(error instanceof Error ? error : new Error("Unknown Error"), currentAttempt) ??
                        retryPresets.default(error instanceof Error ? error : new Error("Unknown Error"), currentAttempt);
                    if (!retryDecision.shouldRetry) {
                        await checkpoint.checkpoint(stepId, {
                            Id: stepId,
                            ParentId: parentId,
                            Action: clientLambda.OperationAction.FAIL,
                            SubType: exports.OperationSubType.STEP,
                            Type: clientLambda.OperationType.STEP,
                            Error: createErrorObjectFromError(error),
                            Name: name,
                        });
                        checkpoint.markOperationState(stepId, OperationLifecycleState.COMPLETED);
                        throw DurableOperationError.fromErrorObject(createErrorObjectFromError(error));
                    }
                    await checkpoint.checkpoint(stepId, {
                        Id: stepId,
                        ParentId: parentId,
                        Action: clientLambda.OperationAction.RETRY,
                        SubType: exports.OperationSubType.STEP,
                        Type: clientLambda.OperationType.STEP,
                        Error: createErrorObjectFromError(error),
                        Name: name,
                        StepOptions: {
                            NextAttemptDelaySeconds: retryDecision.delay
                                ? durationToSeconds(retryDecision.delay)
                                : 1,
                        },
                    });
                    checkpoint.markOperationState(stepId, OperationLifecycleState.RETRY_WAITING, {
                        metadata: {
                            stepId,
                            name,
                            type: clientLambda.OperationType.STEP,
                            subType: exports.OperationSubType.STEP,
                            parentId,
                        },
                        endTimestamp: context.getStepData(stepId)?.StepDetails?.NextAttemptTimestamp,
                    });
                    await checkpoint.waitForRetryTimer(stepId);
                    return await executeStepLogic();
                }
            }
        })();
        phase1Promise.catch(() => { });
        return new DurablePromise(async () => {
            checkpoint.markOperationAwaited(stepId);
            return await phase1Promise;
        });
    };
};

const createInvokeHandler = (context, checkpoint, createStepId, parentId, checkAndUpdateReplayMode) => {
    function invokeHandler(nameOrFuncId, funcIdOrInput, inputOrConfig, maybeConfig) {
        const isNameFirst = typeof funcIdOrInput === "string";
        const name = isNameFirst ? nameOrFuncId : undefined;
        const funcId = isNameFirst ? funcIdOrInput : nameOrFuncId;
        const input = isNameFirst
            ? inputOrConfig
            : funcIdOrInput;
        const config = isNameFirst
            ? maybeConfig
            : inputOrConfig;
        const stepId = createStepId();
        // Phase 1: Start invoke operation
        let isCompleted = false;
        const phase1Promise = (async () => {
            log("🔗", "Invoke phase 1:", { stepId, name: name || funcId });
            let stepData = context.getStepData(stepId);
            // Validate replay consistency
            validateReplayConsistency(stepId, {
                type: clientLambda.OperationType.CHAINED_INVOKE,
                name,
                subType: exports.OperationSubType.CHAINED_INVOKE,
            }, stepData, context);
            // Check if already completed
            if (stepData?.Status === clientLambda.OperationStatus.SUCCEEDED) {
                log("⏭️", "Invoke already completed:", { stepId });
                checkAndUpdateReplayMode?.();
                checkpoint.markOperationState(stepId, OperationLifecycleState.COMPLETED, {
                    metadata: {
                        stepId,
                        name,
                        type: clientLambda.OperationType.CHAINED_INVOKE,
                        subType: exports.OperationSubType.CHAINED_INVOKE,
                        parentId,
                    },
                });
                isCompleted = true;
                return;
            }
            // Check if already failed
            if (stepData?.Status === clientLambda.OperationStatus.FAILED ||
                stepData?.Status === clientLambda.OperationStatus.TIMED_OUT ||
                stepData?.Status === clientLambda.OperationStatus.STOPPED) {
                log("❌", "Invoke already failed:", { stepId });
                checkpoint.markOperationState(stepId, OperationLifecycleState.COMPLETED, {
                    metadata: {
                        stepId,
                        name,
                        type: clientLambda.OperationType.CHAINED_INVOKE,
                        subType: exports.OperationSubType.CHAINED_INVOKE,
                        parentId,
                    },
                });
                isCompleted = true;
                return;
            }
            // Start invoke if not already started
            if (!stepData) {
                const serializedPayload = await safeSerialize(config?.payloadSerdes || defaultSerdes, input, stepId, name, context.terminationManager, context.durableExecutionArn);
                await checkpoint.checkpoint(stepId, {
                    Id: stepId,
                    ParentId: parentId,
                    Action: clientLambda.OperationAction.START,
                    SubType: exports.OperationSubType.CHAINED_INVOKE,
                    Type: clientLambda.OperationType.CHAINED_INVOKE,
                    Name: name,
                    Payload: serializedPayload,
                    ChainedInvokeOptions: {
                        FunctionName: funcId,
                        ...(config?.tenantId && { TenantId: config.tenantId }),
                    },
                });
            }
            // Mark as IDLE_NOT_AWAITED
            checkpoint.markOperationState(stepId, OperationLifecycleState.IDLE_NOT_AWAITED, {
                metadata: {
                    stepId,
                    name,
                    type: clientLambda.OperationType.CHAINED_INVOKE,
                    subType: exports.OperationSubType.CHAINED_INVOKE,
                    parentId,
                },
            });
            log("✅", "Invoke phase 1 complete:", { stepId });
        })();
        phase1Promise.catch(() => { });
        // Phase 2: Wait for completion
        return new DurablePromise(async () => {
            await phase1Promise;
            if (isCompleted) {
                const stepData = context.getStepData(stepId);
                if (stepData?.Status === clientLambda.OperationStatus.SUCCEEDED) {
                    const invokeDetails = stepData.ChainedInvokeDetails;
                    return await safeDeserialize(config?.resultSerdes || defaultSerdes, invokeDetails?.Result, stepId, name, context.terminationManager, context.durableExecutionArn);
                }
                // Handle failure
                const invokeDetails = stepData?.ChainedInvokeDetails;
                if (invokeDetails?.Error) {
                    throw new InvokeError(invokeDetails.Error.ErrorMessage || "Invoke failed", invokeDetails.Error.ErrorMessage
                        ? new Error(invokeDetails.Error.ErrorMessage)
                        : undefined, invokeDetails.Error.ErrorData);
                }
                else {
                    throw new InvokeError("Invoke failed");
                }
            }
            log("🔗", "Invoke phase 2:", { stepId });
            checkpoint.markOperationAwaited(stepId);
            await checkpoint.waitForStatusChange(stepId);
            const stepData = context.getStepData(stepId);
            if (stepData?.Status === clientLambda.OperationStatus.SUCCEEDED) {
                log("✅", "Invoke completed:", { stepId });
                checkAndUpdateReplayMode?.();
                checkpoint.markOperationState(stepId, OperationLifecycleState.COMPLETED);
                const invokeDetails = stepData.ChainedInvokeDetails;
                return await safeDeserialize(config?.resultSerdes || defaultSerdes, invokeDetails?.Result, stepId, name, context.terminationManager, context.durableExecutionArn);
            }
            // Handle failure
            log("❌", "Invoke failed:", { stepId, status: stepData?.Status });
            checkpoint.markOperationState(stepId, OperationLifecycleState.COMPLETED);
            const invokeDetails = stepData?.ChainedInvokeDetails;
            if (invokeDetails?.Error) {
                throw new InvokeError(invokeDetails.Error.ErrorMessage || "Invoke failed", invokeDetails.Error.ErrorMessage
                    ? new Error(invokeDetails.Error.ErrorMessage)
                    : undefined, invokeDetails.Error.ErrorData);
            }
            else {
                throw new InvokeError("Invoke failed");
            }
        });
    }
    return invokeHandler;
};

// Checkpoint size limit in bytes (256KB)
const CHECKPOINT_SIZE_LIMIT = 256 * 1024;
const determineChildReplayMode = (context, stepId) => {
    const stepData = context.getStepData(stepId);
    if (!stepData) {
        return DurableExecutionMode.ExecutionMode;
    }
    if (stepData.Status === clientLambda.OperationStatus.SUCCEEDED &&
        stepData.ContextDetails?.ReplayChildren) {
        return DurableExecutionMode.ReplaySucceededContext;
    }
    if (stepData.Status === clientLambda.OperationStatus.SUCCEEDED ||
        stepData.Status === clientLambda.OperationStatus.FAILED) {
        return DurableExecutionMode.ReplayMode;
    }
    return DurableExecutionMode.ExecutionMode;
};
const createRunInChildContextHandler = (context, checkpoint, parentContext, createStepId, getParentLogger, createChildContext, parentId) => {
    return (nameOrFn, fnOrOptions, maybeOptions) => {
        let name;
        let fn;
        let options;
        if (typeof nameOrFn === "string" || nameOrFn === undefined) {
            name = nameOrFn;
            fn = fnOrOptions;
            options = maybeOptions;
        }
        else {
            fn = nameOrFn;
            options = fnOrOptions;
        }
        const entityId = createStepId();
        log("🔄", "Running child context:", {
            entityId,
            name,
        });
        const stepData = context.getStepData(entityId);
        // Validate replay consistency
        validateReplayConsistency(entityId, {
            type: clientLambda.OperationType.CONTEXT,
            name,
            subType: options?.subType ||
                exports.OperationSubType.RUN_IN_CHILD_CONTEXT,
        }, stepData, context);
        // Two-phase execution: Phase 1 starts immediately, Phase 2 returns result when awaited
        let phase1Result;
        let phase1Error;
        // Phase 1: Start execution immediately and capture result/error
        const phase1Promise = (async () => {
            const currentStepData = context.getStepData(entityId);
            // If already completed, return cached result
            if (currentStepData?.Status === clientLambda.OperationStatus.SUCCEEDED ||
                currentStepData?.Status === clientLambda.OperationStatus.FAILED) {
                // Mark this run-in-child-context as finished to prevent descendant operations
                checkpoint.markAncestorFinished(entityId);
                return handleCompletedChildContext(context, parentContext, entityId, name, fn, options, getParentLogger, createChildContext);
            }
            // Execute if not completed
            return executeChildContext(context, checkpoint, parentContext, entityId, name, fn, options, getParentLogger, createChildContext, parentId);
        })()
            .then((result) => {
            phase1Result = result;
        })
            .catch((error) => {
            phase1Error = error;
        });
        // Phase 2: Return DurablePromise that returns Phase 1 result when awaited
        return new DurablePromise(async () => {
            await phase1Promise;
            if (phase1Error !== undefined) {
                throw phase1Error;
            }
            return phase1Result;
        });
    };
};
const handleCompletedChildContext = async (context, parentContext, entityId, stepName, fn, options, getParentLogger, createChildContext) => {
    const serdes = options?.serdes || defaultSerdes;
    const stepData = context.getStepData(entityId);
    const result = stepData?.ContextDetails?.Result;
    // Handle failed child context
    if (stepData?.Status === clientLambda.OperationStatus.FAILED) {
        if (stepData.ContextDetails?.Error) {
            const originalError = DurableOperationError.fromErrorObject(stepData.ContextDetails.Error);
            throw new ChildContextError(originalError.message, originalError);
        }
        else {
            throw new ChildContextError("Child context failed");
        }
    }
    // Check if we need to replay children due to large payload
    if (stepData?.ContextDetails?.ReplayChildren) {
        log("🔄", "ReplayChildren mode: Re-executing child context due to large payload:", { entityId, stepName });
        // Re-execute the child context to reconstruct the result
        const durableChildContext = createChildContext(context, parentContext, DurableExecutionMode.ReplaySucceededContext, getParentLogger(), entityId, undefined, entityId);
        return await runWithContext(entityId, entityId, () => fn(durableChildContext));
    }
    log("⏭️", "Child context already finished, returning cached result:", {
        entityId,
    });
    return await safeDeserialize(serdes, result, entityId, stepName, context.terminationManager, context.durableExecutionArn);
};
const executeChildContext = async (context, checkpoint, parentContext, entityId, name, fn, options, getParentLogger, createChildContext, parentId) => {
    const serdes = options?.serdes || defaultSerdes;
    // Checkpoint at start if not already started (fire-and-forget for performance)
    if (context.getStepData(entityId) === undefined) {
        const subType = options?.subType || exports.OperationSubType.RUN_IN_CHILD_CONTEXT;
        checkpoint.checkpoint(entityId, {
            Id: entityId,
            ParentId: parentId,
            Action: clientLambda.OperationAction.START,
            SubType: subType,
            Type: clientLambda.OperationType.CONTEXT,
            Name: name,
        });
    }
    const childReplayMode = determineChildReplayMode(context, entityId);
    // Create a child context with the entity ID as prefix
    const durableChildContext = createChildContext(context, parentContext, childReplayMode, getParentLogger(), entityId, undefined, entityId);
    try {
        // Execute the child context function with context tracking
        const result = await runWithContext(entityId, parentId, () => fn(durableChildContext), undefined, childReplayMode);
        // Serialize the result for consistency
        const serializedResult = await safeSerialize(serdes, result, entityId, name, context.terminationManager, context.durableExecutionArn);
        // Check if payload is too large for adaptive mode
        let payloadToCheckpoint = serializedResult;
        let replayChildren = false;
        if (serializedResult &&
            Buffer.byteLength(serializedResult, "utf8") > CHECKPOINT_SIZE_LIMIT) {
            replayChildren = true;
            // Use summary generator if provided, otherwise use empty string
            if (options?.summaryGenerator) {
                payloadToCheckpoint = options.summaryGenerator(result);
            }
            else {
                payloadToCheckpoint = "";
            }
            log("📦", "Large payload detected, using ReplayChildren mode:", {
                entityId,
                name,
                payloadSize: Buffer.byteLength(serializedResult, "utf8"),
                limit: CHECKPOINT_SIZE_LIMIT,
            });
        }
        // Mark this run-in-child-context as finished to prevent descendant operations
        checkpoint.markAncestorFinished(entityId);
        const subType = options?.subType || exports.OperationSubType.RUN_IN_CHILD_CONTEXT;
        checkpoint.checkpoint(entityId, {
            Id: entityId,
            ParentId: parentId,
            Action: clientLambda.OperationAction.SUCCEED,
            SubType: subType,
            Type: clientLambda.OperationType.CONTEXT,
            Payload: payloadToCheckpoint,
            ContextOptions: replayChildren ? { ReplayChildren: true } : undefined,
            Name: name,
        });
        log("✅", "Child context completed successfully:", {
            entityId,
            name,
        });
        return result;
    }
    catch (error) {
        log("❌", "Child context failed:", {
            entityId,
            name,
            error,
        });
        // Mark this run-in-child-context as finished to prevent descendant operations
        checkpoint.markAncestorFinished(entityId);
        // Always checkpoint failures
        const subType = options?.subType || exports.OperationSubType.RUN_IN_CHILD_CONTEXT;
        checkpoint.checkpoint(entityId, {
            Id: entityId,
            ParentId: parentId,
            Action: clientLambda.OperationAction.FAIL,
            SubType: subType,
            Type: clientLambda.OperationType.CONTEXT,
            Error: createErrorObjectFromError(error),
            Name: name,
        });
        // Reconstruct error from ErrorObject for deterministic behavior
        const errorObject = createErrorObjectFromError(error);
        const reconstructedError = DurableOperationError.fromErrorObject(errorObject);
        throw new ChildContextError(reconstructedError.message, reconstructedError);
    }
};

const createWaitHandler = (context, checkpoint, createStepId, parentId, checkAndUpdateReplayMode) => {
    function waitHandler(nameOrDuration, duration) {
        const isNameFirst = typeof nameOrDuration === "string";
        const actualName = isNameFirst ? nameOrDuration : undefined;
        const actualDuration = isNameFirst ? duration : nameOrDuration;
        const actualSeconds = durationToSeconds(actualDuration);
        const stepId = createStepId();
        // Phase 1: Start wait operation
        let isCompleted = false;
        const phase1Promise = (async () => {
            log("⏲️", "Wait phase 1:", {
                stepId,
                name: actualName,
                seconds: actualSeconds,
            });
            let stepData = context.getStepData(stepId);
            // Validate replay consistency
            validateReplayConsistency(stepId, {
                type: clientLambda.OperationType.WAIT,
                name: actualName,
                subType: exports.OperationSubType.WAIT,
            }, stepData, context);
            // Check if already completed
            if (stepData?.Status === clientLambda.OperationStatus.SUCCEEDED) {
                log("⏭️", "Wait already completed:", { stepId });
                checkAndUpdateReplayMode?.();
                // Mark as completed
                checkpoint.markOperationState(stepId, OperationLifecycleState.COMPLETED, {
                    metadata: {
                        stepId,
                        name: actualName,
                        type: clientLambda.OperationType.WAIT,
                        subType: exports.OperationSubType.WAIT,
                        parentId,
                    },
                });
                isCompleted = true;
                return;
            }
            // Start wait if not already started
            if (!stepData) {
                await checkpoint.checkpoint(stepId, {
                    Id: stepId,
                    ParentId: parentId,
                    Action: clientLambda.OperationAction.START,
                    SubType: exports.OperationSubType.WAIT,
                    Type: clientLambda.OperationType.WAIT,
                    Name: actualName,
                    WaitOptions: {
                        WaitSeconds: actualSeconds,
                    },
                });
            }
            // Refresh stepData after checkpoint
            stepData = context.getStepData(stepId);
            // Mark as IDLE_NOT_AWAITED (phase 1 complete, not awaited yet)
            checkpoint.markOperationState(stepId, OperationLifecycleState.IDLE_NOT_AWAITED, {
                metadata: {
                    stepId,
                    name: actualName,
                    type: clientLambda.OperationType.WAIT,
                    subType: exports.OperationSubType.WAIT,
                    parentId,
                },
                endTimestamp: stepData?.WaitDetails?.ScheduledEndTimestamp,
            });
            log("✅", "Wait phase 1 complete:", { stepId });
        })();
        // Prevent unhandled rejection
        phase1Promise.catch(() => { });
        // Phase 2: Wait for completion
        return new DurablePromise(async () => {
            // Wait for phase 1
            await phase1Promise;
            // If already completed in phase 1, skip phase 2
            if (isCompleted) {
                return;
            }
            log("⏲️", "Wait phase 2:", { stepId });
            // Mark as awaited
            checkpoint.markOperationAwaited(stepId);
            // Wait for status change
            await checkpoint.waitForStatusChange(stepId);
            // Check final status
            const stepData = context.getStepData(stepId);
            if (stepData?.Status === clientLambda.OperationStatus.SUCCEEDED) {
                log("✅", "Wait completed:", { stepId });
                checkAndUpdateReplayMode?.();
                // Mark as completed
                checkpoint.markOperationState(stepId, OperationLifecycleState.COMPLETED);
                return;
            }
            // Should not reach here, but handle gracefully
            log("⚠️", "Wait ended with unexpected status:", {
                stepId,
                status: stepData?.Status,
            });
        });
    }
    return waitHandler;
};

const createWaitForConditionHandler = (context, checkpoint, createStepId, logger, parentId) => {
    return (nameOrCheck, checkOrConfig, maybeConfig) => {
        let name;
        let check;
        let config;
        if (typeof nameOrCheck === "string" || nameOrCheck === undefined) {
            name = nameOrCheck;
            check = checkOrConfig;
            config = maybeConfig;
        }
        else {
            check = nameOrCheck;
            config = checkOrConfig;
        }
        if (!config?.waitStrategy || config.initialState === undefined) {
            throw new Error("waitForCondition requires config with waitStrategy and initialState");
        }
        const stepId = createStepId();
        const serdes = config.serdes || defaultSerdes;
        const phase1Promise = (async () => {
            let stepData = context.getStepData(stepId);
            // Check if already completed
            if (stepData?.Status === clientLambda.OperationStatus.SUCCEEDED) {
                log("⏭️", "WaitForCondition already completed:", { stepId });
                checkpoint.markOperationState(stepId, OperationLifecycleState.COMPLETED, {
                    metadata: {
                        stepId,
                        name,
                        type: clientLambda.OperationType.STEP,
                        subType: exports.OperationSubType.WAIT_FOR_CONDITION,
                        parentId,
                    },
                });
                return await safeDeserialize(serdes, stepData.StepDetails?.Result, stepId, name, context.terminationManager, context.durableExecutionArn);
            }
            // Check if already failed
            if (stepData?.Status === clientLambda.OperationStatus.FAILED) {
                checkpoint.markOperationState(stepId, OperationLifecycleState.COMPLETED, {
                    metadata: {
                        stepId,
                        name,
                        type: clientLambda.OperationType.STEP,
                        subType: exports.OperationSubType.WAIT_FOR_CONDITION,
                        parentId,
                    },
                });
                if (stepData.StepDetails?.Error) {
                    throw DurableOperationError.fromErrorObject(stepData.StepDetails.Error);
                }
                throw new WaitForConditionError("waitForCondition failed");
            }
            // Check if pending retry
            if (stepData?.Status === clientLambda.OperationStatus.PENDING) {
                checkpoint.markOperationState(stepId, OperationLifecycleState.RETRY_WAITING, {
                    metadata: {
                        stepId,
                        name,
                        type: clientLambda.OperationType.STEP,
                        subType: exports.OperationSubType.WAIT_FOR_CONDITION,
                        parentId,
                    },
                    endTimestamp: stepData.StepDetails?.NextAttemptTimestamp,
                });
                return (async () => {
                    await checkpoint.waitForRetryTimer(stepId);
                    stepData = context.getStepData(stepId);
                    return await executeCheckLogic();
                })();
            }
            return await executeCheckLogic();
            async function executeCheckLogic() {
                stepData = context.getStepData(stepId);
                // Get current state
                let currentState;
                if (stepData?.Status === clientLambda.OperationStatus.STARTED ||
                    stepData?.Status === clientLambda.OperationStatus.READY) {
                    const checkpointData = stepData.StepDetails?.Result;
                    if (checkpointData) {
                        try {
                            const serdesContext = {
                                entityId: stepId,
                                durableExecutionArn: context.durableExecutionArn,
                            };
                            currentState = await serdes.deserialize(checkpointData, serdesContext);
                        }
                        catch {
                            currentState = config.initialState;
                        }
                    }
                    else {
                        currentState = config.initialState;
                    }
                }
                else {
                    currentState = config.initialState;
                }
                const currentAttempt = (stepData?.StepDetails?.Attempt ?? 0) + 1;
                // Checkpoint START if not already started
                if (stepData?.Status !== clientLambda.OperationStatus.STARTED) {
                    checkpoint.checkpoint(stepId, {
                        Id: stepId,
                        ParentId: parentId,
                        Action: clientLambda.OperationAction.START,
                        SubType: exports.OperationSubType.WAIT_FOR_CONDITION,
                        Type: clientLambda.OperationType.STEP,
                        Name: name,
                    });
                }
                try {
                    const waitForConditionContext = {
                        logger,
                    };
                    // Mark operation as EXECUTING
                    checkpoint.markOperationState(stepId, OperationLifecycleState.EXECUTING, {
                        metadata: {
                            stepId,
                            name,
                            type: clientLambda.OperationType.STEP,
                            subType: exports.OperationSubType.WAIT_FOR_CONDITION,
                            parentId,
                        },
                    });
                    const newState = await runWithContext(stepId, parentId, () => check(currentState, waitForConditionContext), currentAttempt, DurableExecutionMode.ExecutionMode);
                    const serializedState = await safeSerialize(serdes, newState, stepId, name, context.terminationManager, context.durableExecutionArn);
                    const deserializedState = await safeDeserialize(serdes, serializedState, stepId, name, context.terminationManager, context.durableExecutionArn);
                    const decision = config.waitStrategy(deserializedState, currentAttempt);
                    if (!decision.shouldContinue) {
                        await checkpoint.checkpoint(stepId, {
                            Id: stepId,
                            ParentId: parentId,
                            Action: clientLambda.OperationAction.SUCCEED,
                            SubType: exports.OperationSubType.WAIT_FOR_CONDITION,
                            Type: clientLambda.OperationType.STEP,
                            Payload: serializedState,
                            Name: name,
                        });
                        checkpoint.markOperationState(stepId, OperationLifecycleState.COMPLETED);
                        return deserializedState;
                    }
                    await checkpoint.checkpoint(stepId, {
                        Id: stepId,
                        ParentId: parentId,
                        Action: clientLambda.OperationAction.RETRY,
                        SubType: exports.OperationSubType.WAIT_FOR_CONDITION,
                        Type: clientLambda.OperationType.STEP,
                        Payload: serializedState,
                        Name: name,
                        StepOptions: {
                            NextAttemptDelaySeconds: durationToSeconds(decision.delay),
                        },
                    });
                    checkpoint.markOperationState(stepId, OperationLifecycleState.RETRY_WAITING, {
                        metadata: {
                            stepId,
                            name,
                            type: clientLambda.OperationType.STEP,
                            subType: exports.OperationSubType.WAIT_FOR_CONDITION,
                            parentId,
                        },
                        endTimestamp: context.getStepData(stepId)?.StepDetails?.NextAttemptTimestamp,
                    });
                    await checkpoint.waitForRetryTimer(stepId);
                    return await executeCheckLogic();
                }
                catch (error) {
                    await checkpoint.checkpoint(stepId, {
                        Id: stepId,
                        ParentId: parentId,
                        Action: clientLambda.OperationAction.FAIL,
                        SubType: exports.OperationSubType.WAIT_FOR_CONDITION,
                        Type: clientLambda.OperationType.STEP,
                        Error: createErrorObjectFromError(error),
                        Name: name,
                    });
                    checkpoint.markOperationState(stepId, OperationLifecycleState.COMPLETED);
                    throw DurableOperationError.fromErrorObject(createErrorObjectFromError(error));
                }
            }
        })();
        phase1Promise.catch(() => { });
        return new DurablePromise(async () => {
            checkpoint.markOperationAwaited(stepId);
            return await phase1Promise;
        });
    };
};

const createCallbackPromise = (context, checkpoint, stepId, stepName, serdes, checkAndUpdateReplayMode) => {
    return new DurablePromise(async () => {
        log("🔄", "Callback promise phase 2:", { stepId, stepName });
        checkpoint.markOperationAwaited(stepId);
        await checkpoint.waitForStatusChange(stepId);
        const stepData = context.getStepData(stepId);
        if (stepData?.Status === clientLambda.OperationStatus.SUCCEEDED) {
            log("✅", "Callback completed:", { stepId });
            checkAndUpdateReplayMode();
            checkpoint.markOperationState(stepId, OperationLifecycleState.COMPLETED);
            const callbackData = stepData.CallbackDetails;
            if (!callbackData) {
                throw new CallbackError(`No callback data found for completed callback: ${stepId}`);
            }
            const result = await safeDeserialize(serdes, callbackData.Result, stepId, stepName, context.terminationManager, context.durableExecutionArn);
            return result;
        }
        // Handle failure
        log("❌", "Callback failed:", { stepId, status: stepData?.Status });
        checkpoint.markOperationState(stepId, OperationLifecycleState.COMPLETED);
        const callbackData = stepData?.CallbackDetails;
        const error = callbackData?.Error;
        if (error) {
            const cause = new Error(error.ErrorMessage);
            cause.name = error.ErrorType || "Error";
            cause.stack = error.StackTrace?.join("\n");
            throw new CallbackError(error.ErrorMessage || "Callback failed", cause, error.ErrorData);
        }
        throw new CallbackError("Callback failed");
    });
};

const createPassThroughSerdes = () => ({
    serialize: async (value) => value,
    deserialize: async (data) => data,
});
const createCallback = (context, checkpoint, createStepId, checkAndUpdateReplayMode, parentId) => {
    return (nameOrConfig, maybeConfig) => {
        let name;
        let config;
        if (typeof nameOrConfig === "string" || nameOrConfig === undefined) {
            name = nameOrConfig;
            config = maybeConfig;
        }
        else {
            config = nameOrConfig;
        }
        const stepId = createStepId();
        const serdes = config?.serdes || createPassThroughSerdes();
        // Phase 1: Setup and checkpoint
        let isCompleted = false;
        const phase1Promise = (async () => {
            log("📞", "Callback phase 1:", { stepId, name });
            let stepData = context.getStepData(stepId);
            // Validate replay consistency
            validateReplayConsistency(stepId, {
                type: clientLambda.OperationType.CALLBACK,
                name,
                subType: exports.OperationSubType.CALLBACK,
            }, stepData, context);
            // Check if already completed
            if (stepData?.Status === clientLambda.OperationStatus.SUCCEEDED) {
                log("⏭️", "Callback already completed:", { stepId });
                checkAndUpdateReplayMode();
                checkpoint.markOperationState(stepId, OperationLifecycleState.COMPLETED, {
                    metadata: {
                        stepId,
                        name,
                        type: clientLambda.OperationType.CALLBACK,
                        subType: exports.OperationSubType.CALLBACK,
                        parentId,
                    },
                });
                isCompleted = true;
                return;
            }
            // Check if already failed
            if (stepData?.Status === clientLambda.OperationStatus.FAILED ||
                stepData?.Status === clientLambda.OperationStatus.TIMED_OUT) {
                log("❌", "Callback already failed:", { stepId });
                checkpoint.markOperationState(stepId, OperationLifecycleState.COMPLETED, {
                    metadata: {
                        stepId,
                        name,
                        type: clientLambda.OperationType.CALLBACK,
                        subType: exports.OperationSubType.CALLBACK,
                        parentId,
                    },
                });
                isCompleted = true;
                return;
            }
            // Start callback if not already started
            if (!stepData) {
                await checkpoint.checkpoint(stepId, {
                    Id: stepId,
                    ParentId: parentId,
                    Action: "START",
                    SubType: exports.OperationSubType.CALLBACK,
                    Type: clientLambda.OperationType.CALLBACK,
                    Name: name,
                    CallbackOptions: {
                        TimeoutSeconds: config?.timeout
                            ? durationToSeconds(config.timeout)
                            : undefined,
                        HeartbeatTimeoutSeconds: config?.heartbeatTimeout
                            ? durationToSeconds(config.heartbeatTimeout)
                            : undefined,
                    },
                });
                // Refresh stepData after checkpoint
                stepData = context.getStepData(stepId);
            }
            // Mark as IDLE_NOT_AWAITED
            checkpoint.markOperationState(stepId, OperationLifecycleState.IDLE_NOT_AWAITED, {
                metadata: {
                    stepId,
                    name,
                    type: clientLambda.OperationType.CALLBACK,
                    subType: exports.OperationSubType.CALLBACK,
                    parentId,
                },
            });
            log("✅", "Callback phase 1 complete:", { stepId });
        })();
        phase1Promise.catch(() => { });
        // Phase 2: Handle results and create callback promise
        return new DurablePromise(async () => {
            await phase1Promise;
            if (isCompleted) {
                const stepData = context.getStepData(stepId);
                const callbackData = stepData?.CallbackDetails;
                if (!callbackData?.CallbackId) {
                    throw new CallbackError(`No callback ID found for callback: ${stepId}`);
                }
                if (stepData?.Status === clientLambda.OperationStatus.SUCCEEDED) {
                    const deserializedResult = await safeDeserialize(serdes, callbackData.Result, stepId, name, context.terminationManager, context.durableExecutionArn);
                    const resolvedPromise = new DurablePromise(async () => deserializedResult);
                    return [resolvedPromise, callbackData.CallbackId];
                }
                // Handle failure
                const error = stepData?.CallbackDetails?.Error;
                const callbackError = error
                    ? (() => {
                        const cause = new Error(error.ErrorMessage);
                        cause.name = error.ErrorType || "Error";
                        cause.stack = error.StackTrace?.join("\n");
                        return new CallbackError(error.ErrorMessage || "Callback failed", cause, error.ErrorData);
                    })()
                    : new CallbackError("Callback failed");
                const rejectedPromise = new DurablePromise(async () => {
                    throw callbackError;
                });
                return [rejectedPromise, callbackData.CallbackId];
            }
            log("📞", "Callback phase 2:", { stepId });
            const stepData = context.getStepData(stepId);
            const callbackData = stepData?.CallbackDetails;
            if (!callbackData?.CallbackId) {
                throw new CallbackError(`No callback ID found for started callback: ${stepId}`);
            }
            const callbackId = callbackData.CallbackId;
            const callbackPromise = createCallbackPromise(context, checkpoint, stepId, name, serdes, checkAndUpdateReplayMode);
            log("✅", "Callback created:", { stepId, name, callbackId });
            return [callbackPromise, callbackId];
        });
    };
};

const createWaitForCallbackHandler = (context, getNextStepId, runInChildContext) => {
    return (nameOrSubmitter, submitterOrConfig, maybeConfig) => {
        let name;
        let submitter;
        let config;
        // Parse the overloaded parameters - validation errors thrown here are async
        if (typeof nameOrSubmitter === "string" || nameOrSubmitter === undefined) {
            // Case: waitForCallback("name", submitterFunc, config?) or waitForCallback(undefined, submitterFunc, config?)
            name = nameOrSubmitter;
            if (typeof submitterOrConfig === "function") {
                submitter = submitterOrConfig;
                config = maybeConfig;
            }
            else {
                return new DurablePromise(() => Promise.reject(new Error("waitForCallback requires a submitter function when name is provided")));
            }
        }
        else if (typeof nameOrSubmitter === "function") {
            // Case: waitForCallback(submitterFunc, config?)
            submitter = nameOrSubmitter;
            config = submitterOrConfig;
        }
        else {
            return new DurablePromise(() => Promise.reject(new Error("waitForCallback requires a submitter function")));
        }
        // Two-phase execution: Phase 1 starts immediately, Phase 2 returns result when awaited
        // Phase 1: Start execution immediately and capture result/error
        const phase1Promise = (async () => {
            log("📞", "WaitForCallback requested:", {
                name,
                hasSubmitter: !!submitter,
                config,
            });
            // Use runInChildContext to ensure proper ID generation and isolation
            const childFunction = async (childCtx) => {
                // Convert WaitForCallbackConfig to CreateCallbackConfig
                const createCallbackConfig = config
                    ? {
                        timeout: config.timeout,
                        heartbeatTimeout: config.heartbeatTimeout,
                    }
                    : undefined;
                // Create callback and get the promise + callbackId
                const [callbackPromise, callbackId] = await childCtx.createCallback(createCallbackConfig);
                log("🆔", "Callback created:", {
                    callbackId,
                    name,
                });
                // Execute the submitter step (submitter is now mandatory)
                await childCtx.step(async (stepContext) => {
                    // Use the step's built-in logger instead of creating a new one
                    const callbackContext = {
                        logger: stepContext.logger,
                    };
                    log("📤", "Executing submitter:", {
                        callbackId,
                        name,
                    });
                    await submitter(callbackId, callbackContext);
                    log("✅", "Submitter completed:", {
                        callbackId,
                        name,
                    });
                }, config?.retryStrategy
                    ? { retryStrategy: config.retryStrategy }
                    : undefined);
                log("⏳", "Waiting for callback completion:", {
                    callbackId,
                    name,
                });
                // Return just the callback promise result
                return await callbackPromise;
            };
            const stepId = getNextStepId();
            return {
                result: await runInChildContext(name, childFunction, {
                    subType: exports.OperationSubType.WAIT_FOR_CALLBACK,
                }),
                stepId,
            };
        })();
        // Attach catch handler to prevent unhandled promise rejections
        // The error will still be thrown when the DurablePromise is awaited
        phase1Promise.catch(() => { });
        // Phase 2: Return DurablePromise that returns Phase 1 result when awaited
        return new DurablePromise(async () => {
            const { result, stepId } = await phase1Promise;
            // Always deserialize the result since it's a string
            return (await safeDeserialize(config?.serdes ?? createPassThroughSerdes(), result, stepId, name, context.terminationManager, context.durableExecutionArn));
        });
    };
};

/**
 * Creates a predefined summary generator for parallel operations
 */
const createParallelSummaryGenerator = () => (result) => {
    return JSON.stringify({
        type: "ParallelResult",
        totalCount: result.totalCount,
        successCount: result.successCount,
        failureCount: result.failureCount,
        startedCount: result.startedCount,
        completionReason: result.completionReason,
        status: result.status,
    });
};
/**
 * Creates a predefined summary generator for map operations
 */
const createMapSummaryGenerator = () => (result) => {
    return JSON.stringify({
        type: "MapResult",
        totalCount: result.totalCount,
        successCount: result.successCount,
        failureCount: result.failureCount,
        completionReason: result.completionReason,
        status: result.status,
    });
};

const createMapHandler = (context, executeConcurrently) => {
    return (nameOrItems, itemsOrMapFunc, mapFuncOrConfig, maybeConfig) => {
        // Phase 1: Parse parameters and start execution immediately
        const phase1Promise = (async () => {
            let name;
            let items;
            let mapFunc;
            let config;
            // Parse overloaded parameters
            if (typeof nameOrItems === "string" || nameOrItems === undefined) {
                // Case: map(name, items, mapFunc, config?)
                name = nameOrItems;
                items = itemsOrMapFunc;
                mapFunc = mapFuncOrConfig;
                config = maybeConfig;
            }
            else {
                // Case: map(items, mapFunc, config?)
                items = nameOrItems;
                mapFunc = itemsOrMapFunc;
                config = mapFuncOrConfig;
            }
            log("🗺️", "Starting map operation:", {
                name,
                itemCount: items.length,
                maxConcurrency: config?.maxConcurrency,
            });
            // Validate inputs
            if (!Array.isArray(items)) {
                throw new Error("Map operation requires an array of items");
            }
            if (typeof mapFunc !== "function") {
                throw new Error("Map operation requires a function to process items");
            }
            // Convert to concurrent execution items
            const executionItems = items.map((item, index) => ({
                id: `map-item-${index}`,
                data: item,
                index,
                name: config?.itemNamer ? config.itemNamer(item, index) : undefined,
            }));
            // Create executor that calls mapFunc
            const executor = async (executionItem, childContext) => mapFunc(childContext, executionItem.data, executionItem.index, items);
            const result = await executeConcurrently(name, executionItems, executor, {
                maxConcurrency: config?.maxConcurrency,
                topLevelSubType: exports.OperationSubType.MAP,
                iterationSubType: exports.OperationSubType.MAP_ITERATION,
                summaryGenerator: createMapSummaryGenerator(),
                completionConfig: config?.completionConfig,
                serdes: config?.serdes,
                itemSerdes: config?.itemSerdes,
            });
            log("🗺️", "Map operation completed successfully:", {
                resultCount: result.totalCount,
            });
            return result;
        })();
        // Attach catch handler to prevent unhandled promise rejections
        // The error will still be thrown when the DurablePromise is awaited
        phase1Promise.catch(() => { });
        // Phase 2: Return DurablePromise that returns Phase 1 result when awaited
        return new DurablePromise(async () => {
            return await phase1Promise;
        });
    };
};

const createParallelHandler = (context, executeConcurrently) => {
    return (nameOrBranches, branchesOrConfig, maybeConfig) => {
        // Phase 1: Parse parameters and start execution immediately
        const phase1Promise = (async () => {
            let name;
            let branches;
            let config;
            // Parse overloaded parameters
            if (typeof nameOrBranches === "string" || nameOrBranches === undefined) {
                // Case: parallel(name, branches, config?)
                name = nameOrBranches;
                branches = branchesOrConfig;
                config = maybeConfig;
            }
            else {
                // Case: parallel(branches, config?)
                branches = nameOrBranches;
                config = branchesOrConfig;
            }
            // Validate inputs
            if (!Array.isArray(branches)) {
                throw new Error("Parallel operation requires an array of branch functions");
            }
            log("🔀", "Starting parallel operation:", {
                name,
                branchCount: branches.length,
                maxConcurrency: config?.maxConcurrency,
            });
            if (branches.some((branch) => typeof branch !== "function" &&
                (typeof branch !== "object" || typeof branch.func !== "function"))) {
                throw new Error("All branches must be functions or NamedParallelBranch objects");
            }
            // Convert to concurrent execution items
            const executionItems = branches.map((branch, index) => {
                const isNamedBranch = typeof branch === "object" && "func" in branch;
                const func = isNamedBranch ? branch.func : branch;
                const branchName = isNamedBranch ? branch.name : undefined;
                return {
                    id: `parallel-branch-${index}`,
                    data: func,
                    index,
                    name: branchName,
                };
            });
            // Create executor that calls the branch function
            const executor = async (executionItem, childContext) => {
                log("🔀", "Processing parallel branch:", {
                    index: executionItem.index,
                });
                const result = await executionItem.data(childContext);
                log("✅", "Parallel branch completed:", {
                    index: executionItem.index,
                    result,
                });
                return result;
            };
            const result = await executeConcurrently(name, executionItems, executor, {
                maxConcurrency: config?.maxConcurrency,
                topLevelSubType: exports.OperationSubType.PARALLEL,
                iterationSubType: exports.OperationSubType.PARALLEL_BRANCH,
                summaryGenerator: createParallelSummaryGenerator(),
                completionConfig: config?.completionConfig,
                serdes: config?.serdes,
                itemSerdes: config?.itemSerdes,
            });
            log("🔀", "Parallel operation completed successfully:", {
                resultCount: result.totalCount,
            });
            return result;
        })();
        // Attach catch handler to prevent unhandled promise rejections
        // The error will still be thrown when the DurablePromise is awaited
        phase1Promise.catch(() => { });
        // Phase 2: Return DurablePromise that returns Phase 1 result when awaited
        return new DurablePromise(async () => {
            return await phase1Promise;
        });
    };
};

// Minimal error decoration for Promise.allSettled results
function decorateErrors(value) {
    return value.map((item) => {
        if (item && item.status === "rejected" && item.reason instanceof Error) {
            return {
                ...item,
                reason: {
                    message: item.reason.message,
                    name: item.reason.name,
                    stack: item.reason.stack,
                },
            };
        }
        return item;
    });
}
// Error restoration for Promise.allSettled results
function restoreErrors(value) {
    return value.map((item) => {
        if (item &&
            item.status === "rejected" &&
            item.reason &&
            typeof item.reason === "object" &&
            item.reason.message) {
            const error = new Error(item.reason.message);
            error.name = item.reason.name || "Error";
            if (item.reason.stack)
                error.stack = item.reason.stack;
            return {
                ...item,
                reason: error,
            };
        }
        return item;
    });
}
// Custom serdes for promise results with error handling
function createErrorAwareSerdes() {
    return {
        serialize: async (value, _context) => value !== undefined ? JSON.stringify(decorateErrors(value)) : undefined,
        deserialize: async (data, _context) => data !== undefined
            ? restoreErrors(JSON.parse(data))
            : undefined,
    };
}
// No-retry strategy for promise combinators
const stepConfig = {
    retryStrategy: () => ({
        shouldRetry: false,
    }),
};
const createPromiseHandler = (step) => {
    const parseParams = (nameOrPromises, maybePromises) => {
        if (typeof nameOrPromises === "string" || nameOrPromises === undefined) {
            return { name: nameOrPromises, promises: maybePromises };
        }
        return { name: undefined, promises: nameOrPromises };
    };
    const all = (nameOrPromises, maybePromises) => {
        return new DurablePromise(async () => {
            const { name, promises } = parseParams(nameOrPromises, maybePromises);
            // Wrap Promise.all execution in a step for persistence
            return await step(name, () => Promise.all(promises), stepConfig);
        });
    };
    const allSettled = (nameOrPromises, maybePromises) => {
        return new DurablePromise(async () => {
            const { name, promises } = parseParams(nameOrPromises, maybePromises);
            // Wrap Promise.allSettled execution in a step for persistence
            return await step(name, () => Promise.allSettled(promises), {
                ...stepConfig,
                serdes: createErrorAwareSerdes(),
            });
        });
    };
    const any = (nameOrPromises, maybePromises) => {
        return new DurablePromise(async () => {
            const { name, promises } = parseParams(nameOrPromises, maybePromises);
            // Wrap Promise.any execution in a step for persistence
            return await step(name, () => Promise.any(promises), stepConfig);
        });
    };
    const race = (nameOrPromises, maybePromises) => {
        return new DurablePromise(async () => {
            const { name, promises } = parseParams(nameOrPromises, maybePromises);
            // Wrap Promise.race execution in a step for persistence
            return await step(name, () => Promise.race(promises), stepConfig);
        });
    };
    return {
        all,
        allSettled,
        any,
        race,
    };
};

class BatchResultImpl {
    all;
    completionReason;
    constructor(all, completionReason) {
        this.all = all;
        this.completionReason = completionReason;
    }
    succeeded() {
        return this.all.filter((item) => item.status === exports.BatchItemStatus.SUCCEEDED && item.result !== undefined);
    }
    failed() {
        return this.all.filter((item) => item.status === exports.BatchItemStatus.FAILED && item.error !== undefined);
    }
    started() {
        return this.all.filter((item) => item.status === exports.BatchItemStatus.STARTED);
    }
    get status() {
        return this.hasFailure ? exports.BatchItemStatus.FAILED : exports.BatchItemStatus.SUCCEEDED;
    }
    get hasFailure() {
        return this.all.some((item) => item.status === exports.BatchItemStatus.FAILED);
    }
    throwIfError() {
        const firstError = this.all.find((item) => item.status === exports.BatchItemStatus.FAILED)?.error;
        if (firstError) {
            throw firstError;
        }
    }
    getResults() {
        return this.succeeded().map((item) => item.result);
    }
    getErrors() {
        return this.failed().map((item) => item.error);
    }
    get successCount() {
        return this.all.filter((item) => item.status === exports.BatchItemStatus.SUCCEEDED)
            .length;
    }
    get failureCount() {
        return this.all.filter((item) => item.status === exports.BatchItemStatus.FAILED)
            .length;
    }
    get startedCount() {
        return this.all.filter((item) => item.status === exports.BatchItemStatus.STARTED)
            .length;
    }
    get totalCount() {
        return this.all.length;
    }
}
/**
 * Restores methods to deserialized BatchResult data
 */
function restoreBatchResult(data) {
    // If data is already a BatchResultImpl instance, return it as-is
    if (data instanceof BatchResultImpl) {
        return data;
    }
    if (data &&
        typeof data === "object" &&
        "all" in data &&
        Array.isArray(data.all)) {
        const serializedData = data;
        // Restore Error objects
        const restoredItems = serializedData.all.map((item) => ({
            ...item,
            result: item.result,
            error: item.error
                ? DurableOperationError.fromErrorObject(item.error)
                : undefined,
        }));
        return new BatchResultImpl(restoredItems, serializedData.completionReason);
    }
    return new BatchResultImpl([], "ALL_COMPLETED");
}

class ConcurrencyController {
    operationName;
    skipNextOperation;
    constructor(operationName, skipNextOperation) {
        this.operationName = operationName;
        this.skipNextOperation = skipNextOperation;
    }
    isChildEntityCompleted(executionContext, parentEntityId, completedCount) {
        const childEntityId = `${parentEntityId}-${completedCount + 1}`;
        const childStepData = executionContext.getStepData(childEntityId);
        return !!(childStepData &&
            (childStepData.Status === clientLambda.OperationStatus.SUCCEEDED ||
                childStepData.Status === clientLambda.OperationStatus.FAILED));
    }
    getCompletionReason(failureCount, successCount, completedCount, items, config) {
        // Check tolerance first, before checking if all completed
        const completion = config.completionConfig;
        // Handle fail-fast behavior (no completion config or empty completion config)
        if (!completion) {
            if (failureCount > 0)
                return "FAILURE_TOLERANCE_EXCEEDED";
        }
        else {
            const hasAnyCompletionCriteria = Object.values(completion).some((value) => value !== undefined);
            if (!hasAnyCompletionCriteria) {
                if (failureCount > 0)
                    return "FAILURE_TOLERANCE_EXCEEDED";
            }
            else {
                // Check specific tolerance thresholds
                if (completion.toleratedFailureCount !== undefined &&
                    failureCount > completion.toleratedFailureCount) {
                    return "FAILURE_TOLERANCE_EXCEEDED";
                }
                if (completion.toleratedFailurePercentage !== undefined) {
                    const failurePercentage = (failureCount / items.length) * 100;
                    if (failurePercentage > completion.toleratedFailurePercentage) {
                        return "FAILURE_TOLERANCE_EXCEEDED";
                    }
                }
            }
        }
        // Check other completion reasons
        if (completedCount === items.length)
            return "ALL_COMPLETED";
        if (config.completionConfig?.minSuccessful !== undefined &&
            successCount >= config.completionConfig.minSuccessful)
            return "MIN_SUCCESSFUL_REACHED";
        return "ALL_COMPLETED";
    }
    async executeItems(items, executor, parentContext, config, durableExecutionMode = DurableExecutionMode.ExecutionMode, entityId, executionContext) {
        // In replay mode, we're reconstructing the result from child contexts
        if (durableExecutionMode === DurableExecutionMode.ReplaySucceededContext) {
            log("🔄", `Replay mode: Reconstructing ${this.operationName} result:`, {
                itemCount: items.length,
            });
            // Try to get the target count from step data
            let targetTotalCount;
            if (entityId && executionContext) {
                const stepData = executionContext.getStepData(entityId);
                const summaryPayload = stepData?.ContextDetails?.Result;
                if (summaryPayload) {
                    try {
                        const serdes = config.serdes || defaultSerdes;
                        const parsedSummary = await serdes.deserialize(summaryPayload, {
                            entityId: entityId,
                            durableExecutionArn: executionContext.durableExecutionArn,
                        });
                        if (parsedSummary &&
                            typeof parsedSummary === "object" &&
                            "totalCount" in parsedSummary) {
                            // Read totalCount directly from summary metadata
                            targetTotalCount = parsedSummary.totalCount;
                            log("📊", "Found initial execution count:", {
                                targetTotalCount,
                            });
                        }
                    }
                    catch (error) {
                        log("⚠️", "Could not parse initial result summary:", error);
                    }
                }
            }
            // If we have target count and required context, use optimized replay; otherwise fallback to concurrent execution
            if (targetTotalCount !== undefined && entityId && executionContext) {
                return await this.replayItems(items, executor, parentContext, config, targetTotalCount, executionContext, entityId);
            }
            else {
                log("⚠️", "No valid target count or context found, falling back to concurrent execution");
            }
        }
        // First-time execution or fallback: use normal concurrent execution logic
        return await this.executeItemsConcurrently(items, executor, parentContext, config);
    }
    async replayItems(items, executor, parentContext, config, targetTotalCount, executionContext, parentEntityId) {
        const resultItems = [];
        log("🔄", `Replaying ${items.length} items sequentially`, {
            targetTotalCount,
        });
        let completedCount = 0;
        let stepCounter = 0;
        // Replay items sequentially until we reach the target count
        for (const item of items) {
            // Stop if we've replayed all items that completed in initial execution
            if (completedCount >= targetTotalCount) {
                log("✅", "Reached target count, stopping replay", {
                    completedCount,
                    targetTotalCount,
                });
                break;
            }
            // Calculate the child entity ID that runInChildContext will create
            // It uses the parent's next step ID, which is parentEntityId-{counter}
            const childEntityId = `${parentEntityId}-${stepCounter + 1}`;
            if (!this.isChildEntityCompleted(executionContext, parentEntityId, stepCounter)) {
                log("⏭️", `Skipping incomplete item:`, {
                    index: item.index,
                    itemId: item.id,
                    childEntityId,
                });
                // Increment step counter to maintain consistency
                this.skipNextOperation();
                stepCounter++;
                continue;
            }
            try {
                const result = await parentContext.runInChildContext(item.name || item.id, (childContext) => executor(item, childContext), { subType: config.iterationSubType, serdes: config.itemSerdes });
                resultItems.push({
                    result,
                    index: item.index,
                    status: exports.BatchItemStatus.SUCCEEDED,
                });
                completedCount++;
                stepCounter++;
                log("✅", `Replayed ${this.operationName} item:`, {
                    index: item.index,
                    itemId: item.id,
                    completedCount,
                });
            }
            catch (error) {
                const err = error instanceof ChildContextError
                    ? error
                    : new ChildContextError(error instanceof Error ? error.message : String(error), error instanceof Error ? error : undefined);
                resultItems.push({
                    error: err,
                    index: item.index,
                    status: exports.BatchItemStatus.FAILED,
                });
                completedCount++;
                stepCounter++;
                log("❌", `Replay failed for ${this.operationName} item:`, {
                    index: item.index,
                    itemId: item.id,
                    error: err.message,
                    completedCount,
                });
            }
        }
        log("🎉", `${this.operationName} replay completed:`, {
            completedCount,
            totalCount: resultItems.length,
        });
        const successCount = resultItems.filter((item) => item.status === exports.BatchItemStatus.SUCCEEDED).length;
        const failureCount = completedCount - successCount;
        return new BatchResultImpl(resultItems, this.getCompletionReason(failureCount, successCount, completedCount, items, config));
    }
    async executeItemsConcurrently(items, executor, parentContext, config) {
        const maxConcurrency = config.maxConcurrency || Infinity;
        const resultItems = new Array(items.length);
        const startedItems = new Set();
        let activeCount = 0;
        let currentIndex = 0;
        let completedCount = 0;
        let successCount = 0;
        let failureCount = 0;
        log("🚀", `Starting ${this.operationName} with concurrency control:`, {
            itemCount: items.length,
            maxConcurrency,
        });
        return new Promise((resolve) => {
            const shouldContinue = () => {
                const completion = config.completionConfig;
                if (!completion)
                    return failureCount === 0;
                // Default to fail-fast when no completion criteria are defined
                const hasAnyCompletionCriteria = Object.values(completion).some((value) => value !== undefined);
                if (!hasAnyCompletionCriteria) {
                    return failureCount === 0;
                }
                if (completion.toleratedFailureCount !== undefined &&
                    failureCount > completion.toleratedFailureCount)
                    return false;
                if (completion.toleratedFailurePercentage !== undefined) {
                    const failurePercentage = (failureCount / items.length) * 100;
                    if (failurePercentage > completion.toleratedFailurePercentage)
                        return false;
                }
                return true;
            };
            const isComplete = () => {
                // Always complete when all items are done (matches BatchResult inference)
                if (completedCount === items.length) {
                    return true;
                }
                const completion = config.completionConfig;
                if (completion?.minSuccessful !== undefined &&
                    successCount >= completion.minSuccessful) {
                    return true;
                }
                return false;
            };
            const getCompletionReason = (failureCount) => {
                return this.getCompletionReason(failureCount, successCount, completedCount, items, config);
            };
            const tryStartNext = () => {
                while (activeCount < maxConcurrency &&
                    currentIndex < items.length &&
                    shouldContinue()) {
                    const index = currentIndex++;
                    const item = items[index];
                    startedItems.add(index);
                    activeCount++;
                    // Set STARTED status immediately in result array
                    resultItems[index] = { index, status: exports.BatchItemStatus.STARTED };
                    log("▶️", `Starting ${this.operationName} item:`, {
                        index,
                        itemId: item.id,
                        itemName: item.name,
                    });
                    parentContext
                        .runInChildContext(item.name || item.id, (childContext) => executor(item, childContext), { subType: config.iterationSubType, serdes: config.itemSerdes })
                        .then((result) => {
                        resultItems[index] = {
                            result,
                            index,
                            status: exports.BatchItemStatus.SUCCEEDED,
                        };
                        successCount++;
                        log("✅", `${this.operationName} item completed:`, {
                            index,
                            itemId: item.id,
                            itemName: item.name,
                        });
                        onComplete();
                    }, (error) => {
                        const err = error instanceof ChildContextError
                            ? error
                            : new ChildContextError(error instanceof Error ? error.message : String(error), error instanceof Error ? error : undefined);
                        resultItems[index] = {
                            error: err,
                            index,
                            status: exports.BatchItemStatus.FAILED,
                        };
                        failureCount++;
                        log("❌", `${this.operationName} item failed:`, {
                            index,
                            itemId: item.id,
                            itemName: item.name,
                            error: err.message,
                        });
                        onComplete();
                    });
                }
            };
            const onComplete = () => {
                activeCount--;
                completedCount++;
                if (isComplete() || !shouldContinue()) {
                    // Convert sparse array to dense array - items are already in correct order by index
                    // Include all items that were started (have a value in resultItems)
                    // Create shallow copy to prevent mutations from affecting the returned result
                    const finalBatchItems = [];
                    for (let i = 0; i < resultItems.length; i++) {
                        if (resultItems[i] !== undefined) {
                            finalBatchItems.push({ ...resultItems[i] });
                        }
                    }
                    log("🎉", `${this.operationName} completed:`, {
                        successCount,
                        failureCount,
                        startedCount: finalBatchItems.filter((item) => item.status === exports.BatchItemStatus.STARTED).length,
                        totalCount: finalBatchItems.length,
                    });
                    const result = new BatchResultImpl(finalBatchItems, getCompletionReason(failureCount));
                    resolve(result);
                }
                else {
                    tryStartNext();
                }
            };
            if (items.length === 0) {
                log("🎉", `${this.operationName} completed with no items`);
                resolve(new BatchResultImpl([], getCompletionReason(0)));
            }
            else {
                tryStartNext();
            }
        });
    }
}
const createConcurrentExecutionHandler = (context, runInChildContext, skipNextOperation) => {
    return (nameOrItems, itemsOrExecutor, executorOrConfig, maybeConfig) => {
        // Phase 1: Start execution immediately
        const phase1Promise = (async () => {
            let name;
            let items;
            let executor;
            let config;
            if (typeof nameOrItems === "string" || nameOrItems === undefined) {
                name = nameOrItems;
                items = itemsOrExecutor;
                executor = executorOrConfig;
                config = maybeConfig;
            }
            else {
                items = nameOrItems;
                executor = itemsOrExecutor;
                config = executorOrConfig;
            }
            log("🔄", "Starting concurrent execution:", {
                name,
                itemCount: items.length,
                maxConcurrency: config?.maxConcurrency,
            });
            if (!Array.isArray(items)) {
                throw new Error("Concurrent execution requires an array of items");
            }
            if (typeof executor !== "function") {
                throw new Error("Concurrent execution requires an executor function");
            }
            if (config?.maxConcurrency !== undefined &&
                config.maxConcurrency !== null &&
                config.maxConcurrency <= 0) {
                throw new Error(`Invalid maxConcurrency: ${config.maxConcurrency}. Must be a positive number or undefined for unlimited concurrency.`);
            }
            const executeOperation = async (executionContext) => {
                const concurrencyController = new ConcurrencyController("concurrent-execution", skipNextOperation);
                // Access durableExecutionMode from the context - it's set by runInChildContext
                // based on determineChildReplayMode logic
                const durableExecutionMode = executionContext.durableExecutionMode;
                // Get the entity ID (step prefix) from the child context
                const entityId = executionContext._stepPrefix;
                log("🔄", "Concurrent execution mode:", {
                    mode: durableExecutionMode,
                    itemCount: items.length,
                    entityId,
                });
                return await concurrencyController.executeItems(items, executor, executionContext, config || {}, durableExecutionMode, entityId, context);
            };
            const result = await runInChildContext(name, executeOperation, {
                subType: config?.topLevelSubType,
                summaryGenerator: config?.summaryGenerator,
                serdes: config?.serdes,
            });
            // Restore BatchResult methods if the result came from deserialized data
            if (result &&
                typeof result === "object" &&
                "all" in result &&
                Array.isArray(result.all)) {
                return restoreBatchResult(result);
            }
            return result;
        })();
        // Attach catch handler to prevent unhandled promise rejections
        // The error will still be thrown when the DurablePromise is awaited
        phase1Promise.catch(() => { });
        // Phase 2: Return DurablePromise that returns Phase 1 result when awaited
        return new DurablePromise(async () => {
            return await phase1Promise;
        });
    };
};

class ModeManagement {
    captureExecutionState;
    checkAndUpdateReplayMode;
    checkForNonResolvingPromise;
    getDurableExecutionMode;
    setDurableExecutionMode;
    constructor(captureExecutionState, checkAndUpdateReplayMode, checkForNonResolvingPromise, getDurableExecutionMode, setDurableExecutionMode) {
        this.captureExecutionState = captureExecutionState;
        this.checkAndUpdateReplayMode = checkAndUpdateReplayMode;
        this.checkForNonResolvingPromise = checkForNonResolvingPromise;
        this.getDurableExecutionMode = getDurableExecutionMode;
        this.setDurableExecutionMode = setDurableExecutionMode;
    }
    withModeManagement(operation) {
        const shouldSwitchToExecutionMode = this.captureExecutionState();
        this.checkAndUpdateReplayMode();
        const nonResolvingPromise = this.checkForNonResolvingPromise();
        if (nonResolvingPromise)
            return nonResolvingPromise;
        try {
            return operation();
        }
        finally {
            if (shouldSwitchToExecutionMode) {
                this.setDurableExecutionMode(DurableExecutionMode.ExecutionMode);
            }
        }
    }
    withDurableModeManagement(operation) {
        const shouldSwitchToExecutionMode = this.captureExecutionState();
        this.checkAndUpdateReplayMode();
        const nonResolvingPromise = this.checkForNonResolvingPromise();
        if (nonResolvingPromise) {
            return new DurablePromise(async () => {
                await nonResolvingPromise;
                // This will never be reached
                throw new Error("Unreachable code");
            });
        }
        try {
            return operation();
        }
        finally {
            if (shouldSwitchToExecutionMode) {
                this.setDurableExecutionMode(DurableExecutionMode.ExecutionMode);
            }
        }
    }
}

const HASH_LENGTH = 16;
/**
 * Creates an MD5 hash of the input string for better performance than SHA-256
 * @param input - The string to hash
 * @returns The truncated hexadecimal hash string
 */
const hashId = (input) => {
    return crypto.createHash("md5")
        .update(input)
        .digest("hex")
        .substring(0, HASH_LENGTH);
};
/**
 * Helper function to get step data using the original stepId
 * This function handles the hashing internally so callers don't need to worry about it
 * @param stepData - The stepData record from context
 * @param stepId - The original stepId (will be hashed internally)
 * @returns The operation data or undefined if not found
 */
const getStepData = (stepData, stepId) => {
    const hashedId = hashId(stepId);
    return stepData[hashedId];
};

class DurableContextImpl {
    _executionContext;
    lambdaContext;
    _stepPrefix;
    _stepCounter = 0;
    durableLogger;
    modeAwareLoggingEnabled = true;
    checkpoint;
    durableExecutionMode;
    _parentId;
    modeManagement;
    durableExecution;
    logger;
    executionContext;
    constructor(_executionContext, lambdaContext, durableExecutionMode, inheritedLogger, stepPrefix, durableExecution, parentId) {
        this._executionContext = _executionContext;
        this.lambdaContext = lambdaContext;
        this._stepPrefix = stepPrefix;
        this._parentId = parentId;
        this.durableExecution = durableExecution;
        this.durableLogger = inheritedLogger;
        this.durableLogger.configureDurableLoggingContext?.(this.getDurableLoggingContext());
        this.logger = this.createModeAwareLogger(inheritedLogger);
        this.executionContext = {
            durableExecutionArn: _executionContext.durableExecutionArn,
        };
        this.durableExecutionMode = durableExecutionMode;
        this.checkpoint = durableExecution.checkpointManager;
        this.modeManagement = new ModeManagement(this.captureExecutionState.bind(this), this.checkAndUpdateReplayMode.bind(this), this.checkForNonResolvingPromise.bind(this), () => this.durableExecutionMode, (mode) => {
            this.durableExecutionMode = mode;
        });
    }
    getDurableLoggingContext() {
        return {
            getDurableLogData: () => {
                const activeContext = getActiveContext();
                const result = {
                    executionArn: this._executionContext.durableExecutionArn,
                    requestId: this._executionContext.requestId,
                    tenantId: this._executionContext.tenantId,
                    operationId: !activeContext || activeContext?.contextId === "root"
                        ? undefined
                        : hashId(activeContext.contextId),
                };
                if (activeContext?.attempt !== undefined) {
                    result.attempt = activeContext.attempt;
                }
                return result;
            },
        };
    }
    shouldLog() {
        const activeContext = getActiveContext();
        if (!this.modeAwareLoggingEnabled || !activeContext) {
            return true;
        }
        if (activeContext.contextId === "root") {
            return this.durableExecutionMode === DurableExecutionMode.ExecutionMode;
        }
        return (activeContext.durableExecutionMode === DurableExecutionMode.ExecutionMode);
    }
    createModeAwareLogger(logger) {
        const durableContextLogger = {
            warn: (...args) => {
                if (this.shouldLog()) {
                    return logger.warn(...args);
                }
            },
            debug: (...args) => {
                if (this.shouldLog()) {
                    return logger.debug(...args);
                }
            },
            info: (...args) => {
                if (this.shouldLog()) {
                    return logger.info(...args);
                }
            },
            error: (...args) => {
                if (this.shouldLog()) {
                    return logger.error(...args);
                }
            },
        };
        if ("log" in logger) {
            durableContextLogger.log = (level, ...args) => {
                if (this.shouldLog()) {
                    return logger.log?.(level, ...args);
                }
            };
        }
        return durableContextLogger;
    }
    createStepId() {
        this._stepCounter++;
        return this._stepPrefix
            ? `${this._stepPrefix}-${this._stepCounter}`
            : `${this._stepCounter}`;
    }
    getNextStepId() {
        const nextCounter = this._stepCounter + 1;
        return this._stepPrefix
            ? `${this._stepPrefix}-${nextCounter}`
            : `${nextCounter}`;
    }
    /**
     * Skips the next operation by incrementing the step counter.
     * Used internally by concurrent execution handler during replay to skip incomplete items.
     * @internal
     */
    skipNextOperation() {
        this._stepCounter++;
    }
    checkAndUpdateReplayMode() {
        if (this.durableExecutionMode === DurableExecutionMode.ReplayMode) {
            const nextStepId = this.getNextStepId();
            const nextStepData = this._executionContext.getStepData(nextStepId);
            if (!nextStepData) {
                this.durableExecutionMode = DurableExecutionMode.ExecutionMode;
            }
        }
    }
    captureExecutionState() {
        const wasInReplayMode = this.durableExecutionMode === DurableExecutionMode.ReplayMode;
        const nextStepId = this.getNextStepId();
        const stepData = this._executionContext.getStepData(nextStepId);
        const wasNotFinished = !!(stepData &&
            stepData.Status !== clientLambda.OperationStatus.SUCCEEDED &&
            stepData.Status !== clientLambda.OperationStatus.FAILED);
        return wasInReplayMode && wasNotFinished;
    }
    checkForNonResolvingPromise() {
        if (this.durableExecutionMode === DurableExecutionMode.ReplaySucceededContext) {
            const nextStepId = this.getNextStepId();
            const nextStepData = this._executionContext.getStepData(nextStepId);
            if (nextStepData &&
                nextStepData.Status !== clientLambda.OperationStatus.SUCCEEDED &&
                nextStepData.Status !== clientLambda.OperationStatus.FAILED) {
                return new Promise(() => { }); // Non-resolving promise
            }
        }
        return null;
    }
    withModeManagement(operation) {
        return this.modeManagement.withModeManagement(operation);
    }
    withDurableModeManagement(operation) {
        return this.modeManagement.withDurableModeManagement(operation);
    }
    step(nameOrFn, fnOrOptions, maybeOptions) {
        validateContextUsage(this._stepPrefix, "step", this._executionContext.terminationManager);
        return this.withDurableModeManagement(() => {
            const stepHandler = createStepHandler(this._executionContext, this.checkpoint, this.lambdaContext, this.createStepId.bind(this), this.durableLogger, this._parentId);
            return stepHandler(nameOrFn, fnOrOptions, maybeOptions);
        });
    }
    invoke(nameOrFuncId, funcIdOrInput, inputOrConfig, maybeConfig) {
        validateContextUsage(this._stepPrefix, "invoke", this._executionContext.terminationManager);
        return this.withDurableModeManagement(() => {
            const invokeHandler = createInvokeHandler(this._executionContext, this.checkpoint, this.createStepId.bind(this), this._parentId, this.checkAndUpdateReplayMode.bind(this));
            return invokeHandler(...[
                nameOrFuncId,
                funcIdOrInput,
                inputOrConfig,
                maybeConfig,
            ]);
        });
    }
    runInChildContext(nameOrFn, fnOrOptions, maybeOptions) {
        validateContextUsage(this._stepPrefix, "runInChildContext", this._executionContext.terminationManager);
        return this.withDurableModeManagement(() => {
            const blockHandler = createRunInChildContextHandler(this._executionContext, this.checkpoint, this.lambdaContext, this.createStepId.bind(this), () => this.durableLogger, 
            // Adapter function to maintain compatibility
            (executionContext, parentContext, durableExecutionMode, inheritedLogger, stepPrefix, _checkpointToken, parentId) => createDurableContext(executionContext, parentContext, durableExecutionMode, inheritedLogger, stepPrefix, this.durableExecution, parentId), this._parentId);
            return blockHandler(nameOrFn, fnOrOptions, maybeOptions);
        });
    }
    wait(nameOrDuration, maybeDuration) {
        validateContextUsage(this._stepPrefix, "wait", this._executionContext.terminationManager);
        return this.withDurableModeManagement(() => {
            const waitHandler = createWaitHandler(this._executionContext, this.checkpoint, this.createStepId.bind(this), this._parentId, this.checkAndUpdateReplayMode.bind(this));
            return typeof nameOrDuration === "string"
                ? waitHandler(nameOrDuration, maybeDuration)
                : waitHandler(nameOrDuration);
        });
    }
    /**
     * Configure logger behavior for this context
     *
     * This method allows partial configuration - only the properties provided will be updated.
     * For example, calling configureLogger(\{ modeAware: false \}) will only change the modeAware
     * setting without affecting any previously configured custom logger.
     *
     * @param config - Logger configuration options including customLogger and modeAware settings (default: modeAware=true)
     * @example
     * // Set custom logger and enable mode-aware logging
     * context.configureLogger(\{ customLogger: myLogger, modeAware: true \});
     *
     * // Later, disable mode-aware logging without changing the custom logger
     * context.configureLogger(\{ modeAware: false \});
     */
    configureLogger(config) {
        if (config.customLogger !== undefined) {
            this.durableLogger = config.customLogger;
            this.durableLogger.configureDurableLoggingContext?.(this.getDurableLoggingContext());
            this.logger = this.createModeAwareLogger(this.durableLogger);
        }
        if (config.modeAware !== undefined) {
            this.modeAwareLoggingEnabled = config.modeAware;
        }
    }
    createCallback(nameOrConfig, maybeConfig) {
        validateContextUsage(this._stepPrefix, "createCallback", this._executionContext.terminationManager);
        return this.withDurableModeManagement(() => {
            const callbackFactory = createCallback(this._executionContext, this.checkpoint, this.createStepId.bind(this), this.checkAndUpdateReplayMode.bind(this), this._parentId);
            return callbackFactory(nameOrConfig, maybeConfig);
        });
    }
    waitForCallback(nameOrSubmitter, submitterOrConfig, maybeConfig) {
        validateContextUsage(this._stepPrefix, "waitForCallback", this._executionContext.terminationManager);
        return this.withDurableModeManagement(() => {
            const waitForCallbackHandler = createWaitForCallbackHandler(this._executionContext, this.getNextStepId.bind(this), this.runInChildContext.bind(this));
            return waitForCallbackHandler(nameOrSubmitter, submitterOrConfig, maybeConfig);
        });
    }
    waitForCondition(nameOrCheckFunc, checkFuncOrConfig, maybeConfig) {
        validateContextUsage(this._stepPrefix, "waitForCondition", this._executionContext.terminationManager);
        return this.withDurableModeManagement(() => {
            const waitForConditionHandler = createWaitForConditionHandler(this._executionContext, this.checkpoint, this.createStepId.bind(this), this.durableLogger, this._parentId);
            return typeof nameOrCheckFunc === "string" ||
                nameOrCheckFunc === undefined
                ? waitForConditionHandler(nameOrCheckFunc, checkFuncOrConfig, maybeConfig)
                : waitForConditionHandler(nameOrCheckFunc, checkFuncOrConfig);
        });
    }
    map(nameOrItems, itemsOrMapFunc, mapFuncOrConfig, maybeConfig) {
        validateContextUsage(this._stepPrefix, "map", this._executionContext.terminationManager);
        return this.withDurableModeManagement(() => {
            const mapHandler = createMapHandler(this._executionContext, this._executeConcurrently.bind(this));
            return mapHandler(nameOrItems, itemsOrMapFunc, mapFuncOrConfig, maybeConfig);
        });
    }
    parallel(nameOrBranches, branchesOrConfig, maybeConfig) {
        validateContextUsage(this._stepPrefix, "parallel", this._executionContext.terminationManager);
        return this.withDurableModeManagement(() => {
            const parallelHandler = createParallelHandler(this._executionContext, this._executeConcurrently.bind(this));
            return parallelHandler(nameOrBranches, branchesOrConfig, maybeConfig);
        });
    }
    _executeConcurrently(nameOrItems, itemsOrExecutor, executorOrConfig, maybeConfig) {
        validateContextUsage(this._stepPrefix, "_executeConcurrently", this._executionContext.terminationManager);
        return this.withDurableModeManagement(() => {
            const concurrentExecutionHandler = createConcurrentExecutionHandler(this._executionContext, this.runInChildContext.bind(this), this.skipNextOperation.bind(this));
            const promise = concurrentExecutionHandler(nameOrItems, itemsOrExecutor, executorOrConfig, maybeConfig);
            // Prevent unhandled promise rejections
            promise?.catch(() => { });
            return promise;
        });
    }
    get promise() {
        return createPromiseHandler(this.step.bind(this));
    }
}
const createDurableContext = (executionContext, parentContext, durableExecutionMode, inheritedLogger, stepPrefix, durableExecution, parentId) => {
    return new DurableContextImpl(executionContext, parentContext, durableExecutionMode, inheritedLogger, stepPrefix, durableExecution, parentId);
};

/**
 * Error thrown when a checkpoint operation fails due to invocation-level issues
 * (e.g., 5xx errors, invalid checkpoint token)
 * This will terminate the current Lambda invocation, but the execution can continue with a new invocation
 */
class CheckpointUnrecoverableInvocationError extends UnrecoverableInvocationError {
    terminationReason = TerminationReason.CHECKPOINT_FAILED;
    constructor(message, originalError) {
        super(message || "Checkpoint operation failed", originalError);
    }
}
/**
 * Error thrown when a checkpoint operation fails due to execution-level issues
 * (e.g., 4xx errors other than invalid checkpoint token)
 * This will terminate the entire execution and cannot be recovered
 */
class CheckpointUnrecoverableExecutionError extends UnrecoverableExecutionError {
    terminationReason = TerminationReason.CHECKPOINT_FAILED;
    constructor(message, originalError) {
        super(message || "Checkpoint operation failed", originalError);
    }
}

const STEP_DATA_UPDATED_EVENT = "stepDataUpdated";
const TERMINAL_STATUSES = [
    clientLambda.OperationStatus.SUCCEEDED,
    clientLambda.OperationStatus.CANCELLED,
    clientLambda.OperationStatus.FAILED,
    clientLambda.OperationStatus.STOPPED,
    clientLambda.OperationStatus.TIMED_OUT,
];
class CheckpointManager {
    durableExecutionArn;
    stepData;
    storage;
    terminationManager;
    stepDataEmitter;
    logger;
    finishedAncestors;
    queue = [];
    isProcessing = false;
    currentTaskToken;
    forceCheckpointPromises = [];
    queueCompletionResolver = null;
    MAX_PAYLOAD_SIZE = 750 * 1024; // 750KB in bytes
    MAX_ITEMS_IN_BATCH = 250;
    isTerminating = false;
    static textEncoder = new TextEncoder();
    // Operation lifecycle tracking
    operations = new Map();
    // Termination cooldown
    terminationTimer = null;
    terminationReason = null;
    constructor(durableExecutionArn, stepData, storage, terminationManager, initialTaskToken, stepDataEmitter, logger, finishedAncestors) {
        this.durableExecutionArn = durableExecutionArn;
        this.stepData = stepData;
        this.storage = storage;
        this.terminationManager = terminationManager;
        this.stepDataEmitter = stepDataEmitter;
        this.logger = logger;
        this.finishedAncestors = finishedAncestors;
        this.currentTaskToken = initialTaskToken;
    }
    setTerminating() {
        this.isTerminating = true;
        log("🛑", "Checkpoint manager marked as terminating");
    }
    /**
     * Mark an ancestor as finished (for run-in-child-context operations)
     */
    markAncestorFinished(stepId) {
        this.finishedAncestors.add(stepId);
    }
    /**
     * Extract parent ID from hierarchical stepId (e.g., "1-2-3" -\> "1-2")
     */
    getParentId(stepId) {
        const lastDashIndex = stepId.lastIndexOf("-");
        return lastDashIndex > 0 ? stepId.substring(0, lastDashIndex) : undefined;
    }
    /**
     * Checks if any ancestor of the given stepId is finished
     * Only applies to operations that are descendants of run-in-child-context operations
     */
    hasFinishedAncestor(stepId) {
        // Only use getParentId to avoid mixing hashed and original stepIds
        let currentParentId = this.getParentId(stepId);
        while (currentParentId) {
            // Check if this ancestor is finished
            if (this.finishedAncestors.has(currentParentId)) {
                return true;
            }
            // Move up to the next ancestor using hierarchical stepId
            currentParentId = this.getParentId(currentParentId);
        }
        return false;
    }
    async forceCheckpoint() {
        if (this.isTerminating) {
            log("⚠️", "Force checkpoint skipped - termination in progress");
            return new Promise(() => { }); // Never resolves during termination
        }
        return new Promise((resolve, reject) => {
            this.forceCheckpointPromises.push({ resolve, reject });
            if (!this.isProcessing) {
                setImmediate(() => {
                    this.processQueue();
                });
            }
        });
    }
    async waitForQueueCompletion() {
        if (this.queue.length === 0 && !this.isProcessing) {
            return;
        }
        return new Promise((resolve) => {
            this.queueCompletionResolver = resolve;
        });
    }
    clearQueue() {
        // Silently clear queue - we're terminating so no need to reject promises
        this.queue = [];
        this.forceCheckpointPromises = [];
        // Resolve any waiting queue completion promises since we're clearing
        this.notifyQueueCompletion();
    }
    // Alias for backward compatibility with Checkpoint interface
    async force() {
        return this.forceCheckpoint();
    }
    async checkpoint(stepId, data) {
        if (this.isTerminating) {
            log("⚠️", "Checkpoint skipped - termination in progress:", { stepId });
            return new Promise(() => { }); // Never resolves during termination
        }
        // Check if any ancestor is finished - if so, don't queue and don't resolve
        if (this.hasFinishedAncestor(stepId)) {
            log("⚠️", "Checkpoint skipped - ancestor already finished:", { stepId });
            return new Promise(() => { }); // Never resolves when ancestor is finished
        }
        return new Promise((resolve, reject) => {
            const queuedItem = {
                stepId,
                data,
                resolve: () => {
                    resolve();
                },
                reject: (error) => {
                    reject(error);
                },
            };
            this.queue.push(queuedItem);
            log("📥", "Checkpoint queued:", {
                stepId,
                queueLength: this.queue.length,
                isProcessing: this.isProcessing,
            });
            if (!this.isProcessing) {
                setImmediate(() => {
                    this.processQueue();
                });
            }
        });
    }
    classifyCheckpointError(error) {
        const originalError = error instanceof Error ? error : new Error(String(error));
        const awsError = error;
        const statusCode = awsError.$metadata?.httpStatusCode;
        const errorName = awsError.name;
        const errorMessage = awsError.message || originalError.message;
        log("🔍", "Classifying checkpoint error:", {
            statusCode,
            errorName,
            errorMessage,
        });
        if (statusCode &&
            statusCode >= 400 &&
            statusCode < 500 &&
            errorName === "InvalidParameterValueException" &&
            errorMessage.startsWith("Invalid Checkpoint Token")) {
            return new CheckpointUnrecoverableInvocationError(`Checkpoint failed: ${errorMessage}`, originalError);
        }
        if (statusCode &&
            statusCode >= 400 &&
            statusCode < 500 &&
            statusCode !== 429) {
            return new CheckpointUnrecoverableExecutionError(`Checkpoint failed: ${errorMessage}`, originalError);
        }
        return new CheckpointUnrecoverableInvocationError(`Checkpoint failed: ${errorMessage}`, originalError);
    }
    async processQueue() {
        if (this.isProcessing) {
            return;
        }
        const hasQueuedItems = this.queue.length > 0;
        const hasForceRequests = this.forceCheckpointPromises.length > 0;
        if (!hasQueuedItems && !hasForceRequests) {
            return;
        }
        this.isProcessing = true;
        const batch = [];
        const baseSize = this.currentTaskToken.length + 100;
        let currentSize = baseSize;
        while (this.queue.length > 0) {
            const nextItem = this.queue[0];
            const itemSize = CheckpointManager.textEncoder.encode(JSON.stringify(nextItem)).length;
            if ((currentSize + itemSize > this.MAX_PAYLOAD_SIZE ||
                batch.length >= this.MAX_ITEMS_IN_BATCH) &&
                batch.length > 0) {
                break;
            }
            this.queue.shift();
            batch.push(nextItem);
            currentSize += itemSize;
        }
        log("🔄", "Processing checkpoint batch:", {
            batchSize: batch.length,
            remainingInQueue: this.queue.length,
            estimatedSize: currentSize,
            maxSize: this.MAX_PAYLOAD_SIZE,
        });
        try {
            if (batch.length > 0 || this.forceCheckpointPromises.length > 0) {
                await this.processBatch(batch);
            }
            batch.forEach((item) => {
                item.resolve();
            });
            const forcePromises = this.forceCheckpointPromises.splice(0);
            forcePromises.forEach((promise) => {
                promise.resolve();
            });
            log("✅", "Checkpoint batch processed successfully:", {
                batchSize: batch.length,
                forceRequests: forcePromises.length,
                newTaskToken: this.currentTaskToken,
            });
        }
        catch (error) {
            log("❌", "Checkpoint batch failed:", {
                batchSize: batch.length,
                error,
            });
            const checkpointError = this.classifyCheckpointError(error);
            // Clear remaining queue silently - we're terminating
            this.clearQueue();
            this.terminationManager.terminate({
                reason: TerminationReason.CHECKPOINT_FAILED,
                message: checkpointError.message,
                error: checkpointError,
            });
        }
        finally {
            this.isProcessing = false;
            if (this.queue.length > 0) {
                setImmediate(() => {
                    this.processQueue();
                });
            }
            else {
                // Queue is empty and processing is done - notify all waiting promises
                this.notifyQueueCompletion();
                // Re-evaluate termination now that the queue is empty, unless
                // a termination cooldown is already in progress.
                if (!this.terminationTimer) {
                    this.checkAndTerminate();
                }
            }
        }
    }
    notifyQueueCompletion() {
        if (this.queueCompletionResolver) {
            this.queueCompletionResolver();
            this.queueCompletionResolver = null;
        }
    }
    async processBatch(batch) {
        const updates = batch.map((item) => {
            const hashedStepId = hashId(item.stepId);
            const update = {
                Type: item.data.Type || "STEP",
                Action: item.data.Action || "START",
                ...item.data,
                Id: hashedStepId,
                ...(item.data.ParentId && { ParentId: hashId(item.data.ParentId) }),
            };
            return update;
        });
        const checkpointData = {
            DurableExecutionArn: this.durableExecutionArn,
            CheckpointToken: this.currentTaskToken,
            Updates: updates,
        };
        log("⏺️", "Creating checkpoint batch:", {
            batchSize: updates.length,
            checkpointToken: this.currentTaskToken,
            updates: updates.map((u) => ({
                Id: u.Id,
                Action: u.Action,
                Type: u.Type,
            })),
        });
        const response = await this.storage.checkpoint(checkpointData, this.logger);
        if (response.CheckpointToken) {
            this.currentTaskToken = response.CheckpointToken;
        }
        if (response.NewExecutionState?.Operations) {
            this.updateStepDataFromCheckpointResponse(response.NewExecutionState.Operations);
        }
    }
    updateStepDataFromCheckpointResponse(operations) {
        log("🔄", "Updating stepData from checkpoint response:", {
            operationCount: operations.length,
            operationIds: operations.map((op) => op.Id).filter(Boolean),
        });
        operations.forEach((operation) => {
            if (operation.Id) {
                // Check if status changed
                const oldStatus = this.stepData[operation.Id]?.Status;
                const newStatus = operation.Status;
                this.stepData[operation.Id] = operation;
                log("📝", "Updated stepData entry:", operation);
                this.stepDataEmitter.emit(STEP_DATA_UPDATED_EVENT, operation.Id);
                // If status changed and we have a waiting promise, resolve it
                if (oldStatus !== newStatus) {
                    this.resolveWaitingOperation(operation.Id);
                }
            }
        });
        log("✅", "StepData update completed:", {
            totalStepDataEntries: Object.keys(this.stepData).length,
        });
    }
    resolveWaitingOperation(hashedStepId) {
        // Find operation by hashed ID in our operations map
        for (const [stepId, op] of this.operations.entries()) {
            if (hashId(stepId) === hashedStepId && op.resolver) {
                log("✅", `Resolving waiting operation ${stepId} due to status change`);
                op.resolver();
                op.resolver = undefined;
                if (op.timer) {
                    clearTimeout(op.timer);
                    op.timer = undefined;
                }
                break;
            }
        }
    }
    getQueueStatus() {
        return {
            queueLength: this.queue.length,
            isProcessing: this.isProcessing,
        };
    }
    // ===== New Lifecycle & Termination Methods =====
    markOperationState(stepId, state, options) {
        let op = this.operations.get(stepId);
        if (!op) {
            // First call - create operation
            if (!options?.metadata) {
                throw new Error(`metadata required on first call for ${stepId}`);
            }
            op = {
                stepId,
                state,
                metadata: options.metadata,
                endTimestamp: options.endTimestamp,
            };
            this.operations.set(stepId, op);
        }
        else {
            // Update existing operation
            op.state = state;
            if (options?.endTimestamp !== undefined) {
                op.endTimestamp = options.endTimestamp;
            }
        }
        // Cleanup if transitioning to COMPLETED
        if (state === OperationLifecycleState.COMPLETED) {
            this.cleanupOperation(stepId);
        }
        // Check if we should terminate
        // Don't check for IDLE_NOT_AWAITED - operation might be awaited later or intentionally not awaited
        if (state !== OperationLifecycleState.IDLE_NOT_AWAITED) {
            this.checkAndTerminate();
        }
    }
    waitForRetryTimer(stepId) {
        const op = this.operations.get(stepId);
        if (!op) {
            throw new Error(`Operation ${stepId} not found`);
        }
        if (op.state !== OperationLifecycleState.RETRY_WAITING) {
            throw new Error(`Operation ${stepId} must be in RETRY_WAITING state, got ${op.state}`);
        }
        // Resolve immediately if the step was completed already
        const stepData = this.stepData[hashId(stepId)];
        if (stepData?.Status && TERMINAL_STATUSES.includes(stepData.Status)) {
            return Promise.resolve();
        }
        // Start timer with polling
        this.startTimerWithPolling(stepId, op.endTimestamp);
        // Return promise that resolves when status changes
        return new Promise((resolve) => {
            op.resolver = resolve;
        });
    }
    waitForStatusChange(stepId) {
        const op = this.operations.get(stepId);
        if (!op) {
            throw new Error(`Operation ${stepId} not found`);
        }
        if (op.state !== OperationLifecycleState.IDLE_AWAITED) {
            throw new Error(`Operation ${stepId} must be in IDLE_AWAITED state, got ${op.state}`);
        }
        // Resolve immediately if the step was completed already
        const stepData = this.stepData[hashId(stepId)];
        if (stepData?.Status && TERMINAL_STATUSES.includes(stepData.Status)) {
            return Promise.resolve();
        }
        // Start timer with polling
        this.startTimerWithPolling(stepId, op.endTimestamp);
        // Return promise that resolves when status changes
        return new Promise((resolve) => {
            op.resolver = resolve;
        });
    }
    markOperationAwaited(stepId) {
        const op = this.operations.get(stepId);
        if (!op) {
            log("⚠️", `Cannot mark operation as awaited: ${stepId} not found`);
            return;
        }
        // Transition IDLE_NOT_AWAITED → IDLE_AWAITED
        if (op.state === OperationLifecycleState.IDLE_NOT_AWAITED) {
            op.state = OperationLifecycleState.IDLE_AWAITED;
            log("📍", `Operation marked as awaited: ${stepId}`);
            // Check if we should terminate now that operation is awaited
            this.checkAndTerminate();
        }
    }
    getOperationState(stepId) {
        return this.operations.get(stepId)?.state;
    }
    getAllOperations() {
        return new Map(this.operations);
    }
    // ===== Private Helper Methods =====
    cleanupOperation(stepId) {
        const op = this.operations.get(stepId);
        if (!op)
            return;
        // Clear timer
        if (op.timer) {
            clearTimeout(op.timer);
            op.timer = undefined;
        }
        // Clear resolver
        op.resolver = undefined;
    }
    cleanupAllOperations() {
        for (const op of this.operations.values()) {
            if (op.timer) {
                clearTimeout(op.timer);
                op.timer = undefined;
            }
            op.resolver = undefined;
        }
    }
    /**
     * Determines if the function should terminate.
     * @returns TerminationReason if the function should terminate, or undefined if the function should not terminate
     */
    shouldTerminate() {
        // Rule 1: Can't terminate if checkpoint queue is not empty
        if (this.queue.length > 0) {
            return undefined;
        }
        // Rule 2: Can't terminate if checkpoint is currently processing
        if (this.isProcessing) {
            return undefined;
        }
        // Rule 3: Can't terminate if there are pending force checkpoint promises
        if (this.forceCheckpointPromises.length > 0) {
            return undefined;
        }
        const allOps = Array.from(this.operations.values());
        // Rule 4: Can't terminate if any operation is EXECUTING
        const hasExecuting = allOps.some((op) => op.state === OperationLifecycleState.EXECUTING);
        if (hasExecuting) {
            return undefined;
        }
        // Rule 5: Clean up operations whose ancestors are complete or pending completion
        for (const op of allOps) {
            if (op.state === OperationLifecycleState.RETRY_WAITING ||
                op.state === OperationLifecycleState.IDLE_NOT_AWAITED ||
                op.state === OperationLifecycleState.IDLE_AWAITED) {
                // Use the original stepId from metadata, not the potentially hashed op.stepId
                const originalStepId = op.metadata.stepId;
                if (this.hasFinishedAncestor(originalStepId)) {
                    log("🧹", `Cleaning up operation with completed ancestor: ${originalStepId}`);
                    this.cleanupOperation(op.stepId);
                    this.operations.delete(op.stepId);
                }
            }
        }
        // Re-check operations after cleanup
        const remainingOps = Array.from(this.operations.values());
        // Determine if we should terminate
        const hasWaiting = remainingOps.some((op) => op.state === OperationLifecycleState.RETRY_WAITING ||
            op.state === OperationLifecycleState.IDLE_NOT_AWAITED ||
            op.state === OperationLifecycleState.IDLE_AWAITED);
        if (hasWaiting) {
            return this.determineTerminationReason(remainingOps);
        }
        return undefined;
    }
    checkAndTerminate() {
        const terminationReason = this.shouldTerminate();
        if (terminationReason) {
            this.scheduleTermination(terminationReason);
            return;
        }
        this.abortTermination();
    }
    abortTermination() {
        if (this.terminationTimer) {
            clearTimeout(this.terminationTimer);
            this.terminationTimer = null;
            this.terminationReason = null;
            log("🔄", "Termination aborted - conditions changed");
        }
    }
    scheduleTermination(reason) {
        // If already scheduled with same reason, don't reschedule
        if (this.terminationTimer && this.terminationReason === reason) {
            return;
        }
        // Clear any existing timer
        this.abortTermination();
        // Schedule new termination
        this.terminationReason = reason;
        log("⏱️", "Scheduling termination", {
            reason,
            cooldownMs: CHECKPOINT_TERMINATION_COOLDOWN_MS,
        });
        this.terminationTimer = setTimeout(() => {
            if (!this.shouldTerminate()) {
                log("🔄", "Termination conditions no longer valid after cooldown, aborting termination");
                this.abortTermination();
                return;
            }
            this.executeTermination(reason);
        }, CHECKPOINT_TERMINATION_COOLDOWN_MS);
    }
    executeTermination(reason) {
        log("🛑", "Executing termination after cooldown", { reason });
        // Clear timer
        this.terminationTimer = null;
        this.terminationReason = null;
        // Cleanup all operations before terminating
        this.cleanupAllOperations();
        // Call termination manager directly
        this.terminationManager.terminate({ reason });
    }
    determineTerminationReason(ops) {
        // Priority: RETRY_SCHEDULED > WAIT_SCHEDULED > CALLBACK_PENDING
        if (ops.some((op) => op.state === OperationLifecycleState.RETRY_WAITING &&
            op.metadata.subType === "Step")) {
            return TerminationReason.RETRY_SCHEDULED;
        }
        if (ops.some((op) => (op.state === OperationLifecycleState.IDLE_NOT_AWAITED ||
            op.state === OperationLifecycleState.IDLE_AWAITED) &&
            op.metadata.subType === "Wait")) {
            return TerminationReason.WAIT_SCHEDULED;
        }
        return TerminationReason.CALLBACK_PENDING;
    }
    startTimerWithPolling(stepId, endTimestamp) {
        const op = this.operations.get(stepId);
        if (!op)
            return;
        let delay;
        if (endTimestamp) {
            // Ensure endTimestamp is a Date object
            const timestamp = endTimestamp instanceof Date ? endTimestamp : new Date(endTimestamp);
            // Wait until endTimestamp
            delay = Math.max(0, timestamp.getTime() - Date.now());
            // Skip setTimeout if delay exceeds MAX_POLL_DURATION_MS (Lambda will timeout before it fires)
            if (delay > MAX_POLL_DURATION_MS) {
                return;
            }
        }
        else {
            // No timestamp, start polling immediately (1 second delay)
            delay = 1000;
        }
        // Initialize poll count and start time for this operation
        if (!op.pollCount) {
            op.pollCount = 0;
            op.pollStartTime = Date.now();
        }
        op.timer = setTimeout(() => {
            this.forceRefreshAndCheckStatus(stepId);
        }, delay);
    }
    async forceRefreshAndCheckStatus(stepId) {
        const op = this.operations.get(stepId);
        if (!op)
            return;
        // Check if we've exceeded max polling duration (15 minutes)
        if (op.pollStartTime &&
            Date.now() - op.pollStartTime > MAX_POLL_DURATION_MS) {
            // Stop polling after 15 minutes to prevent indefinite resource consumption.
            // We don't resolve or reject the promise because the handler cannot continue
            // without a status change. The execution will remain suspended until the
            // operation completes or the Lambda times out.
            log("⏱️", `Max polling duration (15 min) exceeded for ${stepId}, stopping poll`);
            if (op.timer) {
                clearTimeout(op.timer);
                op.timer = undefined;
            }
            return;
        }
        // Get old status before refresh
        const oldStatus = this.stepData[hashId(stepId)]?.Status;
        // Force checkpoint to refresh state from backend
        await this.forceCheckpoint();
        // Get new status after refresh
        const newStatus = this.stepData[hashId(stepId)]?.Status;
        // Check if status changed
        if (newStatus !== oldStatus) {
            // Status changed, resolve the waiting promise
            log("✅", `Status changed for ${stepId}: ${oldStatus} → ${newStatus}`);
            op.resolver?.();
            op.resolver = undefined;
            // Clear timer
            if (op.timer) {
                clearTimeout(op.timer);
                op.timer = undefined;
            }
        }
        else {
            // Status not changed yet, poll again with incremental backoff
            // Start at 1s, increase by 1s each poll, max 10s
            op.pollCount = (op.pollCount || 0) + 1;
            const nextDelay = Math.min(op.pollCount * 1000, 10000);
            op.timer = setTimeout(() => {
                this.forceRefreshAndCheckStatus(stepId);
            }, nextDelay);
        }
    }
}

/*
Second Approach (Promise-based):
Pros:
  - Simpler implementation
  - Single promise instance for the entire lifecycle
  - More memory efficient as it doesn't create new promises on each getTerminationPromise() call
  - More predictable behavior since there's only one resolution path
Cons:
  - Less flexible as it doesn't support multiple listeners
  - Once the promise is resolved, it stays resolved (can't be reset)
  - Doesn't leverage Node.js's event system
*/
class TerminationManager extends events.EventEmitter {
    isTerminated = false;
    terminationDetails;
    resolveTermination;
    terminationPromise;
    setCheckpointTerminating;
    constructor(setCheckpointTerminating) {
        super();
        this.setCheckpointTerminating = setCheckpointTerminating;
        // Create the promise immediately during construction
        this.terminationPromise = new Promise((resolve) => {
            this.resolveTermination = resolve;
        });
    }
    setCheckpointTerminatingCallback(callback) {
        this.setCheckpointTerminating = callback;
    }
    terminate(options = {}) {
        if (this.isTerminated)
            return;
        // Set checkpoint termination flag before any other termination logic
        this.setCheckpointTerminating?.();
        this.isTerminated = true;
        this.terminationDetails = {
            reason: options.reason ?? TerminationReason.OPERATION_TERMINATED,
            message: options.message ?? "Operation terminated",
            error: options.error,
            cleanup: options.cleanup,
        };
        // Instead of emitting an event, resolve the promise
        if (this.resolveTermination) {
            this.handleTermination(this.terminationDetails).then(this.resolveTermination);
        }
    }
    getTerminationPromise() {
        return this.terminationPromise;
    }
    async handleTermination(details) {
        if (details.cleanup) {
            try {
                await details.cleanup();
            }
            catch { }
        }
        return {
            reason: details.reason,
            message: details.message,
            error: details.error,
        };
    }
}

// The logic from this file is based on the NodeJS RIC LogPatch functionality for parity with standard Lambda functions. We should always
// align the default behaviour of how logs are emitted to match the RIC logging behaviour for consistency.
// For custom logic, users can implement their own logger to log data differently.
// See: https://github.com/aws/aws-lambda-nodejs-runtime-interface-client/blob/962ed28eefbc052389c4de4366b1c0c49ee08a13/src/LogPatch.js
/**
 * Format options for util.formatWithOptions.
 * Using breakLength: Infinity prevents util.inspect from inserting newlines
 * when formatting objects, regardless of object size (fixes issue #322).
 * Defined at module level to avoid creating a new object on every function call.
 */
const FORMAT_OPTIONS = { breakLength: Infinity };
/**
 * JSON.stringify replacer function for Error objects.
 * Based on AWS Lambda Runtime Interface Client LogPatch functionality.
 * Transforms Error instances into serializable objects with structured error information,
 * emulating the default Node.js console behavior in Lambda environments.
 *
 * @param _key - The property key (unused in this replacer)
 * @param value - The value being stringified
 * @returns The original value, or a structured error object for Error instances
 */
function jsonErrorReplacer(_key, value) {
    if (value instanceof Error) {
        return Object.assign({
            errorType: value?.constructor?.name ?? "UnknownError",
            errorMessage: value.message,
            stackTrace: typeof value.stack === "string"
                ? value.stack.split("\n")
                : value.stack,
        }, value);
    }
    return value;
}
/**
 * Formats durable log data into structured JSON string output.
 * Emulates AWS Lambda Runtime Interface Client's formatJsonMessage functionality
 * to provide consistent logging format with standard Lambda functions.
 *
 * The function handles two main scenarios:
 * 1. Single parameter: Attempts to stringify directly, falls back to util.format on error
 * 2. Multiple parameters: Uses util.format to create message, extracts error details if present
 *
 * This approach mirrors the RIC's behavior of:
 * - Using util.format for message formatting (same as console.log)
 * - Handling circular references gracefully with fallback formatting
 * - Extracting structured error information when Error objects are present
 * - Including optional tenantId when available
 *
 * @param level - The log level for this message
 * @param logData - Durable execution context data (requestId, executionArn, etc.)
 * @param messageParams - Variable number of message parameters to log
 * @returns JSON string representation of the structured log entry
 */
function formatDurableLogData(level, logData, ...messageParams) {
    const result = {
        requestId: logData.requestId,
        timestamp: new Date().toISOString(),
        level: level.toUpperCase(),
        executionArn: logData.executionArn,
    };
    const tenantId = logData.tenantId;
    if (tenantId != undefined && tenantId != null) {
        result.tenantId = tenantId;
    }
    if (logData.operationId !== undefined) {
        result.operationId = logData.operationId;
    }
    if (logData.attempt !== undefined) {
        result.attempt = logData.attempt;
    }
    if (messageParams.length === 1) {
        result.message = messageParams[0];
        try {
            return JSON.stringify(result, jsonErrorReplacer);
        }
        catch (_) {
            result.message = util.formatWithOptions(FORMAT_OPTIONS, result.message);
            return JSON.stringify(result);
        }
    }
    result.message = util.formatWithOptions(FORMAT_OPTIONS, ...messageParams);
    for (const param of messageParams) {
        if (param instanceof Error) {
            result.errorType = param?.constructor?.name ?? "UnknownError";
            result.errorMessage = param.message;
            result.stackTrace =
                typeof param.stack === "string" ? param.stack.split("\n") : [];
            break;
        }
    }
    return JSON.stringify(result);
}
/**
 * Default logger class that outputs structured logs to console.
 *
 * This logger emulates the AWS Lambda Runtime Interface Client (RIC) console patching
 * behavior to maintain parity with standard Lambda function logging while providing
 * structured output suitable for durable execution contexts.
 *
 * Key RIC behavior emulation:
 * - Respects AWS_LAMBDA_LOG_LEVEL environment variable for log filtering
 * - Uses priority-based level filtering (DEBUG=2, INFO=3, WARN=4, ERROR=5)
 * - Outputs structured JSON with timestamp, requestId, executionArn, and other metadata
 * - Handles Error objects with structured error information extraction
 * - Uses Node.js Console instance for proper stdout/stderr routing
 * - Applies util.format for message formatting (same as console.log behavior)
 *
 * Individual logger methods (info, error, warn, debug) are dynamically enabled/disabled
 * based on the configured log level, defaulting to no-op functions when disabled.
 * This mirrors how RIC patches console methods conditionally.
 */
class DefaultLogger {
    consoleLogger;
    durableLoggingContext = undefined;
    executionContext;
    noOpLog = () => { };
    constructor(executionContext) {
        this.executionContext = executionContext;
        // Override the RIC logger to provide custom attributes on the structured log output
        this.consoleLogger = new node_console.Console({
            stdout: process.stdout,
            stderr: process.stderr,
        });
        // Initialize methods with no-op and then configure based on log level
        this.info = this.noOpLog;
        this.error = this.noOpLog;
        this.warn = this.noOpLog;
        this.debug = this.noOpLog;
        this.configureLogLevel();
    }
    configureLogLevel() {
        const levels = {
            DEBUG: { name: "DEBUG", priority: 2 },
            INFO: { name: "INFO", priority: 3 },
            WARN: { name: "WARN", priority: 4 },
            ERROR: { name: "ERROR", priority: 5 },
            // Not implemented yet. Can be implemented later
            // TRACE: { name: "TRACE", priority: 1 },
            // FATAL: { name: "FATAL", priority: 6 },
        };
        const logLevelEnvVariable = process.env["AWS_LAMBDA_LOG_LEVEL"]?.toUpperCase();
        // Default to DEBUG level when env var is invalid/missing
        const lambdaLogLevel = logLevelEnvVariable && logLevelEnvVariable in levels
            ? levels[logLevelEnvVariable]
            : levels.DEBUG;
        // Enable methods based on priority: higher priority = more restrictive
        // e.g., if WARN is set (priority 4), only WARN and ERROR methods are enabled
        if (levels.DEBUG.priority >= lambdaLogLevel.priority) {
            this.debug = (message, ...optionalParams) => {
                const loggingContext = this.ensureDurableLoggingContext();
                const params = message !== undefined ? [message, ...optionalParams] : optionalParams;
                this.consoleLogger.debug(formatDurableLogData(DurableLogLevel.DEBUG, loggingContext.getDurableLogData(), ...params));
            };
        }
        if (levels.INFO.priority >= lambdaLogLevel.priority) {
            this.info = (message, ...optionalParams) => {
                const loggingContext = this.ensureDurableLoggingContext();
                const params = message !== undefined ? [message, ...optionalParams] : optionalParams;
                this.consoleLogger.info(formatDurableLogData(DurableLogLevel.INFO, loggingContext.getDurableLogData(), ...params));
            };
        }
        if (levels.WARN.priority >= lambdaLogLevel.priority) {
            this.warn = (message, ...optionalParams) => {
                const loggingContext = this.ensureDurableLoggingContext();
                const params = message !== undefined ? [message, ...optionalParams] : optionalParams;
                this.consoleLogger.warn(formatDurableLogData(DurableLogLevel.WARN, loggingContext.getDurableLogData(), ...params));
            };
        }
        if (levels.ERROR.priority >= lambdaLogLevel.priority) {
            this.error = (message, ...optionalParams) => {
                const loggingContext = this.ensureDurableLoggingContext();
                const params = message !== undefined ? [message, ...optionalParams] : optionalParams;
                this.consoleLogger.error(formatDurableLogData(DurableLogLevel.ERROR, loggingContext.getDurableLogData(), ...params));
            };
        }
    }
    ensureDurableLoggingContext() {
        const context = this.executionContext;
        if (!this.durableLoggingContext && !context) {
            throw new Error("DurableLoggingContext is not configured. Please call configureDurableLoggingContext before logging.");
        }
        if (this.durableLoggingContext) {
            return this.durableLoggingContext;
        }
        if (!context) {
            throw new Error("Execution context is not provided.");
        }
        return {
            getDurableLogData: () => {
                return {
                    requestId: context.requestId,
                    executionArn: context.durableExecutionArn,
                    tenantId: context.tenantId,
                };
            },
        };
    }
    log(level, message, ...optionalParams) {
        switch (level) {
            case DurableLogLevel.DEBUG:
                this.debug(message, ...optionalParams);
                break;
            case DurableLogLevel.INFO:
                this.info(message, ...optionalParams);
                break;
            case DurableLogLevel.WARN:
                this.warn(message, ...optionalParams);
                break;
            case DurableLogLevel.ERROR:
                this.error(message, ...optionalParams);
                break;
            default:
                this.info(message, ...optionalParams);
                break;
        }
    }
    // These method signatures will be set dynamically in configureLogLevel()
    info;
    error;
    warn;
    debug;
    configureDurableLoggingContext(durableLoggingContext) {
        this.durableLoggingContext = durableLoggingContext;
    }
}
/**
 * Creates a default logger that outputs structured logs to console.
 *
 * @param executionContext - Optional execution context for logging
 * @returns DefaultLogger instance
 */
const createDefaultLogger = (executionContext) => {
    return new DefaultLogger(executionContext);
};

/**
 * SDK metadata injected by Rollup at build time from package.json.
 * These values are inserted into UserAgent headers.
 *
 * At build time, Rollup replaces "1.1.5"
 * with actual values from package.json.
 *
 * SDK_NAME is a fixed string matching the cross-SDK convention:
 * aws-durable-execution-sdk-\{language\}
 * Alternate version if SDK is bundled into the Lambda runtime.
 *
 * Defaults are provided for test environments where Rollup doesn't run
 * and process.env values are undefined.
 *
 * @internal
 */
const runtimeDir = process.env.LAMBDA_RUNTIME_DIR || "/var/runtime";
// Capture this module's path at module scope. `import.meta.url` is
// per-module and is only resolvable in true ESM contexts, so it must
// be referenced at top level — not from inside a function, and not
// via `new Function("return import.meta")` or `eval(...)` (both run
// their body in non-module scope, where `import.meta` is undefined).
// In CJS the rollup output makes `__filename` a normal binding, so
// the typeof guard takes that branch.
//
// The Jest unit tests never run this file directly: a manual mock
// at `__mocks__/version.ts` substitutes a hardcoded SDK_VERSION,
// which sidesteps ts-jest's TS1343 ("import.meta is only allowed
// when module is es2020+") error during CJS test compilation.
let moduleFilePath;
if (typeof __filename !== "undefined") {
    moduleFilePath = __filename;
}
else if (typeof (typeof document === 'undefined' ? require('u' + 'rl').pathToFileURL(__filename).href : (_documentCurrentScript && _documentCurrentScript.tagName.toUpperCase() === 'SCRIPT' && _documentCurrentScript.src || new URL('index.js', document.baseURI).href)) === "string") {
    moduleFilePath = node_url.fileURLToPath((typeof document === 'undefined' ? require('u' + 'rl').pathToFileURL(__filename).href : (_documentCurrentScript && _documentCurrentScript.tagName.toUpperCase() === 'SCRIPT' && _documentCurrentScript.src || new URL('index.js', document.baseURI).href)));
}
// Check if this code is running from a bundle in Lambda runtime
// Use file path detection to determine if running in Lambda runtime directory
function isInLambdaRuntime() {
    try {
        if (!moduleFilePath) {
            return false;
        }
        return node_path.dirname(moduleFilePath).startsWith(runtimeDir);
    }
    catch {
        return false;
    }
}
const isRuntimeBundled = isInLambdaRuntime();
const SDK_NAME = "aws-durable-execution-sdk-js";
const baseVersion = "1.1.5";
const SDK_VERSION = isRuntimeBundled
    ? `${baseVersion}-bundled`
    : baseVersion;

let defaultLambdaClient;
/**
 * Durable execution client which uses an API-based LambdaClient
 * with built-in error logging. By default, the Lambda client will
 * have custom timeouts set.
 *
 * @public
 */
class DurableExecutionApiClient {
    client;
    constructor(client) {
        if (!client) {
            if (!defaultLambdaClient) {
                defaultLambdaClient = new clientLambda.LambdaClient({
                    customUserAgent: [[SDK_NAME, SDK_VERSION]],
                    requestHandler: {
                        connectionTimeout: 5000,
                        socketTimeout: 50000,
                        requestTimeout: 55000,
                        throwOnRequestTimeout: true,
                    },
                });
            }
            this.client = defaultLambdaClient;
        }
        else {
            this.client = client;
        }
    }
    /**
     * Gets operation state data from the durable execution
     * @param params - The GetDurableExecutionState request
     * @param logger - Optional developer logger for error reporting
     * @returns Response with operations data
     */
    async getExecutionState(params, logger) {
        try {
            const response = await this.client.send(new clientLambda.GetDurableExecutionStateCommand({
                DurableExecutionArn: params.DurableExecutionArn,
                CheckpointToken: params.CheckpointToken,
                Marker: params.Marker,
                MaxItems: params.MaxItems,
            }));
            return response;
        }
        catch (error) {
            // Internal debug logging
            log("❌", "GetDurableExecutionState failed", {
                error,
                requestId: error?.$metadata
                    ?.requestId,
                DurableExecutionArn: params.DurableExecutionArn,
                CheckpointToken: params.CheckpointToken,
                Marker: params.Marker,
            });
            // Developer logging if logger provided
            if (logger) {
                logger.error("Failed to get durable execution state", error, {
                    requestId: error
                        ?.$metadata?.requestId,
                });
            }
            throw error;
        }
    }
    /**
     * Checkpoints the durable execution with operation updates
     * @param params - The checkpoint request
     * @param logger - Optional developer logger for error reporting
     * @returns Checkpoint response
     */
    async checkpoint(params, logger) {
        try {
            const response = await this.client.send(new clientLambda.CheckpointDurableExecutionCommand({
                DurableExecutionArn: params.DurableExecutionArn,
                CheckpointToken: params.CheckpointToken,
                ClientToken: params.ClientToken,
                Updates: params.Updates,
            }));
            return response;
        }
        catch (error) {
            // Internal debug logging
            log("❌", "CheckpointDurableExecution failed", {
                error,
                requestId: error?.$metadata
                    ?.requestId,
                DurableExecutionArn: params.DurableExecutionArn,
                CheckpointToken: params.CheckpointToken,
                ClientToken: params.ClientToken,
            });
            // Developer logging if logger provided
            if (logger) {
                logger.error("Failed to checkpoint durable execution", error, {
                    requestId: error
                        ?.$metadata?.requestId,
                });
            }
            throw error;
        }
    }
}

/**
 * Custom DurableExecutionInvocationInput which uses a custom durable
 * execution client instead of the API-based LambdaClient.
 *
 * @internal
 */
class DurableExecutionInvocationInputWithClient {
    durableExecutionClient;
    InitialExecutionState;
    DurableExecutionArn;
    CheckpointToken;
    constructor(params, durableExecutionClient) {
        this.durableExecutionClient = durableExecutionClient;
        this.InitialExecutionState = params.InitialExecutionState;
        this.DurableExecutionArn = params.DurableExecutionArn;
        this.CheckpointToken = params.CheckpointToken;
    }
    static isInstance(event) {
        if (event instanceof DurableExecutionInvocationInputWithClient) {
            return true;
        }
        return !!(typeof event === "object" &&
            event &&
            event.toString() ===
                "[object DurableExecutionInvocationInputWithClient]" &&
            "durableExecutionClient" in event &&
            event.constructor.name === "DurableExecutionInvocationInputWithClient");
    }
    get [Symbol.toStringTag]() {
        return "DurableExecutionInvocationInputWithClient";
    }
}

const initializeExecutionContext = async (event, context, lambdaClient) => {
    log("🔵", "Initializing durable function with event:", event);
    log("📍", "Function Input:", event);
    const checkpointToken = event.CheckpointToken;
    const durableExecutionArn = event.DurableExecutionArn;
    const durableExecutionClient = 
    // Allow passing arbitrary durable clients if the input is a custom class
    DurableExecutionInvocationInputWithClient.isInstance(event)
        ? event.durableExecutionClient
        : new DurableExecutionApiClient(lambdaClient);
    // Create logger for initialization errors using existing logger factory
    const initLogger = createDefaultLogger({
        durableExecutionArn,
        requestId: context.awsRequestId,
        tenantId: context.tenantId,
    });
    const operationsArray = [...(event.InitialExecutionState.Operations || [])];
    let nextMarker = event.InitialExecutionState.NextMarker;
    while (nextMarker) {
        const response = await durableExecutionClient.getExecutionState({
            CheckpointToken: checkpointToken,
            Marker: nextMarker,
            DurableExecutionArn: durableExecutionArn,
            MaxItems: 1000,
        }, initLogger);
        operationsArray.push(...(response.Operations || []));
        nextMarker = response.NextMarker || "";
    }
    // Determine replay mode based on operations array length
    const durableExecutionMode = operationsArray.length > 1
        ? DurableExecutionMode.ReplayMode
        : DurableExecutionMode.ExecutionMode;
    log("📝", "Operations:", operationsArray);
    const stepData = operationsArray.reduce((acc, operation) => {
        if (operation.Id) {
            // The stepData received from backend has Id and ParentId as hash, so no need to hash it again
            acc[operation.Id] = operation;
        }
        return acc;
    }, {});
    log("📝", "Loaded step data:", stepData);
    return {
        executionContext: {
            durableExecutionClient,
            _stepData: stepData,
            terminationManager: new TerminationManager(),
            durableExecutionArn,
            pendingCompletions: new Set(),
            getStepData(stepId) {
                return getStepData(stepData, stepId);
            },
            tenantId: context.tenantId,
            requestId: context.awsRequestId,
        },
        durableExecutionMode,
        checkpointToken,
    };
};

// Lambda response size limit is 6MB
const LAMBDA_RESPONSE_SIZE_LIMIT = 6 * 1024 * 1024 - 50; // 6MB in bytes, minus 50 bytes for envelope
async function runHandler(event, context, executionContext, durableExecutionMode, checkpointToken, handler) {
    // Create checkpoint manager and step data emitter
    const stepDataEmitter = new events.EventEmitter();
    const checkpointManager = new CheckpointManager(executionContext.durableExecutionArn, executionContext._stepData, executionContext.durableExecutionClient, executionContext.terminationManager, checkpointToken, stepDataEmitter, createDefaultLogger(executionContext), new Set());
    // Set the checkpoint terminating callback on the termination manager
    executionContext.terminationManager.setCheckpointTerminatingCallback(() => {
        checkpointManager.setTerminating();
    });
    const durableExecution = {
        checkpointManager,
        stepDataEmitter,
        setTerminating: () => checkpointManager.setTerminating(),
    };
    const durableContext = createDurableContext(executionContext, context, durableExecutionMode, 
    // Default logger may not have the same type as Logger, but we should always provide a default logger even if the user overrides it
    createDefaultLogger(), undefined, durableExecution);
    // Extract customerHandlerEvent from the complete operations array (after pagination)
    // This ensures we get the full payload even for large payloads that are paginated
    const initialExecutionEvent = executionContext._stepData[Object.keys(executionContext._stepData)[0]];
    const customerHandlerEvent = JSON.parse(initialExecutionEvent?.ExecutionDetails?.InputPayload ?? "{}");
    try {
        log("🎯", `Starting handler execution, handler event: ${customerHandlerEvent}`);
        let handlerPromiseResolved = false;
        let terminationPromiseResolved = false;
        const handlerPromise = runWithContext("root", undefined, () => handler(customerHandlerEvent, durableContext)).then((result) => {
            handlerPromiseResolved = true;
            log("🏆", "Handler promise resolved first!");
            return ["handler", result];
        });
        const terminationPromise = executionContext.terminationManager
            .getTerminationPromise()
            .then((result) => {
            terminationPromiseResolved = true;
            log("💥", "Termination promise resolved first!");
            // Set checkpoint manager as terminating when termination starts
            durableExecution.setTerminating();
            return ["termination", result];
        });
        // Set up a timeout to log the state of promises after a short delay
        setTimeout(() => {
            log("⏱️", "Promise race status check:", {
                handlerResolved: handlerPromiseResolved,
                terminationResolved: terminationPromiseResolved,
            });
        }, 500);
        const [resultType, result] = await Promise.race([
            handlerPromise,
            terminationPromise,
        ]);
        log("🏁", "Promise race completed with:", {
            resultType,
        });
        // Wait for all pending checkpoints to complete
        try {
            await durableExecution.checkpointManager.waitForQueueCompletion();
            log("✅", "All pending checkpoints completed");
        }
        catch (error) {
            log("⚠️", "Error waiting for checkpoint completion:", error);
        }
        // If termination was due to checkpoint failure, throw the appropriate error
        if (resultType === "termination" &&
            result.reason === TerminationReason.CHECKPOINT_FAILED) {
            log("🛑", "Checkpoint failed - handling termination");
            // checkpoint.ts always provides classified error
            throw result.error;
        }
        // If termination was due to serdes failure, throw an error to terminate the Lambda
        if (resultType === "termination" &&
            result.reason === TerminationReason.SERDES_FAILED) {
            log("🛑", "Serdes failed - terminating Lambda execution");
            throw new SerdesFailedError(result.message);
        }
        // If termination was due to context validation error, return FAILED
        if (resultType === "termination" &&
            result.reason === TerminationReason.CONTEXT_VALIDATION_ERROR) {
            log("🛑", "Context validation error - returning FAILED status");
            return {
                Status: exports.InvocationStatus.FAILED,
                Error: createErrorObjectFromError(result.error || new Error(result.message)),
            };
        }
        if (resultType === "termination") {
            log("🛑", "Returning termination response");
            return {
                Status: exports.InvocationStatus.PENDING,
            };
        }
        log("✅", "Returning normal completion response");
        // Stringify the result once to avoid multiple JSON.stringify calls
        const serializedResult = JSON.stringify(result);
        const serializedSize = new TextEncoder().encode(serializedResult).length;
        // Check if the response size exceeds the Lambda limit
        // Note: JSON.stringify(undefined) returns undefined, so we need to handle that case
        if (serializedResult && serializedSize > LAMBDA_RESPONSE_SIZE_LIMIT) {
            log("📦", `Response size (${serializedSize} bytes) exceeds Lambda limit (${LAMBDA_RESPONSE_SIZE_LIMIT} bytes). Checkpointing result.`);
            // Create a checkpoint to save the large result
            const stepId = `execution-result-${Date.now()}`;
            try {
                await durableExecution.checkpointManager.checkpoint(stepId, {
                    Id: stepId,
                    Action: "SUCCEED",
                    Type: clientLambda.OperationType.EXECUTION,
                    Payload: serializedResult, // Reuse the already serialized result
                });
                log("✅", "Large result successfully checkpointed");
                // Wait for any pending checkpoints to complete before returning
                try {
                    await durableExecution.checkpointManager.waitForQueueCompletion();
                }
                catch (waitError) {
                    log("⚠️", "Error waiting for checkpoint queue completion:", waitError);
                    // Continue anyway - the checkpoint will be retried on next invocation
                }
                // Return a response indicating the result was checkpointed
                return {
                    Status: exports.InvocationStatus.SUCCEEDED,
                    Result: "",
                };
            }
            catch (checkpointError) {
                log("❌", "Failed to checkpoint large result:", checkpointError);
                // Re-throw - checkpoint.ts always classifies errors before terminating
                throw checkpointError;
            }
        }
        // If response size is acceptable, return the response
        // Wait for any pending checkpoints to complete before returning
        try {
            await durableExecution.checkpointManager.waitForQueueCompletion();
        }
        catch (waitError) {
            log("⚠️", "Error waiting for checkpoint queue completion:", waitError);
            // Continue anyway - the checkpoint will be retried on next invocation
        }
        return {
            Status: exports.InvocationStatus.SUCCEEDED,
            Result: serializedResult,
        };
    }
    catch (error) {
        log("❌", "Handler threw an error:", error);
        // Check if this is an unrecoverable invocation error (includes checkpoint invocation failures)
        if (isUnrecoverableInvocationError(error)) {
            log("🛑", "Unrecoverable invocation error - terminating Lambda execution");
            throw error; // Re-throw the error to terminate Lambda execution
        }
        // Wait for any pending checkpoints to complete before returning error
        try {
            await durableExecution.checkpointManager.waitForQueueCompletion();
        }
        catch (waitError) {
            log("⚠️", "Error waiting for checkpoint queue completion:", waitError);
            // Continue anyway - the checkpoint will be retried on next invocation
        }
        return {
            Status: exports.InvocationStatus.FAILED,
            Error: createErrorObjectFromError(error),
        };
    }
}
/**
 * Validates that the event is a proper durable execution input
 */
function validateDurableExecutionEvent(event) {
    const eventObj = event;
    if (!eventObj?.DurableExecutionArn || !eventObj?.CheckpointToken) {
        throw new Error("Unexpected payload provided to start the durable execution.\n" +
            "Check your resource configurations to confirm the durability is set.");
    }
}
/**
 * Wraps a durable handler function to create a handler with automatic state persistence,
 * retry logic, and workflow orchestration capabilities.
 *
 * This function transforms your durable handler into a function that integrates
 * with the AWS Durable Execution service. The wrapped handler automatically manages execution state
 * and checkpointing.
 *
 * @typeParam TEvent - The type of the input event your handler expects (defaults to any)
 * @typeParam TResult - The type of the result your handler returns (defaults to any)
 * @typeParam TLogger - The type of custom logger implementation (defaults to DurableLogger)
 *
 * @param handler - Your durable handler function that uses the DurableContext for operations
 * @param config - Optional configuration for custom advanced settings
 *
 * @returns A handler function that automatically manages durability
 *
 * @example
 * **Basic Usage:**
 * ```typescript
 * import { withDurableExecution, DurableExecutionHandler } from '@aws/durable-execution-sdk-js';
 *
 * const durableHandler: DurableExecutionHandler<MyEvent, MyResult> = async (event, context) => {
 *   // Execute durable operations with automatic retry and checkpointing
 *   const userData = await context.step("fetch-user", async () =>
 *     fetchUserFromDB(event.userId)
 *   );
 *
 *   // Wait for external approval
 *   const approval = await context.waitForCallback("user-approval", async (callbackId) => {
 *     await sendApprovalEmail(callbackId, userData);
 *   });
 *
 *   // Process in parallel
 *   const results = await context.parallel("process-data", [
 *     async (ctx) => ctx.step("validate", () => validateData(userData)),
 *     async (ctx) => ctx.step("transform", () => transformData(userData))
 *   ]);
 *
 *   return { success: true, results };
 * };
 *
 * export const handler = withDurableExecution(durableHandler);
 * ```
 *
 * @example
 * **With Custom Configuration:**
 * ```typescript
 * import { LambdaClient } from '@aws-sdk/client-lambda';
 *
 * const customClient = new LambdaClient({
 *   region: 'us-west-2',
 *   maxAttempts: 5
 * });
 *
 * export const handler = withDurableExecution(durableHandler, {
 *   client: customClient
 * });
 * ```
 *
 * @example
 * **Passed Directly to the Handler:**
 * ```typescript
 * export const handler = withDurableExecution(async (event, context) => {
 *   const result = await context.step(async () => processEvent(event));
 *   return result;
 * });
 * ```
 *
 * @public
 */
const withDurableExecution = (handler, config) => {
    return async (event, context) => {
        validateDurableExecutionEvent(event);
        const { executionContext, durableExecutionMode, checkpointToken } = await initializeExecutionContext(event, context, config?.client);
        return runHandler(event, context, executionContext, durableExecutionMode, checkpointToken, handler);
    };
};

const DEFAULT_CONFIG = {
    maxAttempts: 60,
    initialDelay: { seconds: 5 },
    maxDelay: { seconds: 300 }, // 5 minutes
    backoffRate: 1.5,
    jitter: exports.JitterStrategy.FULL,
    timeoutSeconds: undefined, // No timeout by default
};
const applyJitter = (delay, strategy) => {
    switch (strategy) {
        case exports.JitterStrategy.NONE:
            return delay;
        case exports.JitterStrategy.FULL:
            // Random between 0 and delay
            return Math.random() * delay;
        case exports.JitterStrategy.HALF:
            // Random between delay/2 and delay
            return delay / 2 + Math.random() * (delay / 2);
    }
};
/**
 * @public
 */
const createWaitStrategy = (config) => {
    const finalConfig = {
        ...DEFAULT_CONFIG,
        ...config,
    };
    return (result, attemptsMade) => {
        // Check if condition is met
        if (!finalConfig.shouldContinuePolling(result)) {
            return { shouldContinue: false };
        }
        // Check if we've exceeded max attempts
        if (attemptsMade >= finalConfig.maxAttempts) {
            throw new Error(`waitForCondition exceeded maximum attempts (${finalConfig.maxAttempts})`);
        }
        // Calculate delay with exponential backoff
        const initialDelaySeconds = durationToSeconds(finalConfig.initialDelay);
        const maxDelaySeconds = durationToSeconds(finalConfig.maxDelay);
        const baseDelay = Math.min(initialDelaySeconds * Math.pow(finalConfig.backoffRate, attemptsMade - 1), maxDelaySeconds);
        // Apply jitter
        const delayWithJitter = applyJitter(baseDelay, finalConfig.jitter);
        // Ensure delay is an integer >= 1
        const finalDelay = Math.max(1, Math.round(delayWithJitter));
        return { shouldContinue: true, delay: { seconds: finalDelay } };
    };
};

exports.CallbackError = CallbackError;
exports.ChildContextError = ChildContextError;
exports.DurableExecutionApiClient = DurableExecutionApiClient;
exports.DurableExecutionInvocationInputWithClient = DurableExecutionInvocationInputWithClient;
exports.DurableOperationError = DurableOperationError;
exports.DurablePromise = DurablePromise;
exports.InvokeError = InvokeError;
exports.StepError = StepError;
exports.StepInterruptedError = StepInterruptedError;
exports.WaitForConditionError = WaitForConditionError;
exports.createClassSerdes = createClassSerdes;
exports.createClassSerdesWithDates = createClassSerdesWithDates;
exports.createRetryStrategy = createRetryStrategy;
exports.createWaitStrategy = createWaitStrategy;
exports.defaultSerdes = defaultSerdes;
exports.retryPresets = retryPresets;
exports.withDurableExecution = withDurableExecution;
//# sourceMappingURL=index.js.map
