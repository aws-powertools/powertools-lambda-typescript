export {};
//# sourceMappingURL=wait-handler-two-phase.test.d.ts.map