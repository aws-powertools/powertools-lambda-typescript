export {};
//# sourceMappingURL=checkpoint-ancestor.test.d.ts.map