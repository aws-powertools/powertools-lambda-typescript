export {};
//# sourceMappingURL=wait-handler-comparison.test.d.ts.map