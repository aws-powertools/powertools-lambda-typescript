import { WaitForConditionDecision, JitterStrategy, Duration } from "../../types";
/**
 * @public
 */
interface WaitStrategyConfig<T> {
    maxAttempts?: number;
    initialDelay?: Duration;
    maxDelay?: Duration;
    backoffRate?: number;
    jitter?: JitterStrategy;
    shouldContinuePolling: (result: T) => boolean;
    timeoutSeconds?: number;
}
/**
 * @public
 */
export declare const createWaitStrategy: <T>(config: WaitStrategyConfig<T>) => (result: T, attemptsMade: number) => WaitForConditionDecision;
export type { WaitStrategyConfig };
//# sourceMappingURL=wait-strategy-config.d.ts.map