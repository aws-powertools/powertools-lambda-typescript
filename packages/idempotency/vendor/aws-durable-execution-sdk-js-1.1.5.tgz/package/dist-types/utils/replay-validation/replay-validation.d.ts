import { Operation, OperationType } from "@aws-sdk/client-lambda";
import { OperationSubType, ExecutionContext } from "../../types";
export declare const validateReplayConsistency: (stepId: string, currentOperation: {
    type: OperationType;
    name: string | undefined;
    subType: OperationSubType;
}, checkpointData: Operation | undefined, context: ExecutionContext) => void;
//# sourceMappingURL=replay-validation.d.ts.map