import { CheckpointManager } from "../utils/checkpoint/checkpoint-manager";
import { ExecutionContext, DurableLogger } from "../types";
import { EventEmitter } from "events";
export declare const createTestCheckpointManager: (context: ExecutionContext, checkpointToken: string, emitter: EventEmitter, logger: DurableLogger) => CheckpointManager;
//# sourceMappingURL=create-test-checkpoint-manager.d.ts.map