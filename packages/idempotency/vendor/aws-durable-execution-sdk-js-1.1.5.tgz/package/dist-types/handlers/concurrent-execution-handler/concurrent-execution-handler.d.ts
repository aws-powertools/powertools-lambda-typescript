import { ExecutionContext, DurableContext, DurableExecutionMode, ConcurrencyConfig, ConcurrentExecutionItem, ConcurrentExecutor, BatchResult, DurablePromise, DurableLogger } from "../../types";
export declare class ConcurrencyController<Logger extends DurableLogger> {
    private readonly operationName;
    private readonly skipNextOperation;
    constructor(operationName: string, skipNextOperation: () => void);
    private isChildEntityCompleted;
    private getCompletionReason;
    executeItems<T, R>(items: ConcurrentExecutionItem<T>[], executor: ConcurrentExecutor<T, R, Logger>, parentContext: DurableContext<Logger>, config: ConcurrencyConfig<R>, durableExecutionMode?: DurableExecutionMode, entityId?: string, executionContext?: ExecutionContext): Promise<BatchResult<R>>;
    private replayItems;
    private executeItemsConcurrently;
}
export declare const createConcurrentExecutionHandler: <Logger extends DurableLogger>(context: ExecutionContext, runInChildContext: DurableContext<Logger>["runInChildContext"], skipNextOperation: () => void) => <TItem, TResult>(nameOrItems: string | undefined | ConcurrentExecutionItem<TItem>[], itemsOrExecutor?: ConcurrentExecutionItem<TItem>[] | ConcurrentExecutor<TItem, TResult, Logger>, executorOrConfig?: ConcurrentExecutor<TItem, TResult, Logger> | ConcurrencyConfig<TResult>, maybeConfig?: ConcurrencyConfig<TResult>) => DurablePromise<BatchResult<TResult>>;
//# sourceMappingURL=concurrent-execution-handler.d.ts.map