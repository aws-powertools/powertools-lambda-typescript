import { Operation } from "@aws-sdk/client-lambda";
/**
 * Creates an MD5 hash of the input string for better performance than SHA-256
 * @param input - The string to hash
 * @returns The truncated hexadecimal hash string
 */
export declare const hashId: (input: string) => string;
/**
 * Helper function to get step data using the original stepId
 * This function handles the hashing internally so callers don't need to worry about it
 * @param stepData - The stepData record from context
 * @param stepId - The original stepId (will be hashed internally)
 * @returns The operation data or undefined if not found
 */
export declare const getStepData: (stepData: Record<string, Operation>, stepId: string) => Operation | undefined;
//# sourceMappingURL=step-id-utils.d.ts.map