import { BatchResult } from "../../types";
/**
 * Creates a predefined summary generator for parallel operations
 */
export declare const createParallelSummaryGenerator: <T>() => (result: BatchResult<T>) => string;
/**
 * Creates a predefined summary generator for map operations
 */
export declare const createMapSummaryGenerator: <T>() => (result: BatchResult<T>) => string;
//# sourceMappingURL=summary-generators.d.ts.map