export {};
//# sourceMappingURL=wait-for-condition-handler.timing.test.d.ts.map