export {};
//# sourceMappingURL=termination-manager-checkpoint.test.d.ts.map