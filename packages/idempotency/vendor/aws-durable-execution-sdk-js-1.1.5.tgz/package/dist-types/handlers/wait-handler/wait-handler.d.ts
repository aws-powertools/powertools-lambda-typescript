import { ExecutionContext, Duration } from "../../types";
import { Checkpoint } from "../../utils/checkpoint/checkpoint-helper";
import { DurablePromise } from "../../types/durable-promise";
export declare const createWaitHandler: (context: ExecutionContext, checkpoint: Checkpoint, createStepId: () => string, parentId?: string, checkAndUpdateReplayMode?: () => void) => {
    (name: string, duration: Duration): DurablePromise<void>;
    (duration: Duration): DurablePromise<void>;
};
//# sourceMappingURL=wait-handler.d.ts.map