import { OperationUpdate, Operation } from "@aws-sdk/client-lambda";
import { DurableExecutionClient } from "../../types/durable-execution";
import { TerminationManager } from "../../termination-manager/termination-manager";
import { EventEmitter } from "events";
import { DurableLogger } from "../../types/durable-logger";
import { Checkpoint } from "./checkpoint-helper";
import { OperationLifecycleState, OperationInfo, OperationMetadata } from "../../types";
export declare const STEP_DATA_UPDATED_EVENT = "stepDataUpdated";
export declare class CheckpointManager implements Checkpoint {
    private durableExecutionArn;
    private stepData;
    private storage;
    private terminationManager;
    private stepDataEmitter;
    private logger;
    private finishedAncestors;
    private queue;
    private isProcessing;
    private currentTaskToken;
    private forceCheckpointPromises;
    private queueCompletionResolver;
    private readonly MAX_PAYLOAD_SIZE;
    private readonly MAX_ITEMS_IN_BATCH;
    private isTerminating;
    private static textEncoder;
    private operations;
    private terminationTimer;
    private terminationReason;
    constructor(durableExecutionArn: string, stepData: Record<string, Operation>, storage: DurableExecutionClient, terminationManager: TerminationManager, initialTaskToken: string, stepDataEmitter: EventEmitter, logger: DurableLogger, finishedAncestors: Set<string>);
    setTerminating(): void;
    /**
     * Mark an ancestor as finished (for run-in-child-context operations)
     */
    markAncestorFinished(stepId: string): void;
    /**
     * Extract parent ID from hierarchical stepId (e.g., "1-2-3" -\> "1-2")
     */
    private getParentId;
    /**
     * Checks if any ancestor of the given stepId is finished
     * Only applies to operations that are descendants of run-in-child-context operations
     */
    private hasFinishedAncestor;
    forceCheckpoint(): Promise<void>;
    waitForQueueCompletion(): Promise<void>;
    clearQueue(): void;
    force(): Promise<void>;
    checkpoint(stepId: string, data: Partial<OperationUpdate>): Promise<void>;
    private classifyCheckpointError;
    private processQueue;
    private notifyQueueCompletion;
    private processBatch;
    private updateStepDataFromCheckpointResponse;
    private resolveWaitingOperation;
    getQueueStatus(): {
        queueLength: number;
        isProcessing: boolean;
    };
    markOperationState(stepId: string, state: OperationLifecycleState, options?: {
        metadata?: OperationMetadata;
        endTimestamp?: Date;
    }): void;
    waitForRetryTimer(stepId: string): Promise<void>;
    waitForStatusChange(stepId: string): Promise<void>;
    markOperationAwaited(stepId: string): void;
    getOperationState(stepId: string): OperationLifecycleState | undefined;
    getAllOperations(): Map<string, OperationInfo>;
    private cleanupOperation;
    private cleanupAllOperations;
    /**
     * Determines if the function should terminate.
     * @returns TerminationReason if the function should terminate, or undefined if the function should not terminate
     */
    private shouldTerminate;
    private checkAndTerminate;
    private abortTermination;
    private scheduleTermination;
    private executeTermination;
    private determineTerminationReason;
    private startTimerWithPolling;
    private forceRefreshAndCheckStatus;
}
//# sourceMappingURL=checkpoint-manager.d.ts.map