import { ExecutionContext } from "../types";
/**
 * Creates a mock ExecutionContext for testing purposes
 * @param overrides - Optional overrides for specific properties
 * @returns A mocked ExecutionContext
 */
export declare const createMockExecutionContext: (overrides?: Partial<ExecutionContext & {
    mutex?: unknown;
}>) => jest.Mocked<ExecutionContext>;
//# sourceMappingURL=mock-context.d.ts.map