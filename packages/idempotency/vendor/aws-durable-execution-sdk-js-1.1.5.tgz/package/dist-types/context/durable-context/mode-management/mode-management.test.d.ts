export {};
//# sourceMappingURL=mode-management.test.d.ts.map