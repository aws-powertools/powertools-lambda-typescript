import { OperationUpdate } from "@aws-sdk/client-lambda";
import { Checkpoint } from "../utils/checkpoint/checkpoint-helper";
export interface CheckpointFunction extends Checkpoint {
    (stepId: string, data: Partial<OperationUpdate>): Promise<void>;
    checkpoint(stepId: string, data: Partial<OperationUpdate>): Promise<void>;
    force(): Promise<void>;
    setTerminating(): void;
    hasPendingAncestorCompletion(stepId: string): boolean;
    waitForQueueCompletion(): Promise<void>;
    markAncestorFinished(stepId: string): void;
}
export declare const createMockCheckpoint: (mockImplementation?: (stepId: string, data: Partial<OperationUpdate>) => Promise<void>) => jest.MockedFunction<CheckpointFunction>;
//# sourceMappingURL=mock-checkpoint.d.ts.map