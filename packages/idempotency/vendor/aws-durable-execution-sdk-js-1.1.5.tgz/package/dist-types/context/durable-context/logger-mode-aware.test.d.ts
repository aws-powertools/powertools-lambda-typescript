export {};
//# sourceMappingURL=logger-mode-aware.test.d.ts.map