export {};
//# sourceMappingURL=callback-promise.test.d.ts.map