export {};
//# sourceMappingURL=summary-generators.test.d.ts.map