import { ExecutionContext } from "../../types";
import { UnrecoverableError } from "../../errors/unrecoverable-error/unrecoverable-error";
/**
 * Terminates execution for unrecoverable errors and returns a never-resolving promise
 * @param context - The execution context containing the termination manager
 * @param error - The unrecoverable error that caused termination
 * @param stepIdentifier - The step name or ID for error messaging
 * @returns A never-resolving promise
 */
export declare function terminateForUnrecoverableError<T>(context: ExecutionContext, error: UnrecoverableError, stepIdentifier: string): Promise<T>;
//# sourceMappingURL=termination-helper.d.ts.map