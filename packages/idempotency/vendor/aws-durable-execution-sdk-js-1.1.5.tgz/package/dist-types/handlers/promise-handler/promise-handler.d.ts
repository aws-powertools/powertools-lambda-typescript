import { DurableContext, DurablePromise, DurableLogger } from "../../types";
export declare const createPromiseHandler: <Logger extends DurableLogger>(step: DurableContext<Logger>["step"]) => {
    all: <T>(nameOrPromises: string | undefined | DurablePromise<T>[], maybePromises?: DurablePromise<T>[]) => DurablePromise<T[]>;
    allSettled: <T>(nameOrPromises: string | undefined | DurablePromise<T>[], maybePromises?: DurablePromise<T>[]) => DurablePromise<PromiseSettledResult<T>[]>;
    any: <T>(nameOrPromises: string | undefined | DurablePromise<T>[], maybePromises?: DurablePromise<T>[]) => DurablePromise<T>;
    race: <T>(nameOrPromises: string | undefined | DurablePromise<T>[], maybePromises?: DurablePromise<T>[]) => DurablePromise<T>;
};
//# sourceMappingURL=promise-handler.d.ts.map