import { ExecutionContext, DurableContext, StepFunc, StepConfig, ChildFunc, ChildConfig, CreateCallbackConfig, CreateCallbackResult, WaitForCallbackSubmitterFunc, WaitForCallbackConfig, WaitForConditionCheckFunc, WaitForConditionConfig, MapFunc, MapConfig, Duration, ParallelFunc, ParallelConfig, NamedParallelBranch, ConcurrentExecutionItem, ConcurrentExecutor, ConcurrencyConfig, LoggerConfig, InvokeConfig, DurableExecutionMode, BatchResult, DurablePromise } from "../../types";
import { Context } from "aws-lambda";
import { CheckpointManager } from "../../utils/checkpoint/checkpoint-manager";
import { EventEmitter } from "events";
import { DurableContextLogger, DurableLogger, DurableLoggingContext } from "../../types/durable-logger";
export interface DurableExecution {
    checkpointManager: CheckpointManager;
    stepDataEmitter: EventEmitter;
    setTerminating(): void;
}
export declare class DurableContextImpl<Logger extends DurableLogger> implements DurableContext<Logger> {
    private _executionContext;
    lambdaContext: Context;
    private _stepPrefix?;
    private _stepCounter;
    private durableLogger;
    private modeAwareLoggingEnabled;
    private checkpoint;
    private durableExecutionMode;
    private _parentId?;
    private modeManagement;
    private durableExecution;
    logger: DurableContextLogger<Logger>;
    readonly executionContext: {
        readonly durableExecutionArn: string;
    };
    constructor(_executionContext: ExecutionContext, lambdaContext: Context, durableExecutionMode: DurableExecutionMode, inheritedLogger: Logger, stepPrefix: string | undefined, durableExecution: DurableExecution, parentId?: string);
    getDurableLoggingContext(): DurableLoggingContext;
    private shouldLog;
    private createModeAwareLogger;
    private createStepId;
    private getNextStepId;
    /**
     * Skips the next operation by incrementing the step counter.
     * Used internally by concurrent execution handler during replay to skip incomplete items.
     * @internal
     */
    private skipNextOperation;
    private checkAndUpdateReplayMode;
    private captureExecutionState;
    private checkForNonResolvingPromise;
    private withModeManagement;
    private withDurableModeManagement;
    step<T>(nameOrFn: string | undefined | StepFunc<T, Logger>, fnOrOptions?: StepFunc<T, Logger> | StepConfig<T>, maybeOptions?: StepConfig<T>): DurablePromise<T>;
    invoke<I, O>(nameOrFuncId: string, funcIdOrInput?: string | I, inputOrConfig?: I | InvokeConfig<I, O>, maybeConfig?: InvokeConfig<I, O>): DurablePromise<O>;
    runInChildContext<T>(nameOrFn: string | undefined | ChildFunc<T, Logger>, fnOrOptions?: ChildFunc<T, Logger> | ChildConfig<T>, maybeOptions?: ChildConfig<T>): DurablePromise<T>;
    wait(nameOrDuration: string | Duration, maybeDuration?: Duration): DurablePromise<void>;
    /**
     * Configure logger behavior for this context
     *
     * This method allows partial configuration - only the properties provided will be updated.
     * For example, calling configureLogger(\{ modeAware: false \}) will only change the modeAware
     * setting without affecting any previously configured custom logger.
     *
     * @param config - Logger configuration options including customLogger and modeAware settings (default: modeAware=true)
     * @example
     * // Set custom logger and enable mode-aware logging
     * context.configureLogger(\{ customLogger: myLogger, modeAware: true \});
     *
     * // Later, disable mode-aware logging without changing the custom logger
     * context.configureLogger(\{ modeAware: false \});
     */
    configureLogger(config: LoggerConfig<Logger>): void;
    createCallback<T>(nameOrConfig?: string | CreateCallbackConfig<T>, maybeConfig?: CreateCallbackConfig<T>): DurablePromise<CreateCallbackResult<T>>;
    waitForCallback<T>(nameOrSubmitter?: string | undefined | WaitForCallbackSubmitterFunc<Logger>, submitterOrConfig?: WaitForCallbackSubmitterFunc<Logger> | WaitForCallbackConfig<T>, maybeConfig?: WaitForCallbackConfig<T>): DurablePromise<T>;
    waitForCondition<T>(nameOrCheckFunc: string | undefined | WaitForConditionCheckFunc<T, Logger>, checkFuncOrConfig?: WaitForConditionCheckFunc<T, Logger> | WaitForConditionConfig<T>, maybeConfig?: WaitForConditionConfig<T>): DurablePromise<T>;
    map<TInput, TOutput>(nameOrItems: string | undefined | TInput[], itemsOrMapFunc: TInput[] | MapFunc<TInput, TOutput, Logger>, mapFuncOrConfig?: MapFunc<TInput, TOutput, Logger> | MapConfig<TInput, TOutput>, maybeConfig?: MapConfig<TInput, TOutput>): DurablePromise<BatchResult<TOutput>>;
    parallel<T>(nameOrBranches: string | undefined | (ParallelFunc<T, Logger> | NamedParallelBranch<T, Logger>)[], branchesOrConfig?: (ParallelFunc<T, Logger> | NamedParallelBranch<T, Logger>)[] | ParallelConfig<T>, maybeConfig?: ParallelConfig<T>): DurablePromise<BatchResult<T>>;
    _executeConcurrently<TItem, TResult>(nameOrItems: string | undefined | ConcurrentExecutionItem<TItem>[], itemsOrExecutor?: ConcurrentExecutionItem<TItem>[] | ConcurrentExecutor<TItem, TResult, Logger>, executorOrConfig?: ConcurrentExecutor<TItem, TResult, Logger> | ConcurrencyConfig<TResult>, maybeConfig?: ConcurrencyConfig<TResult>): DurablePromise<BatchResult<TResult>>;
    get promise(): DurableContext<Logger>["promise"];
}
export declare const createDurableContext: <Logger extends DurableLogger>(executionContext: ExecutionContext, parentContext: Context, durableExecutionMode: DurableExecutionMode, inheritedLogger: Logger, stepPrefix: string | undefined, durableExecution: DurableExecution, parentId?: string) => DurableContextImpl<Logger>;
//# sourceMappingURL=durable-context.d.ts.map