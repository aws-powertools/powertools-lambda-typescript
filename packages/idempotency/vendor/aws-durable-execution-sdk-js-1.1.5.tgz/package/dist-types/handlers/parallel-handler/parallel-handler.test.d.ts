export {};
//# sourceMappingURL=parallel-handler.test.d.ts.map