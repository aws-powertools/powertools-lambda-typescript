import { BatchItemStatus, BatchItem, BatchResult } from "../../types";
import { ChildContextError } from "../../errors/durable-error/durable-error";
import { Serdes } from "../../utils/serdes/serdes";
export declare class BatchResultImpl<R> implements BatchResult<R> {
    readonly all: Array<BatchItem<R>>;
    readonly completionReason: "ALL_COMPLETED" | "MIN_SUCCESSFUL_REACHED" | "FAILURE_TOLERANCE_EXCEEDED";
    constructor(all: Array<BatchItem<R>>, completionReason: "ALL_COMPLETED" | "MIN_SUCCESSFUL_REACHED" | "FAILURE_TOLERANCE_EXCEEDED");
    succeeded(): Array<BatchItem<R> & {
        result: R;
    }>;
    failed(): Array<BatchItem<R> & {
        error: ChildContextError;
    }>;
    started(): Array<BatchItem<R> & {
        status: BatchItemStatus.STARTED;
    }>;
    get status(): BatchItemStatus.SUCCEEDED | BatchItemStatus.FAILED;
    get hasFailure(): boolean;
    throwIfError(): void;
    getResults(): Array<R>;
    getErrors(): Array<ChildContextError>;
    get successCount(): number;
    get failureCount(): number;
    get startedCount(): number;
    get totalCount(): number;
}
/**
 * Restores methods to deserialized BatchResult data
 */
export declare function restoreBatchResult<R>(data: unknown): BatchResult<R>;
/**
 * Creates a Serdes for BatchResult that properly handles error serialization
 */
export declare function createBatchResultSerdes<R>(): Serdes<BatchResult<R>>;
//# sourceMappingURL=batch-result.d.ts.map