import { DurablePromise } from "../../../types";
import { DurableExecutionMode } from "../../../types/core";
export declare class ModeManagement {
    private captureExecutionState;
    private checkAndUpdateReplayMode;
    private checkForNonResolvingPromise;
    private getDurableExecutionMode;
    private setDurableExecutionMode;
    constructor(captureExecutionState: () => boolean, checkAndUpdateReplayMode: () => void, checkForNonResolvingPromise: () => Promise<never> | null, getDurableExecutionMode: () => DurableExecutionMode, setDurableExecutionMode: (mode: DurableExecutionMode) => void);
    withModeManagement<T>(operation: () => Promise<T>): Promise<T>;
    withDurableModeManagement<T>(operation: () => DurablePromise<T>): DurablePromise<T>;
}
//# sourceMappingURL=mode-management.d.ts.map