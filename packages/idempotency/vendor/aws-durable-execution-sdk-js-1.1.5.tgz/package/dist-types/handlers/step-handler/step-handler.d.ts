import { ExecutionContext, StepFunc, StepConfig, DurablePromise } from "../../types";
import { Context } from "aws-lambda";
import { Checkpoint } from "../../utils/checkpoint/checkpoint-helper";
import { DurableLogger } from "../../types/durable-logger";
export declare const createStepHandler: <Logger extends DurableLogger>(context: ExecutionContext, checkpoint: Checkpoint, parentContext: Context, createStepId: () => string, logger: Logger, parentId?: string) => <T>(nameOrFn: string | undefined | StepFunc<T, Logger>, fnOrOptions?: StepFunc<T, Logger> | StepConfig<T>, maybeOptions?: StepConfig<T>) => DurablePromise<T>;
//# sourceMappingURL=step-handler.d.ts.map