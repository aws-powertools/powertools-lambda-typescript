import { BatchResult, BatchItem, BatchItemStatus } from "../types";
import { ChildContextError } from "../errors/durable-error/durable-error";
export declare class MockBatchResult<R> implements BatchResult<R> {
    readonly all: Array<BatchItem<R>>;
    readonly completionReason: "ALL_COMPLETED" | "MIN_SUCCESSFUL_REACHED" | "FAILURE_TOLERANCE_EXCEEDED";
    constructor(all: Array<BatchItem<R>>, completionReason?: "ALL_COMPLETED" | "MIN_SUCCESSFUL_REACHED" | "FAILURE_TOLERANCE_EXCEEDED");
    succeeded(): Array<BatchItem<R> & {
        result: R;
    }>;
    failed(): Array<BatchItem<R> & {
        error: ChildContextError;
    }>;
    started(): Array<BatchItem<R> & {
        status: BatchItemStatus.STARTED;
    }>;
    get status(): BatchItemStatus.SUCCEEDED | BatchItemStatus.FAILED;
    get hasFailure(): boolean;
    throwIfError(): void;
    getResults(): Array<R>;
    getErrors(): Array<ChildContextError>;
    get successCount(): number;
    get failureCount(): number;
    get startedCount(): number;
    get totalCount(): number;
}
//# sourceMappingURL=mock-batch-result.d.ts.map