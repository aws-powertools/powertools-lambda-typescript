import { ExecutionContext, CreateCallbackConfig, CreateCallbackResult, DurablePromise } from "../../types";
import { Checkpoint } from "../../utils/checkpoint/checkpoint-helper";
import { Serdes } from "../../utils/serdes/serdes";
export declare const createPassThroughSerdes: <T>() => Serdes<T>;
export declare const createCallback: (context: ExecutionContext, checkpoint: Checkpoint, createStepId: () => string, checkAndUpdateReplayMode: () => void, parentId?: string) => <T>(nameOrConfig?: string | undefined | CreateCallbackConfig<T>, maybeConfig?: CreateCallbackConfig<T>) => DurablePromise<CreateCallbackResult<T>>;
//# sourceMappingURL=callback.d.ts.map