export declare const safeStringify: (data: unknown) => string;
//# sourceMappingURL=safe-stringify.d.ts.map