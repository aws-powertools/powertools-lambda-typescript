export {};
//# sourceMappingURL=wait-handler.test.d.ts.map