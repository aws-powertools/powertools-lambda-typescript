/**
 * Error thrown when a step with AT_MOST_ONCE_PER_RETRY semantics was started but interrupted
 * before completion.
 * @public
 */
export declare class StepInterruptedError extends Error {
    constructor(_stepId: string, _stepName?: string);
}
//# sourceMappingURL=step-errors.d.ts.map