import { DurableLogLevel } from "../../types";
import { DurableLogger, DurableLoggingContext } from "../../types/durable-logger";
export interface LoggingExecutionContext {
    durableExecutionArn: string;
    requestId: string;
    tenantId: string | undefined;
}
type DurableLogField = unknown;
/**
 * Default logger class that outputs structured logs to console.
 *
 * This logger emulates the AWS Lambda Runtime Interface Client (RIC) console patching
 * behavior to maintain parity with standard Lambda function logging while providing
 * structured output suitable for durable execution contexts.
 *
 * Key RIC behavior emulation:
 * - Respects AWS_LAMBDA_LOG_LEVEL environment variable for log filtering
 * - Uses priority-based level filtering (DEBUG=2, INFO=3, WARN=4, ERROR=5)
 * - Outputs structured JSON with timestamp, requestId, executionArn, and other metadata
 * - Handles Error objects with structured error information extraction
 * - Uses Node.js Console instance for proper stdout/stderr routing
 * - Applies util.format for message formatting (same as console.log behavior)
 *
 * Individual logger methods (info, error, warn, debug) are dynamically enabled/disabled
 * based on the configured log level, defaulting to no-op functions when disabled.
 * This mirrors how RIC patches console methods conditionally.
 */
export declare class DefaultLogger implements DurableLogger {
    private consoleLogger;
    private durableLoggingContext;
    private executionContext;
    private noOpLog;
    constructor(executionContext?: LoggingExecutionContext);
    private configureLogLevel;
    private ensureDurableLoggingContext;
    log(level: `${DurableLogLevel}`, message?: DurableLogField, ...optionalParams: DurableLogField[]): void;
    info: (message?: DurableLogField, ...optionalParams: DurableLogField[]) => void;
    error: (message?: DurableLogField, ...optionalParams: DurableLogField[]) => void;
    warn: (message?: DurableLogField, ...optionalParams: DurableLogField[]) => void;
    debug: (message?: DurableLogField, ...optionalParams: DurableLogField[]) => void;
    configureDurableLoggingContext(durableLoggingContext: DurableLoggingContext): void;
}
/**
 * Creates a default logger that outputs structured logs to console.
 *
 * @param executionContext - Optional execution context for logging
 * @returns DefaultLogger instance
 */
export declare const createDefaultLogger: (executionContext?: LoggingExecutionContext) => DurableLogger;
export {};
//# sourceMappingURL=default-logger.d.ts.map