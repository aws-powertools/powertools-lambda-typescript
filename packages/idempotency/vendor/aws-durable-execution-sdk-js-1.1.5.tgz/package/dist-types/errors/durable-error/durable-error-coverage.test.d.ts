export {};
//# sourceMappingURL=durable-error-coverage.test.d.ts.map