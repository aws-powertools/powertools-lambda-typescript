export {};
//# sourceMappingURL=error-object.test.d.ts.map