import { UnrecoverableExecutionError } from "../unrecoverable-error/unrecoverable-error";
import { TerminationReason } from "../../termination-manager/types";
/**
 * Error thrown when non-deterministic code is detected during replay
 */
export declare class NonDeterministicExecutionError extends UnrecoverableExecutionError {
    readonly terminationReason = TerminationReason.CUSTOM;
    constructor(message: string);
}
//# sourceMappingURL=non-deterministic-error.d.ts.map