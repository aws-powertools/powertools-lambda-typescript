export {};
//# sourceMappingURL=logger-property.test.d.ts.map