export {};
//# sourceMappingURL=checkpoint-termination.test.d.ts.map