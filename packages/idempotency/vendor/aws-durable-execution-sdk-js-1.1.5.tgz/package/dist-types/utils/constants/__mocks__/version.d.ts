export declare const SDK_NAME = "aws-durable-execution-sdk-js";
export declare const SDK_VERSION: string;
//# sourceMappingURL=version.d.ts.map