import { CheckpointManager } from "../utils/checkpoint/checkpoint-manager";
import { OperationUpdate } from "@aws-sdk/client-lambda";
export declare class MockCheckpointManager extends CheckpointManager {
    checkpointCalls: Array<{
        stepId: string;
        data: Partial<OperationUpdate>;
    }>;
    forceCheckpointCalls: number;
    setTerminatingCalls: number;
    constructor();
    checkpoint(stepId: string, data: Partial<OperationUpdate>): Promise<void>;
    forceCheckpoint(): Promise<void>;
    setTerminating(): void;
    getQueueStatus(): {
        queueLength: number;
        isProcessing: boolean;
    };
}
export declare const createMockCheckpointManager: () => MockCheckpointManager;
//# sourceMappingURL=mock-checkpoint-manager.d.ts.map