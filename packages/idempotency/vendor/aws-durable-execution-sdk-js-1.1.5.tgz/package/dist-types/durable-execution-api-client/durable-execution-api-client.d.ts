import { CheckpointDurableExecutionRequest, CheckpointDurableExecutionResponse, GetDurableExecutionStateRequest, GetDurableExecutionStateResponse, LambdaClient } from "@aws-sdk/client-lambda";
import { DurableExecutionClient } from "../types/durable-execution";
import { DurableLogger } from "../types/durable-logger";
/**
 * Durable execution client which uses an API-based LambdaClient
 * with built-in error logging. By default, the Lambda client will
 * have custom timeouts set.
 *
 * @public
 */
export declare class DurableExecutionApiClient implements DurableExecutionClient {
    private readonly client;
    constructor(client?: LambdaClient);
    /**
     * Gets operation state data from the durable execution
     * @param params - The GetDurableExecutionState request
     * @param logger - Optional developer logger for error reporting
     * @returns Response with operations data
     */
    getExecutionState(params: GetDurableExecutionStateRequest, logger?: DurableLogger): Promise<GetDurableExecutionStateResponse>;
    /**
     * Checkpoints the durable execution with operation updates
     * @param params - The checkpoint request
     * @param logger - Optional developer logger for error reporting
     * @returns Checkpoint response
     */
    checkpoint(params: CheckpointDurableExecutionRequest, logger?: DurableLogger): Promise<CheckpointDurableExecutionResponse>;
}
//# sourceMappingURL=durable-execution-api-client.d.ts.map