import { ExecutionContext, WaitForConditionCheckFunc, WaitForConditionConfig, DurablePromise } from "../../types";
import { Checkpoint } from "../../utils/checkpoint/checkpoint-helper";
import { DurableLogger } from "../../types/durable-logger";
export declare const createWaitForConditionHandler: <Logger extends DurableLogger>(context: ExecutionContext, checkpoint: Checkpoint, createStepId: () => string, logger: Logger, parentId: string | undefined) => <T>(nameOrCheck: string | undefined | WaitForConditionCheckFunc<T, Logger>, checkOrConfig?: WaitForConditionCheckFunc<T, Logger> | WaitForConditionConfig<T>, maybeConfig?: WaitForConditionConfig<T>) => DurablePromise<T>;
//# sourceMappingURL=wait-for-condition-handler.d.ts.map