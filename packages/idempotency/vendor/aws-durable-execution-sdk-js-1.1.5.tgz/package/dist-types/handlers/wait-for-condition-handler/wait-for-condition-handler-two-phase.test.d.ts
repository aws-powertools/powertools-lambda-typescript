export {};
//# sourceMappingURL=wait-for-condition-handler-two-phase.test.d.ts.map