export {};
//# sourceMappingURL=wait-for-callback-handler.test.d.ts.map