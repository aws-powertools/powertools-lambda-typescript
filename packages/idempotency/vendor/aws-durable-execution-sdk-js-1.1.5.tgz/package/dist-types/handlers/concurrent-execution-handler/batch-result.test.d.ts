export {};
//# sourceMappingURL=batch-result.test.d.ts.map