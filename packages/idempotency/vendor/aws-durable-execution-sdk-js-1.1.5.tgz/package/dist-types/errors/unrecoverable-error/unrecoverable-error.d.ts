import { TerminationReason } from "../../termination-manager/types";
/**
 * Base class for all unrecoverable errors
 * Any error that inherits from this class indicates a fatal condition
 */
export declare abstract class UnrecoverableError extends Error {
    readonly originalError?: Error | undefined;
    abstract readonly terminationReason: TerminationReason;
    readonly isUnrecoverable = true;
    constructor(message: string, originalError?: Error | undefined);
}
/**
 * Base class for errors that make the entire execution unrecoverable
 * These errors indicate that the execution cannot continue and should be terminated completely
 */
export declare abstract class UnrecoverableExecutionError extends UnrecoverableError {
    readonly isUnrecoverableExecution = true;
    constructor(message: string, originalError?: Error);
}
/**
 * Base class for errors that make the current invocation unrecoverable
 * These errors indicate that the current Lambda invocation should be terminated,
 * but the execution might be able to continue with a new invocation
 */
export declare abstract class UnrecoverableInvocationError extends UnrecoverableError {
    readonly isUnrecoverableInvocation = true;
    constructor(message: string, originalError?: Error);
}
/**
 * Type guard to check if an error is any kind of unrecoverable error
 */
export declare function isUnrecoverableError(error: unknown): error is UnrecoverableError;
/**
 * Type guard to check if an error is an unrecoverable execution error
 */
export declare function isUnrecoverableExecutionError(error: unknown): error is UnrecoverableExecutionError;
/**
 * Type guard to check if an error is an unrecoverable invocation error
 */
export declare function isUnrecoverableInvocationError(error: unknown): error is UnrecoverableInvocationError;
//# sourceMappingURL=unrecoverable-error.d.ts.map