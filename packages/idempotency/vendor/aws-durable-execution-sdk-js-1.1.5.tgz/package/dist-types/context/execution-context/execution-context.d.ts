import { LambdaClient } from "@aws-sdk/client-lambda";
import { DurableExecutionInvocationInput, ExecutionContext, DurableExecutionMode } from "../../types";
import { Context } from "aws-lambda";
export declare const initializeExecutionContext: (event: DurableExecutionInvocationInput, context: Context, lambdaClient?: LambdaClient) => Promise<{
    executionContext: ExecutionContext;
    durableExecutionMode: DurableExecutionMode;
    checkpointToken: string;
}>;
//# sourceMappingURL=execution-context.d.ts.map