import { ExecutionContext, DurablePromise } from "../../types";
import { Serdes } from "../../utils/serdes/serdes";
import { Checkpoint } from "../../utils/checkpoint/checkpoint-helper";
export declare const createCallbackPromise: <T>(context: ExecutionContext, checkpoint: Checkpoint, stepId: string, stepName: string | undefined, serdes: Omit<Serdes<T>, "serialize">, checkAndUpdateReplayMode: () => void) => DurablePromise<T>;
//# sourceMappingURL=callback-promise.d.ts.map