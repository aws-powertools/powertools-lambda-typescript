import { Operation } from "@aws-sdk/client-lambda";
import { DurableExecutionClient } from "../../types/durable-execution";
import { DurableExecutionInvocationInput } from "../../types";
/**
 * Custom DurableExecutionInvocationInput which uses a custom durable
 * execution client instead of the API-based LambdaClient.
 *
 * @internal
 */
export declare class DurableExecutionInvocationInputWithClient implements DurableExecutionInvocationInput {
    readonly durableExecutionClient: DurableExecutionClient;
    readonly InitialExecutionState: {
        Operations: Operation[];
        NextMarker?: string | undefined;
    };
    readonly DurableExecutionArn: string;
    readonly CheckpointToken: string;
    constructor(params: DurableExecutionInvocationInput, durableExecutionClient: DurableExecutionClient);
    static isInstance(event: unknown): event is DurableExecutionInvocationInputWithClient;
    get [Symbol.toStringTag](): string;
}
//# sourceMappingURL=durable-execution-invocation-input.d.ts.map