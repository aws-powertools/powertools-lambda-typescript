import { TerminationReason } from "../../termination-manager/types";
import { TerminationManager } from "../../termination-manager/termination-manager";
import { UnrecoverableInvocationError } from "../unrecoverable-error/unrecoverable-error";
import { SerdesContext } from "../../utils/serdes/serdes";
/**
 * Error thrown when serdes operation fails and terminates Lambda invocation
 * This is used by withDurableExecution to terminate the Lambda when serdes fails
 */
export declare class SerdesFailedError extends UnrecoverableInvocationError {
    readonly terminationReason = TerminationReason.SERDES_FAILED;
    constructor(message?: string, originalError?: Error);
}
/**
 * Utility function to safely execute serialization with proper error handling
 * Instead of throwing unrecoverable errors, this directly terminates execution
 */
export declare function safeSerialize<T>(serdes: {
    serialize: (value: T | undefined, context: SerdesContext) => Promise<string | undefined>;
}, value: T | undefined, stepId: string, stepName: string | undefined, terminationManager: TerminationManager, durableExecutionArn: string): Promise<string | undefined>;
/**
 * Utility function to safely execute deserialization with proper error handling
 * Instead of throwing unrecoverable errors, this directly terminates execution
 */
export declare function safeDeserialize<T>(serdes: {
    deserialize: (data: string | undefined, context: SerdesContext) => Promise<T | undefined>;
}, data: string | undefined, stepId: string, stepName: string | undefined, terminationManager: TerminationManager, durableExecutionArn: string): Promise<T | undefined>;
//# sourceMappingURL=serdes-errors.d.ts.map