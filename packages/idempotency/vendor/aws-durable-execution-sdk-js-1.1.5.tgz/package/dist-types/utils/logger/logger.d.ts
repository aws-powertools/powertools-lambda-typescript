export declare const log: (emoji: string, message: string, data?: unknown) => void;
//# sourceMappingURL=logger.d.ts.map