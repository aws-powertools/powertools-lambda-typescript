import { TerminationManager } from "../../termination-manager/termination-manager";
import { DurableExecutionMode } from "../../types";
interface ContextInfo {
    contextId: string;
    parentId?: string;
    attempt?: number;
    durableExecutionMode?: DurableExecutionMode;
}
export declare const getActiveContext: () => ContextInfo | undefined;
export declare const runWithContext: <T>(contextId: string, parentId: string | undefined, fn: () => T, attempt?: number, durableExecutionMode?: DurableExecutionMode) => T;
export declare const validateContextUsage: (operationContextId: string | undefined, operationName: string, terminationManager: TerminationManager) => void;
export {};
//# sourceMappingURL=context-tracker.d.ts.map