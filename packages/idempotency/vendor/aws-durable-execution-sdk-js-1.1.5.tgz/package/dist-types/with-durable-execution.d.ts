import { DurableLogger } from "./types";
import { DurableExecutionConfig, DurableExecutionHandler, DurableLambdaHandler } from "./types/durable-execution";
/**
 * Wraps a durable handler function to create a handler with automatic state persistence,
 * retry logic, and workflow orchestration capabilities.
 *
 * This function transforms your durable handler into a function that integrates
 * with the AWS Durable Execution service. The wrapped handler automatically manages execution state
 * and checkpointing.
 *
 * @typeParam TEvent - The type of the input event your handler expects (defaults to any)
 * @typeParam TResult - The type of the result your handler returns (defaults to any)
 * @typeParam TLogger - The type of custom logger implementation (defaults to DurableLogger)
 *
 * @param handler - Your durable handler function that uses the DurableContext for operations
 * @param config - Optional configuration for custom advanced settings
 *
 * @returns A handler function that automatically manages durability
 *
 * @example
 * **Basic Usage:**
 * ```typescript
 * import { withDurableExecution, DurableExecutionHandler } from '@aws/durable-execution-sdk-js';
 *
 * const durableHandler: DurableExecutionHandler<MyEvent, MyResult> = async (event, context) => {
 *   // Execute durable operations with automatic retry and checkpointing
 *   const userData = await context.step("fetch-user", async () =>
 *     fetchUserFromDB(event.userId)
 *   );
 *
 *   // Wait for external approval
 *   const approval = await context.waitForCallback("user-approval", async (callbackId) => {
 *     await sendApprovalEmail(callbackId, userData);
 *   });
 *
 *   // Process in parallel
 *   const results = await context.parallel("process-data", [
 *     async (ctx) => ctx.step("validate", () => validateData(userData)),
 *     async (ctx) => ctx.step("transform", () => transformData(userData))
 *   ]);
 *
 *   return { success: true, results };
 * };
 *
 * export const handler = withDurableExecution(durableHandler);
 * ```
 *
 * @example
 * **With Custom Configuration:**
 * ```typescript
 * import { LambdaClient } from '@aws-sdk/client-lambda';
 *
 * const customClient = new LambdaClient({
 *   region: 'us-west-2',
 *   maxAttempts: 5
 * });
 *
 * export const handler = withDurableExecution(durableHandler, {
 *   client: customClient
 * });
 * ```
 *
 * @example
 * **Passed Directly to the Handler:**
 * ```typescript
 * export const handler = withDurableExecution(async (event, context) => {
 *   const result = await context.step(async () => processEvent(event));
 *   return result;
 * });
 * ```
 *
 * @public
 */
export declare const withDurableExecution: <TEvent = any, TResult = any, TLogger extends DurableLogger = DurableLogger>(handler: DurableExecutionHandler<TEvent, TResult, TLogger>, config?: DurableExecutionConfig) => DurableLambdaHandler;
//# sourceMappingURL=with-durable-execution.d.ts.map