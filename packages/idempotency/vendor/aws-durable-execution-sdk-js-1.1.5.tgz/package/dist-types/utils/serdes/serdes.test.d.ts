export {};
//# sourceMappingURL=serdes.test.d.ts.map