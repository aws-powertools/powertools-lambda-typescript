export declare enum TerminationReason {
    OPERATION_TERMINATED = "OPERATION_TERMINATED",
    RETRY_SCHEDULED = "RETRY_SCHEDULED",
    RETRY_INTERRUPTED_STEP = "RETRY_INTERRUPTED_STEP",
    WAIT_SCHEDULED = "WAIT_SCHEDULED",
    CALLBACK_PENDING = "CALLBACK_PENDING",
    CHECKPOINT_FAILED = "CHECKPOINT_FAILED",
    SERDES_FAILED = "SERDES_FAILED",
    CONTEXT_VALIDATION_ERROR = "CONTEXT_VALIDATION_ERROR",
    CUSTOM = "CUSTOM"
}
export interface TerminationResponse {
    reason: TerminationReason;
    message: string;
    error?: Error;
}
export interface TerminationOptions {
    reason?: TerminationReason;
    message?: string;
    error?: Error;
    cleanup?: () => Promise<void>;
}
export interface TerminationDetails extends TerminationResponse {
    cleanup?: () => Promise<void>;
}
//# sourceMappingURL=types.d.ts.map