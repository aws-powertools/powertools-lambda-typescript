import { ErrorObject } from "@aws-sdk/client-lambda";
/**
 * Base class for all durable operation errors
 * @public
 */
export declare abstract class DurableOperationError extends Error {
    abstract readonly errorType: string;
    cause?: Error;
    errorData?: string;
    stackTrace?: string[];
    constructor(message: string, cause?: Error, errorData?: string);
    /**
     * Create DurableOperationError from ErrorObject (for reconstruction during replay)
     */
    static fromErrorObject(errorObject: ErrorObject): DurableOperationError;
    /**
     * Convert to ErrorObject for serialization
     */
    toErrorObject(): ErrorObject;
}
/**
 * Error thrown when a step operation fails
 * @public
 */
export declare class StepError extends DurableOperationError {
    readonly errorType = "StepError";
    constructor(message?: string, cause?: Error, errorData?: string);
}
/**
 * Error thrown when a callback operation fails
 * @public
 */
export declare class CallbackError extends DurableOperationError {
    readonly errorType = "CallbackError";
    constructor(message?: string, cause?: Error, errorData?: string);
}
/**
 * Error thrown when an invoke operation fails
 * @public
 */
export declare class InvokeError extends DurableOperationError {
    readonly errorType = "InvokeError";
    constructor(message?: string, cause?: Error, errorData?: string);
}
/**
 * Error thrown when a child context operation fails
 * @public
 */
export declare class ChildContextError extends DurableOperationError {
    readonly errorType = "ChildContextError";
    constructor(message?: string, cause?: Error, errorData?: string);
}
/**
 * Error thrown when a wait for condition operation fails
 * @public
 */
export declare class WaitForConditionError extends DurableOperationError {
    readonly errorType = "WaitForConditionError";
    constructor(message?: string, cause?: Error, errorData?: string);
}
//# sourceMappingURL=durable-error.d.ts.map