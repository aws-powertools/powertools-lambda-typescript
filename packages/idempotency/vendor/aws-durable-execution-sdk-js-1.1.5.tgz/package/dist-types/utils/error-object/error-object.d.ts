import { ErrorObject } from "@aws-sdk/client-lambda";
export declare function createErrorObjectFromError(error: unknown, data?: string): ErrorObject;
//# sourceMappingURL=error-object.d.ts.map