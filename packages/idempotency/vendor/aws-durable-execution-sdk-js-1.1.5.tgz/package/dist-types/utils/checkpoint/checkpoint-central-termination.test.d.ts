export {};
//# sourceMappingURL=checkpoint-central-termination.test.d.ts.map