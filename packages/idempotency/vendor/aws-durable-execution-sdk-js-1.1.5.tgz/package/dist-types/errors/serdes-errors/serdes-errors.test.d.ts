export {};
//# sourceMappingURL=serdes-errors.test.d.ts.map