export {};
//# sourceMappingURL=safe-stringify.test.d.ts.map