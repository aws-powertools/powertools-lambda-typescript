import { Context } from "aws-lambda";
import { Operation, CheckpointDurableExecutionResponse } from "@aws-sdk/client-lambda";
import { DurableContextImpl } from "../context/durable-context/durable-context";
import { DurableExecutionClient } from "../types/durable-execution";
import { ExecutionContext, DurableExecutionMode, DurableLogger } from "../types";
/**
 * In-memory storage for testing - no API calls
 */
declare class InMemoryStorage implements DurableExecutionClient {
    private operations;
    getExecutionState(): Promise<{
        Operations: Operation[];
    }>;
    checkpoint(): Promise<CheckpointDurableExecutionResponse>;
    addOperation(operation: Operation): void;
    getOperations(): Operation[];
}
/**
 * Creates a real DurableContext with mocked storage for integration testing
 */
export declare function createTestDurableContext(options?: {
    stepPrefix?: string;
    durableExecutionMode?: DurableExecutionMode;
    existingOperations?: Operation[];
    lambdaContext?: Partial<Context>;
}): {
    context: DurableContextImpl<DurableLogger>;
    storage: InMemoryStorage;
    executionContext: ExecutionContext;
};
export {};
//# sourceMappingURL=create-test-durable-context.d.ts.map