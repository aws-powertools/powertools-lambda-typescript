export declare const TEST_CONSTANTS: {
    readonly STEP_ID: "test-step-id";
    readonly STEP_ID_1: "step-1";
    readonly CALLBACK_ID: "test-callback-id";
    readonly STEP: "test-step";
    readonly TASK_TOKEN: "test-task-token";
    readonly CHECKPOINT_TOKEN: "test-checkpoint-token";
    readonly DURABLE_EXECUTION_ARN: "test-durable-execution-arn";
    readonly CALLBACK_NAME: "test-callback";
    readonly STEP_NAME: "test-step";
    readonly RESULT: "test-result";
    readonly CHILD_CONTEXT_ID: "test-child-context-id";
    readonly CHILD_CONTEXT_STEP_ID: "test-child-context-step-id";
    readonly CHILD_CONTEXT_NAME: "test-child-context";
    readonly CHILD_CONTEXT_RESULT: "child-context-result";
    readonly DEFAULT_MAP_CONFIG: {
        readonly iterationSubType: "MapIteration";
        readonly maxConcurrency: undefined;
        readonly topLevelSubType: "Map";
    };
    readonly DEFAULT_PARALLEL_CONFIG: {
        readonly iterationSubType: "ParallelBranch";
        readonly maxConcurrency: undefined;
        readonly topLevelSubType: "Parallel";
    };
    readonly DEFAULT_STEP_START_CHECKPOINT: {
        readonly Id: "test-step-id";
        readonly ParentId: undefined;
        readonly Action: "START";
        readonly SubType: "Step";
        readonly Type: "STEP";
        readonly Name: "test-step";
    };
    readonly DEFAULT_STEP_SUCCEED_CHECKPOINT: {
        readonly Id: "test-step-id";
        readonly ParentId: undefined;
        readonly Action: "SUCCEED";
        readonly SubType: "Step";
        readonly Type: "STEP";
        readonly Name: "test-step";
    };
    readonly DEFAULT_STEP_FAIL_CHECKPOINT: {
        readonly Id: "test-step-id";
        readonly ParentId: undefined;
        readonly Action: "FAIL";
        readonly SubType: "Step";
        readonly Type: "STEP";
        readonly Name: "test-step";
    };
    readonly DEFAULT_STEP_RETRY_CHECKPOINT: {
        readonly Id: "test-step-id";
        readonly ParentId: undefined;
        readonly Action: "RETRY";
        readonly SubType: "Step";
        readonly Type: "STEP";
        readonly Name: "test-step";
    };
};
//# sourceMappingURL=test-constants.d.ts.map